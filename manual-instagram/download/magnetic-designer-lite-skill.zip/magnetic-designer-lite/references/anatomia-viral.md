# Anatomia do carrossel viral (capa que para o scroll + sequência que prende)

Use como estrutura padrão do carrossel (opção 2), com qualquer estilo. Combina melhor com o estilo **viral** (capa com foto em tela cheia, slides creme com fotos e prints em cartões). Se a pessoa tiver um padrão próprio salvo (ex.: pedido de curtida no slide 3 ou 4), encaixe dentro desta anatomia.

## O mapa (8 a 10 slides)

| Slides | Função | O que entra |
|---|---|---|
| 1 | **Quebra de padrão** | Foto chamativa + manchete forte. Tem que parar o dedo em 1 segundo. |
| 2 e 3 | **Armadilha de retenção** | A situação que a pessoa reconhece ("já aconteceu comigo") e a promessa do que ela vai ganhar se continuar. Deixe uma pergunta aberta. |
| 4 a 6 | **Entrega técnica pesada** | O conteúdo de verdade: conceito, passo, dado, exemplo, print. Um por slide. É aqui que a pessoa sente que aprendeu. |
| 7 e 8 | **Gatilhos de salvamento** | Checklist, prompt pronto, modelo, comparação, resumo. Coisa que dá vontade de guardar. Use o tipo `salvar` e diga "salva esse post". |
| Último | **Chamada** | Uma ação só: conversa (pergunta), seguir, palavra-chave ou link. A chamada da configuração. |

## A capa: 1 segundo pra ganhar o scroll

**A imagem não é o rosto da pessoa por padrão.** Rosto funciona quando a pessoa é conhecida ou a expressão é forte. No resto, a imagem chamativa vence. Ordem de escolha:

1. **Metáfora visual** do tema: um objeto que conta a ideia sem texto (peixinho dourado = memória curta, cofre aberto = dinheiro vazando, despertador = prazo, fila = atendimento lento). É a mais forte.
2. **Print real** com algo surpreendente: um número, uma conversa, um painel, uma notificação.
3. **Cena do problema**: mesa bagunçada, celular lotado de mensagens, agenda vazia.
4. **Imagem gerada por IA** quando nenhuma foto real conta a ideia (descreva a cena, peça formato 4:5, sem texto na imagem).
5. **Foto da pessoa** com expressão forte ou num contexto que conta a história.

Onde achar: Unsplash (conector ou unsplash.com, foto grátis), Pexels, prints da própria pessoa, gerador de imagem disponível. Nunca use foto de pessoa real conhecida, logo de marca de terceiros ou imagem de outro perfil sem permissão.

Regras da foto: contraste alto, um assunto só, cor que salta (de preferência perto da cor de destaque da marca), espaço embaixo pra manchete (no estilo viral o texto fica na parte de baixo da foto, sobre a sombra).

**A manchete da capa** (até 14 palavras, 2 a 4 linhas):
- **Afirmação que contraria:** "Sua IA tem memória de peixinho dourado. E não é defeito."
- **Número + resultado:** "1 prompt que fez o cliente responder em 4 minutos."
- **Erro que dói:** "Você está pagando 5 ferramentas pra fazer o trabalho de uma."
- **Segredo/bastidor:** "O que eu faço antes de mandar qualquer proposta."
- **Antes x depois:** "Era 3 horas por dia no WhatsApp. Virou 20 minutos."
- **Aviso:** "Antes de colocar IA no seu atendimento, olha isso."

Pinte 1 a 3 palavras com a cor de destaque (`*palavra*`). Use o `selo` pra um rótulo curto em cima da foto ("VOCÊ FAZ ISSO", "NOVO", "ERRO COMUM", "TESTEI"). A linha de baixo (`sub`) diz o que a pessoa ganha ao arrastar.

## Não deixe engessado

- **Varie o tipo de slide** a cada 1 ou 2 slides: conversa (`chat`), número grande (`numero`), foto com legenda (`imagem`), print no celular (`print`), lista, comparação, `salvar`. Três slides seguidos de texto puro cansam.
- **Alterne o fundo** de vez em quando (creme, escuro) pra marcar a virada do carrossel, por exemplo no slide da entrega mais importante.
- **Metáfora no meio:** repita a ideia da capa com outra imagem no slide 5 ou 6 ("pensa numa mesa que só cabe uma pilha de papel").
- **Frases de conversa**, não de manual. Leia em voz alta: se soa como apostila, reescreva.
- Nada de inventar caso, número ou print. Sem dado real, troque por um exemplo descrito como exemplo.

## Checklist antes de gerar

- [ ] A capa tem imagem que conta a ideia sem o texto?
- [ ] A manchete para o scroll em 1 segundo e tem até 14 palavras?
- [ ] Os slides 2 e 3 fazem a pessoa se reconhecer e prometem algo?
- [ ] Os slides 4 a 6 entregam de verdade (um ponto por slide)?
- [ ] Tem pelo menos um slide pra salvar (checklist, prompt, modelo)?
- [ ] Os tipos de slide variam?
- [ ] O último slide tem uma ação só?
