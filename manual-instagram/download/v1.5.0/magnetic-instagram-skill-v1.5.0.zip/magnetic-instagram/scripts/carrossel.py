#!/usr/bin/env python3
"""carrossel.py - monta o carrossel (1080x1350) a partir de um arquivo JSON e gera as imagens.

uso:
  python3 carrossel.py slides.json saida/            # gera saida/carrossel.html e saida/slide-N.png
  python3 carrossel.py slides.json saida/ --so-html  # só o HTML (para abrir no navegador)
  python3 carrossel.py config.json galeria/ --galeria  # amostra de todos os estilos com as cores da pessoa

Estilos ("estilo" no JSON): impacto, editorial, tweet, caderno, gradiente, minimal, caneta, sistema, jornal, drawing,
ou "alternar" (sorteia um diferente de "ultimo_estilo"). O estilo usado sai no final da execução.
No estilo tweet, use "nome" e "avatar" (foto da pessoa) no JSON.
No estilo jornal, use "jornal_nome" (ex.: "O Diário Magnético") e "jornal_edicao" (ex.: "Edição de ontem · Qui, 1º de outubro");
em cada slide dá pra pôr "pagina" (ex.: "Classificados"), "edicao" e "carimbo" ("SAIU|ONTEM") com "carimbo_data".
"formato": "story" gera telas de Stories (1080x1920) em vez de carrossel (1080x1350), em qualquer estilo.
"css_extra" (opcional) acrescenta ajustes finos de visual, por exemplo pra ficar parecido com um carrossel de exemplo da pessoa.

slides.json:
{
  "arroba": "@fulano", "assinatura": "opcional, texto pequeno no topo à esquerda",
  "cor_destaque": "#D15434", "cor_escura": "#0F0D0C", "cor_clara": "#F7F4F1",
  "fonte_titulo": "Barlow Condensed", "fonte_texto": "Plus Jakarta Sans",
  "slides": [
    {"tipo": "capa", "fundo": "escuro", "chapeu": "IA + Instagram", "titulo": "Texto *destacado*", "sub": "linha de promessa", "foto": "caminho/opcional.jpg"},
    {"tipo": "texto", "fundo": "claro", "chapeu": "...", "titulo": "...", "texto": "parágrafo curto"},
    {"tipo": "lista", "fundo": "escuro", "chapeu": "...", "titulo": "...", "itens": [["título", "detalhe"], ...]},
    {"tipo": "chat", "fundo": "claro", "chapeu": "...", "titulo": "...", "pergunta": "...", "resposta": "...", "nota": "..."},
    {"tipo": "comparacao", "fundo": "claro", "titulo": "...", "a": ["Antes", "item", "item"], "b": ["Depois", "item", "item"], "conclusao": "..."},
    {"tipo": "numero", "fundo": "escuro", "numero": "3x", "titulo": "...", "texto": "..."},
    {"tipo": "resumo", "fundo": "claro", "titulo": "Resumo", "itens": ["...", "..."]},
    {"tipo": "cta", "numero": "+200", "titulo": "...", "texto": "...", "acao": "Comenta", "palavra": "GUIA", "depois": "que eu te mando o link."}
  ]
}
Use *asteriscos* no título para pintar a palavra com a cor de destaque.
Fundo: "escuro", "claro" ou "destaque". O slide "cta" usa o destaque por padrão.
"""
import json, sys, os, html, re, shutil, subprocess, pathlib, base64, urllib.request, tarfile, tempfile

def E(t): return html.escape(str(t or ""))
def hl(t): return re.sub(r"\*(.+?)\*", r"<em>\1</em>", E(t))

CACHE = os.path.join(os.path.expanduser("~"), ".cache", "magnetic-fontes")
def _baixa(url):
    try:
        with urllib.request.urlopen(url, timeout=12) as r: return r.read()
    except Exception: return None
def fontes_embutidas(familias):
    """Tenta embutir as fontes no HTML (funciona mesmo sem internet no navegador). Fontes: jsDelivr ou pacote npm @fontsource."""
    css = []
    for fam in familias:
        slug = fam.strip().lower().replace(" ", "-")
        d = os.path.join(CACHE, slug); os.makedirs(d, exist_ok=True)
        pesos = [400, 500, 600, 700, 800, 900]
        faltam = [w for w in pesos for sub in ("latin", "latin-ext") if not os.path.exists(os.path.join(d, f"{sub}-{w}.woff2"))]
        if faltam and not os.path.exists(os.path.join(d, ".tentado")):
            ok_cdn = _baixa(f"https://cdn.jsdelivr.net/npm/@fontsource/{slug}/package.json") is not None
            for w in (pesos if ok_cdn else []):
                for sub in ("latin", "latin-ext"):
                    f = os.path.join(d, f"{sub}-{w}.woff2")
                    if os.path.exists(f): continue
                    b = _baixa(f"https://cdn.jsdelivr.net/npm/@fontsource/{slug}/files/{slug}-{sub}-{w}-normal.woff2")
                    if b: open(f, "wb").write(b)
            if not any(n.endswith(".woff2") for n in os.listdir(d)) and shutil.which("npm"):
                tmp = tempfile.mkdtemp()
                try:
                    subprocess.run(["npm", "pack", f"@fontsource/{slug}", "--silent"], cwd=tmp, capture_output=True, timeout=90)
                    for tg in [x for x in os.listdir(tmp) if x.endswith(".tgz")]:
                        with tarfile.open(os.path.join(tmp, tg)) as tf:
                            for m in tf.getmembers():
                                mm = re.search(rf"files/{re.escape(slug)}-(latin|latin-ext)-(\d00)-normal\.woff2$", m.name)
                                if mm: open(os.path.join(d, f"{mm.group(1)}-{mm.group(2)}.woff2"), "wb").write(tf.extractfile(m).read())
                except Exception: pass
            open(os.path.join(d, ".tentado"), "w").write("1")
        arqs = [n for n in sorted(os.listdir(d)) if re.match(r"(latin|latin-ext)-(\d00)\.woff2$", n) and int(n.split("-")[-1][:3]) >= 400]
        unico = len({n.split("-")[-1] for n in arqs}) == 1
        for n in arqs:
            mm = re.match(r"(latin|latin-ext)-(\d00)\.woff2$", n)
            rng = "U+0000-00FF,U+0131,U+0152-0153,U+02BB-02BC,U+02C6,U+02DA,U+02DC,U+2000-206F,U+2074,U+20AC,U+2122,U+2191,U+2193,U+2212,U+2215,U+FEFF,U+FFFD" if mm.group(1) == "latin" else "U+0100-024F,U+0259,U+1E00-1EFF,U+2020,U+20A0-20AB,U+20AD-20C0,U+2113,U+2C60-2C7F,U+A720-A7FF"
            b64 = base64.b64encode(open(os.path.join(d, n), "rb").read()).decode()
            css.append(f"@font-face{{font-family:'{fam}';font-weight:{'100 900' if unico else mm.group(2)};font-display:block;src:url(data:font/woff2;base64,{b64}) format('woff2');unicode-range:{rng}}}")
    return "".join(css)

ESTILOS = {
 "impacto":   "Títulos gigantes em caixa alta, fundo escuro e claro alternando, cartões com borda. Forte e direto.",
 "editorial": "Cara de revista: títulos em caixa baixa, linhas finas, números grandes vazados, muito respiro.",
 "tweet":     "Cada slide parece um post do X/Twitter com sua foto, nome e @. Ótimo pra opinião e bastidor.",
 "caderno":   "Folha pautada com marca-texto e anotações à mão. Ótimo pra passo a passo e dicas.",
 "gradiente": "Fundo em degradê com as cores da marca e cartões de vidro arredondados. Moderno, tecnologia.",
 "minimal":   "Um fundo, texto centralizado e enorme, quase nada de enfeite. Ótimo pra frases e reflexões.",
 "caneta":    "Desenho de caneta azul em folha de caderno, letra de mão e marca-texto. Ótimo pra tutorial e passo a passo.",
 "sistema":   "Papel bege, título com serifa sublinhado à mão, post-it e cartões de sistema. Ótimo pra método e 'monte seu sistema'.",
 "drawing":   "Desenho à mão em folha de caderno, nas cores da marca: letra de mão, caixas com contorno de caneta, marca-texto, círculos e setas tracejadas. Fotos viram desenho a lápis. Ótimo pra explicar processo e contar história.",
 "jornal":    "Página de jornal impresso: cabeçalho com o nome do jornal, manchete com serifa, colunas e carimbo. Ótimo pra notícia, novidade e resumo do que saiu ontem.",
}
def _a(cor, alfa):
    cor = (cor or "#000000").strip()
    return cor + alfa if re.fullmatch(r"#[0-9a-fA-F]{6}", cor) else cor
def desenho(caminho):
    """Transforma uma foto em desenho a lápis (estilo drawing). Precisa de Pillow e numpy; sem eles, usa a foto normal."""
    try:
        from PIL import Image, ImageOps, ImageFilter
        import numpy as np, io, base64
        im = Image.open(caminho).convert("RGBA"); im.thumbnail((1400, 1400))
        a = im.split()[3]; g = ImageOps.grayscale(im.convert("RGB"))
        inv = ImageOps.invert(g).filter(ImageFilter.GaussianBlur(7))
        G = np.asarray(g).astype(float); I = np.asarray(inv).astype(float)
        d = np.clip(G * 255 / (256 - I), 0, 255); d = np.clip(255 - (255 - d) * 1.9, 0, 255); d = np.where(d > 240, 255, d)
        k = (255 - d) / 255.0; ink = np.array([27, 23, 20])
        rgb = 253 * (1 - k[..., None]) + ink * k[..., None]
        o = Image.fromarray(rgb.astype("uint8")).convert("RGBA"); o.putalpha(a)
        b = io.BytesIO(); o.save(b, "PNG"); return "data:image/png;base64," + base64.b64encode(b.getvalue()).decode()
    except Exception:
        return ""

def css_estilo(estilo, ac, dk, lt, FT, FX, FN, FE):
    if estilo == "editorial": return f"""
.bar{{display:none}} .top{{border-bottom:2px solid currentColor;margin:0 80px;padding:56px 0 22px;opacity:.75}}
h1,h2{{font-family:{FE};text-transform:none;letter-spacing:-.015em;line-height:1.04;font-weight:400}} h1{{font-size:132px}} h2{{font-size:90px}}
h1 em,h2 em{{font-style:italic}} .cmp h3,.conc,.caixa strong,.big,.item i{{font-family:{FE};font-weight:400;text-transform:none}}
.chapeu{{color:inherit;opacity:.7;border-top:2px solid var(--ac);display:inline-block;align-self:flex-start;padding-top:14px}}
.item{{background:none;border:none;border-top:2px solid rgba(128,128,128,.35);border-radius:0;padding:26px 0}}
.item i{{background:none;color:var(--ac);font-size:64px;width:90px;height:auto;line-height:1}}
.big{{color:transparent;-webkit-text-stroke:4px var(--ac)}} .destaque .big{{-webkit-text-stroke-color:#fff}}
.cmp>div{{border-radius:0;border:none;border-top:4px solid currentColor}} .cmp>div.b{{background:none;color:inherit;border-top-color:var(--ac)}} .cmp>div.b h3{{color:var(--ac)}}
.conc,.caixa{{border-radius:0}} .chat div{{border-radius:0}}
.prog .t{{height:2px}} .prog .t span{{height:2px}}
"""
    if estilo == "tweet": return f"""
.bar,.top{{display:none}} .s.escuro{{background:{dk}}} .s.claro{{background:#FFFFFF}}
.c{{padding:60px 70px 150px}}
.tw{{max-width:940px;width:100%;margin:0 auto}}
.twh{{display:flex;align-items:center;gap:26px;margin-bottom:40px}}
.twh .av{{width:120px;height:120px;border-radius:50%;background:var(--ac);color:#fff;display:flex;align-items:center;justify-content:center;font:800 48px {FX};overflow:hidden;flex:none}}
.twh .av img{{width:100%;height:100%;object-fit:cover}}
.twh b{{display:block;font:800 42px {FX}}} .twh b i{{display:inline-block;width:38px;height:38px;border-radius:50%;background:var(--ac);color:#fff;font:900 26px/38px {FX};text-align:center;font-style:normal;margin-left:10px;vertical-align:4px}}
.twh span{{font-size:32px;opacity:.6}}
h1,h2{{font-family:{FX};text-transform:none;font-weight:800;letter-spacing:-.01em;line-height:1.15}} h1{{font-size:88px}} h2{{font-size:66px}}
.chapeu{{text-transform:none;letter-spacing:0;font-size:30px}}
.item{{border-radius:18px}} .big{{font-family:{FX};font-weight:800}}
.comfoto .foto{{display:none}}
"""
    if estilo == "caderno": return f"""
.bar{{display:none}}
.s.claro{{background:repeating-linear-gradient(180deg,transparent 0 62px,{_a(dk,'14')} 62px 64px),{lt}}}
.s.escuro{{background:repeating-linear-gradient(180deg,transparent 0 62px,{_a(lt,'12')} 62px 64px),{dk}}}
.s::after{{content:"";position:absolute;top:0;bottom:0;left:56px;width:3px;background:{_a(ac,'99')}}}
h1,h2{{text-transform:none;letter-spacing:-.01em;line-height:1.08}} h1{{font-size:120px}} h2{{font-size:84px}}
h1 em,h2 em{{color:inherit;background:linear-gradient(180deg,transparent 58%,{_a(ac,'aa')} 58% 92%,transparent 92%);padding:0 6px}}
.chapeu{{font:700 54px {FN};text-transform:none;letter-spacing:0;transform:rotate(-2deg);align-self:flex-start}}
.nota,.swipe{{font-family:{FN};font-size:52px;text-transform:none;letter-spacing:0;border:none;padding-left:0}}
.item{{background:none;border:3px dashed rgba(128,128,128,.45);border-radius:14px}}
.item i{{border-radius:50%;transform:rotate(-6deg)}}
.check li::before{{content:"☑";font-family:{FX}}}
.caixa,.conc{{transform:rotate(-1deg);border-radius:10px}}
"""
    if estilo == "gradiente": return f"""
.bar{{display:none}}
.s.escuro{{background:radial-gradient(circle at 88% 8%,{_a(ac,'aa')} 0,transparent 42%),radial-gradient(circle at 0% 100%,{_a(ac,'55')} 0,transparent 40%),{dk}}}
.s.claro{{background:radial-gradient(circle at 90% 6%,{_a(ac,'55')} 0,transparent 40%),radial-gradient(circle at 0% 100%,{_a(ac,'30')} 0,transparent 45%),{lt}}}
.s.destaque{{background:linear-gradient(150deg,{ac} 0%,{dk} 130%)}}
.top{{margin:48px 80px 0;padding:14px 26px;border-radius:40px;background:rgba(128,128,128,.14);opacity:.85}}
h1,h2{{text-transform:none;letter-spacing:-.02em;line-height:1.02}} h1{{font-size:132px}} h2{{font-size:88px}}
.item,.cmp>div,.chat div,.caixa,.conc{{border-radius:34px;border:1px solid rgba(255,255,255,.18);box-shadow:0 20px 50px rgba(0,0,0,.18)}}
.escuro .item{{background:rgba(255,255,255,.07)}} .claro .item{{background:rgba(255,255,255,.75)}}
.item i{{border-radius:50%}}
"""
    if estilo == "caneta":
        tinta = "#1E36A6"
        return f"""
.bar{{display:none}}
.s.claro,.s.escuro,.s.destaque{{background:repeating-linear-gradient(180deg,transparent 0 58px,#9DB5E3 58px 60px),#FDFDFB;color:{tinta}}}
.s::after{{content:"";position:absolute;top:0;bottom:0;left:64px;width:3px;background:#E79A9A}}
.top{{opacity:.8;font-family:{FN};font-size:30px;letter-spacing:0;text-transform:none;color:{tinta}}}
.c{{padding-left:110px}}
h1,h2{{font-family:{FN};font-weight:700;text-transform:uppercase;letter-spacing:.01em;line-height:1.02;color:{tinta}}} h1{{font-size:118px}} h2{{font-size:92px}}
h1 em,h2 em{{color:{tinta};background:linear-gradient(180deg,transparent 52%,#BFD5F7 52%,#BFD5F7 92%,transparent 92%);padding:0 8px}}
.destaque h1 em,.destaque h2 em{{color:{tinta}}}
.chapeu{{font:700 44px {FN};color:{tinta};text-transform:none;letter-spacing:0;text-decoration:underline;text-decoration-thickness:3px;text-underline-offset:8px}}
.destaque .chapeu{{color:{tinta};opacity:1}}
.sub,.txt,.item span,.chat div,.cmp p,.caixa p,.nota{{font-family:{FN}}}
.item{{background:#ffffffd9;border:3px solid {tinta};border-radius:22px 16px 26px 14px;color:{tinta}}}
.item i{{background:none;border:3px solid {tinta};color:{tinta};border-radius:50%;font-family:{FN}}}
.item b{{font-family:{FN};font-size:42px}} .item span{{opacity:.85}}
.chat .eu,.chat .ia,.escuro .chat .ia,.claro .chat .ia{{background:#ffffffd9;color:{tinta};border:3px solid {tinta}}}
.chat .eu{{background:#BFD5F7}}
.cmp>div,.cmp>div.b{{background:#ffffffd9;color:{tinta};border:3px solid {tinta}}} .cmp>div.b{{background:#BFD5F7}}
.cmp h3,.conc,.caixa strong,.big{{font-family:{FN};color:{tinta}}}
.conc,.escuro .conc,.caixa{{background:#ffffffd9;color:{tinta};border:3px dashed {tinta};transform:rotate(-1deg)}}
.caixa small{{color:{tinta}}} .destaque .big,.big{{color:{tinta}}}
.check li{{font-family:{FN}}} .check li::before{{content:"☑";color:{tinta};font-family:{FX}}}
.nota{{border-left:none;border:3px dashed {tinta};border-radius:16px;padding:16px 20px}}
.swipe{{font-family:{FN};color:{tinta};text-transform:none;letter-spacing:0;font-size:40px;text-decoration:underline}}
.foto::before{{background:#BFD5F7}}
.prog .t{{background:#9DB5E3}} .prog .t span,.destaque .prog .t span{{background:{tinta}}} .prog b{{font-family:{FN};color:{tinta}}}
"""
    if estilo == "drawing":
        tinta = dk if dk and dk.lower() not in ("#ffffff", "#fff") else "#1B1714"
        return f"""
.bar{{display:none}}
.s.claro,.s.escuro,.s.destaque{{background:repeating-linear-gradient(180deg,transparent 0 58px,{_a(tinta,'1c')} 58px 60px),#FDFAF5;color:{tinta}}}
.s::after{{content:"";position:absolute;top:0;bottom:0;left:64px;width:3px;background:{_a(ac,'99')}}}
.top{{opacity:.75;font-family:{FN};font-size:28px;letter-spacing:0;text-transform:none;color:{tinta}}}
.c{{padding-left:110px}}
h1,h2{{font-family:{FN};font-weight:700;text-transform:none;letter-spacing:-.005em;line-height:1.08;color:{tinta}}} h1{{font-size:110px}} h2{{font-size:88px}}
h1 em,h2 em{{color:{tinta};font-style:normal;background:linear-gradient(180deg,transparent 50%,{_a(ac,'55')} 50%,{_a(ac,'55')} 92%,transparent 92%);padding:0 8px}}
.destaque h1 em,.destaque h2 em{{color:{ac}}}
.chapeu{{font:700 40px {FN};color:{ac};text-transform:none;letter-spacing:0;border:3px solid {ac};border-radius:40px;padding:2px 22px;display:inline-block;width:fit-content}}
.destaque .chapeu{{color:{ac};opacity:1}}
.sub,.txt,.item span,.chat div,.cmp p,.caixa p,.nota{{font-family:{FN}}}
.item{{background:#fffdf9;border:3px solid {tinta};border-radius:24px 14px 28px 16px/16px 26px 14px 24px;box-shadow:5px 6px 0 {tinta};color:{tinta}}}
.item i{{background:none;border:3.5px solid {ac};color:{ac};border-radius:50%;font-family:{FN}}}
.item b{{font-family:{FN};font-size:42px}} .item span{{opacity:.85}}
.chat .eu,.chat .ia,.escuro .chat .ia,.claro .chat .ia{{background:#fffdf9;color:{tinta};border:3px solid {tinta};box-shadow:4px 5px 0 {tinta}}}
.chat .eu{{background:{_a(ac,'33')}}}
.cmp>div,.cmp>div.b{{background:#fffdf9;color:{tinta};border:3px solid {tinta};box-shadow:5px 6px 0 {tinta}}} .cmp>div.b{{background:{_a(ac,'33')}}}
.cmp h3,.conc,.caixa strong,.big{{font-family:{FN};color:{tinta}}}
.conc,.escuro .conc,.caixa{{background:#fffdf9;color:{tinta};border:3px dashed {ac};transform:rotate(-1deg)}}
.caixa small{{color:{ac}}} .destaque .big,.big{{color:{ac}}}
.check li{{font-family:{FN}}} .check li::before{{content:"✓";color:{ac};font-family:{FN};font-weight:700}}
.nota{{border-left:none;border:3px dashed {ac};border-radius:16px;padding:16px 20px}}
.swipe{{font-family:{FN};color:{ac};text-transform:none;letter-spacing:0;font-size:40px;font-weight:700}}
.foto::before{{background:{_a(ac,'33')};border:3px solid {tinta};border-radius:24px 14px 28px 16px}}
.foto img{{border-radius:24px 14px 28px 16px;background:#FDFAF5}}
.prog .t{{background:{_a(tinta,'22')}}} .prog .t span,.destaque .prog .t span{{background:{ac}}} .prog b{{font-family:{FN};color:{tinta}}}
"""
    if estilo == "sistema":
        papel = "#EEE6D6"; tinta = dk
        rab = "data:image/svg+xml;utf8," + "<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 300 24' preserveAspectRatio='none'><path d='M3 15 C 60 4, 140 22, 200 10 S 280 8, 297 14' fill='none' stroke='" + ac.replace("#", "%23") + "' stroke-width='5' stroke-linecap='round'/></svg>"
        return f"""
.bar{{display:none}}
.s.claro,.s.escuro{{background:radial-gradient(1200px 900px at 30% 20%,#ffffff55,transparent 60%),{papel};color:{tinta}}}
.s.destaque{{background:{papel};color:{tinta}}}
.top{{margin:0 70px;padding:44px 0 16px;border-bottom:1.5px solid {_a(tinta,'33')};font-family:'JetBrains Mono',monospace;font-size:20px;letter-spacing:.06em;opacity:.8}}
h1,h2{{font-family:{FE};font-weight:400;text-transform:none;letter-spacing:-.01em;line-height:1}} h1{{font-size:128px}} h2{{font-size:98px}}
h1 em,h2 em{{font-style:normal;color:var(--ac);background:url("{rab}") no-repeat left bottom/100% 22px;padding-bottom:14px}}
.destaque h1 em,.destaque h2 em{{color:var(--ac)}}
.chapeu{{align-self:flex-start;background:#F5E6B8;color:{tinta};font:700 40px {FN};text-transform:none;letter-spacing:0;padding:16px 26px;transform:rotate(-3deg);box-shadow:0 8px 18px #0000001f}}
.destaque .chapeu{{color:{tinta};opacity:1}}
.item{{background:#ffffff66;border:2px solid {tinta};border-radius:16px}}
.item i{{background:none;border:2px solid {tinta};color:var(--ac);border-radius:14px}}
.item b{{color:var(--ac)}}
.chat .ia,.escuro .chat .ia,.claro .chat .ia{{background:#16130F;color:#eae3d6}}
.cmp>div{{border:2px solid {tinta};border-radius:0}} .cmp>div.b{{background:{_a(ac,'1a')};color:{tinta};border-color:{tinta}}} .cmp>div.b h3{{color:var(--ac)}}
.cmp h3{{font-family:'JetBrains Mono',monospace;font-size:30px;letter-spacing:.06em}}
.conc,.escuro .conc{{background:#16130F;color:#eae3d6;font-family:'JetBrains Mono',monospace;font-size:34px;text-transform:none;border-radius:16px}}
.caixa{{background:#16130F;color:#eae3d6}} .caixa strong{{color:var(--ac);font-family:{FE};font-weight:400}}
.big{{font-family:{FE};font-weight:400}} .destaque .big{{color:var(--ac)}}
.nota{{font-family:{FN};font-size:44px;border:none;color:var(--ac);padding:0;transform:rotate(-2deg)}}
.swipe{{font-family:{FN};font-size:42px;text-transform:none;letter-spacing:0}}
.prog .t span,.destaque .prog .t span{{background:var(--ac)}}
"""
    if estilo == "jornal":
        papel = "#F3EDE2"; tinta = "#17130F"; FM = "'JetBrains Mono',monospace"
        return f"""
.bar{{display:none}}
.s.claro,.s.escuro,.s.destaque{{background:repeating-linear-gradient(0deg,transparent 0 3px,#00000005 3px 4px),{papel};color:{tinta}}}
.top{{display:none}}
.mast{{margin:52px 70px 0;text-align:center;border-bottom:6px double {tinta};padding-bottom:14px}}
.mast .l1{{display:flex;justify-content:space-between;font:700 20px {FM};letter-spacing:.08em;text-transform:uppercase;color:{_a(tinta,'99')};border-bottom:2px solid {tinta};padding-bottom:12px}}
.mast .nm{{font:900 86px/1.05 {FE};letter-spacing:-.02em;margin-top:10px}}
.mast .l2{{display:flex;justify-content:space-between;font:600 20px {FM};letter-spacing:.06em;text-transform:uppercase;color:{_a(tinta,'99')};margin-top:8px}}
.c{{justify-content:flex-start;padding:40px 70px 140px}}
.chapeu{{align-self:flex-start;background:var(--ac);color:#fff;font:800 24px {FM};letter-spacing:.12em;padding:10px 18px;margin-bottom:22px}}
.destaque .chapeu{{color:#fff;opacity:1}}
h1,h2{{font-family:{FE};font-weight:900;text-transform:none;letter-spacing:-.025em;line-height:.98}} h1{{font-size:112px}} h2{{font-size:80px;margin-bottom:26px}}
h1 em,h2 em,.destaque h1 em,.destaque h2 em{{font-style:italic;color:var(--ac)}}
.sub,.txt{{font-family:{FE};font-weight:400}} .sub{{border-left:6px solid var(--ac);padding-left:24px;opacity:1}}
.swipe,.destaque .swipe{{align-self:flex-end;background:{tinta};color:{papel};font:800 26px {FM};padding:12px 20px;letter-spacing:.06em}}
.foto{{right:70px;bottom:140px;width:420px;height:520px;border:2px solid {tinta};padding:10px;background:#fff}}
.foto::before{{display:none}} .foto img{{border-radius:0;filter:grayscale(1) contrast(1.12)}}
.itens{{gap:0;border-top:2px solid {tinta}}}
.item{{background:none;border:none;border-bottom:1px solid {_a(tinta,'55')};border-radius:0;padding:22px 0}}
.item i{{background:none;color:var(--ac);font:900 56px/1 {FE};width:84px;height:auto;text-align:left}}
.item b{{font-weight:700;font-size:44px}} .item span{{opacity:.8;font-size:34px}}
.cmp p{{font-size:38px}} .txt{{font-size:44px}}
.chat div{{border-radius:0}} .escuro .chat .ia,.claro .chat .ia,.chat .ia{{background:#fff;color:{tinta};border:2px solid {tinta}}}
.cmp{{gap:0;border-top:2px solid {tinta}}} .cmp>div{{border:none;border-radius:0;padding:24px 26px 24px 0}}
.cmp>div.b{{background:none;color:{tinta};border-left:1px solid {_a(tinta,'55')};padding:24px 0 24px 26px}}
.cmp h3{{font:900 52px {FE};text-transform:none}} .cmp>div.b h3{{color:var(--ac)}}
.conc,.escuro .conc,.caixa{{background:{tinta};color:{papel};border-radius:0}}
.conc{{font:700 44px/1.3 {FX};text-transform:none}}
.caixa small{{font-family:{FM};color:var(--ac)}} .caixa strong{{font-family:{FE};font-weight:900;color:{papel}}}
.big,.destaque .big{{font-family:{FE};font-weight:900;color:var(--ac)}}
.check li::before{{content:"■";font-size:30px;top:6px;color:var(--ac)}}
.nota{{border-left:6px solid var(--ac);font-family:{FE};font-style:italic;font-weight:400}}
.carimbo{{position:absolute;right:80px;bottom:150px;transform:rotate(-8deg);border:6px solid var(--ac);color:var(--ac);font:900 40px/1 {FM};padding:14px 22px;text-align:center;letter-spacing:.06em;z-index:3}}
.carimbo small{{display:block;font-size:20px;margin-top:6px}}
.prog .t{{height:2px;border-radius:0;background:{_a(tinta,'33')}}} .prog .t span,.destaque .prog .t span{{background:{tinta};border-radius:0}}
.prog b{{font-family:{FM}}}
"""
    if estilo == "minimal": return f"""
.bar{{display:none}} .top{{justify-content:center;opacity:.45}} .top span:first-child{{display:none}}
.c{{align-items:center;text-align:center;padding:40px 110px 150px}}
h1,h2{{text-transform:none;letter-spacing:-.02em;line-height:1.05}} h1{{font-size:124px}} h2{{font-size:92px}}
.chapeu{{align-self:center}} .itens,.check,.cmp,.chat{{width:100%;text-align:left}}
.item{{background:none;border:none;border-bottom:2px solid rgba(128,128,128,.3);border-radius:0}}
.chat div{{text-align:left}} .caixa{{width:100%}}
.prog{{left:50%;right:auto;transform:translateX(-50%);width:240px}}
"""
    return ""

def build(cfg, base_dir):
    ac, dk, lt = cfg.get("cor_destaque", "#D15434"), cfg.get("cor_escura", "#0F0D0C"), cfg.get("cor_clara", "#F7F4F1")
    ft, fx = cfg.get("fonte_titulo", "Barlow Condensed"), cfg.get("fonte_texto", "Plus Jakarta Sans")
    arroba, ass = E(cfg.get("arroba", "")), E(cfg.get("assinatura", ""))
    slides = cfg["slides"]; T = len(slides)
    H = 1920 if str(cfg.get("formato", "")).lower() in ("story", "stories", "9:16") else 1350
    estilo = (cfg.get("estilo") or "impacto").lower().strip()
    if estilo in ("alternar", "aleatorio", "aleatório", "variar"):
        import random
        op = [e for e in ESTILOS if e != (cfg.get("ultimo_estilo") or "").lower()]
        estilo = random.choice(op)
    if estilo not in ESTILOS: estilo = "impacto"
    fn = cfg.get("fonte_anotacao", "Caveat")
    fe = cfg.get("fonte_editorial", "DM Serif Display")
    if estilo in ("caneta", "drawing"): fn = cfg.get("fonte_caneta", "Kalam")
    extra_f = set()
    if estilo in ("caderno", "caneta", "sistema", "drawing"): extra_f.add(fn)
    if estilo == "jornal": fe = cfg.get("fonte_jornal", "Playfair Display")
    if estilo in ("editorial", "sistema", "jornal"): extra_f.add(fe)
    if estilo in ("sistema", "jornal"): extra_f.add("JetBrains Mono")
    emb = fontes_embutidas({ft, fx} | extra_f)
    FN = f"'{fn}','Comic Sans MS',cursive"
    FE = f"'{fe}',Georgia,'Times New Roman',serif"
    FT, FX = f"'{ft}',Impact,'Arial Narrow',sans-serif", f"'{fx}',Arial,Helvetica,sans-serif"
    fam = "&".join("family=" + f.replace(" ", "+") + ":wght@400;600;700;800;900" for f in {ft, fx})
    css = emb + f"""
*{{box-sizing:border-box;margin:0;padding:0}}
body{{background:#777}}
:root{{--ac:{ac};--dk:{dk};--lt:{lt}}}
.s{{width:1080px;height:{H}px;position:relative;overflow:hidden;font-family:{FX};display:flex;flex-direction:column}}
.s.escuro{{background:var(--dk);color:var(--lt)}} .s.claro{{background:var(--lt);color:var(--dk)}}
.s.destaque{{background:var(--ac);color:#fff}}
.bar{{position:absolute;top:0;left:0;right:0;height:12px;background:var(--ac)}} .destaque .bar{{background:var(--dk)}}
.top{{display:flex;justify-content:space-between;padding:56px 80px 0;font:700 22px {FX};letter-spacing:.14em;text-transform:uppercase;opacity:.6}}
.c{{flex:1;display:flex;flex-direction:column;justify-content:center;padding:40px 80px 150px}}
.chapeu{{font:800 26px {FX};letter-spacing:.16em;text-transform:uppercase;color:var(--ac);margin-bottom:26px}}
.destaque .chapeu{{color:#fff;opacity:.85}}
h1,h2{{font-family:{FT};font-weight:900;text-transform:uppercase;line-height:1.02;letter-spacing:.005em}}
h1{{font-size:150px}} h2{{font-size:96px;margin-bottom:34px}}
h1 em,h2 em{{font-style:normal;color:var(--ac)}} .destaque h1 em,.destaque h2 em{{color:var(--dk)}}
.sub,.txt{{font-size:42px;line-height:1.38}} .sub{{margin-top:36px;opacity:.85}}
.txt{{opacity:.9}}
.swipe{{margin-top:44px;font:800 28px {FX};letter-spacing:.12em;text-transform:uppercase;color:var(--ac)}}
.foto{{position:absolute;right:80px;bottom:150px;width:440px;height:560px}}
.foto::before{{content:"";position:absolute;inset:0;transform:translate(20px,20px);background:var(--ac);border-radius:28px}}
.foto img{{position:relative;width:100%;height:100%;object-fit:cover;object-position:50% 20%;border-radius:28px;display:block}}
.comfoto .c{{justify-content:flex-start;padding-top:60px}} .comfoto .sub{{max-width:430px}}
.itens{{display:grid;gap:20px}}
.item{{display:flex;gap:24px;align-items:flex-start;border-radius:22px;padding:26px 28px;border:2px solid rgba(128,128,128,.28);background:rgba(128,128,128,.08)}}
.item i{{flex:none;width:66px;height:66px;border-radius:16px;background:var(--ac);color:#fff;font:900 38px/66px {FT};text-align:center;font-style:normal}}
.item b{{font:800 38px/1.2 {FX}}} .item span{{display:block;font-size:30px;line-height:1.35;opacity:.72;margin-top:6px}}
.chat{{display:flex;flex-direction:column;gap:22px}}
.chat div{{max-width:860px;border-radius:26px;padding:32px 36px;font-size:37px;line-height:1.4}}
.chat .eu{{align-self:flex-end;background:var(--ac);color:#fff;border-bottom-right-radius:6px}}
.chat .ia{{align-self:flex-start;border-bottom-left-radius:6px}}
.escuro .chat .ia{{background:var(--lt);color:var(--dk)}} .claro .chat .ia{{background:var(--dk);color:var(--lt)}}
.nota{{margin-top:40px;border-left:8px solid var(--ac);padding:8px 0 8px 26px;font:700 36px/1.35 {FX}}}
.cmp{{display:grid;grid-template-columns:1fr 1fr;gap:22px}}
.cmp>div{{border-radius:24px;padding:32px 28px;border:2px solid rgba(128,128,128,.28)}}
.cmp>div.b{{background:var(--ac);color:#fff;border-color:var(--ac)}}
.cmp h3{{font:900 54px {FT};text-transform:uppercase;margin-bottom:14px}}
.cmp p{{font-size:33px;line-height:1.35;padding:12px 0;border-bottom:1px solid rgba(128,128,128,.3)}}
.conc{{margin-top:36px;background:var(--dk);color:var(--lt);border-radius:22px;padding:28px 32px;font:900 54px/1.05 {FT};text-transform:uppercase}}
.escuro .conc{{background:var(--ac);color:#fff}}
.big{{font:900 300px/.9 {FT};color:var(--ac);margin-bottom:24px}} .destaque .big{{color:#fff}}
.check{{list-style:none;display:grid;gap:22px}}
.check li{{font:700 44px/1.3 {FX};padding-left:62px;position:relative}}
.check li::before{{content:"✓";position:absolute;left:0;top:-4px;font:900 48px {FT};color:var(--ac)}}
.caixa{{margin-top:50px;background:var(--dk);color:var(--lt);border-radius:28px;padding:40px 44px}}
.caixa small{{font:800 26px {FX};letter-spacing:.14em;text-transform:uppercase;color:var(--ac)}}
.caixa strong{{display:block;font:900 150px/.95 {FT};margin:8px 0}}
.caixa p{{font-size:34px}}
.prog{{position:absolute;left:80px;right:80px;bottom:62px;display:flex;align-items:center;gap:24px}}
.prog .t{{flex:1;height:6px;border-radius:6px;background:rgba(128,128,128,.3)}} .prog .t span{{display:block;height:100%;border-radius:6px;background:var(--ac)}}
.destaque .prog .t span{{background:#fff}}
.prog b{{font:800 26px {FX}}}
.s.story .c{{justify-content:center;padding-bottom:260px}}
.s.story h1{{font-size:{"124" if estilo == "jornal" else "150"}px}} .s.story h2{{font-size:{"100" if estilo == "jornal" else "104"}px}}
.s.story .sub,.s.story .txt{{font-size:50px}} .s.story .item b{{font-size:50px}} .s.story .item span{{font-size:38px}}
.s.story .cmp p{{font-size:42px}} .s.story .chat div{{font-size:44px}} .s.story .check li{{font-size:52px}}
.s.story .prog{{bottom:200px}} .s.story .carimbo{{bottom:330px}} .s.story .foto{{bottom:300px}}
.s:target{{}}
@media screen{{.s{{margin:0 auto 30px}}}}
""" + css_estilo(estilo, ac, dk, lt, FT, FX, FN, FE) + cfg.get("css_extra", "")
    def img(p):
        if not p: return ""
        if estilo == "drawing" and not p.startswith(("http", "data:")):
            d = desenho(str(pathlib.Path(base_dir, p.replace("file://", "")).resolve()))
            if d: return d
        q = p if p.startswith(("http", "file:", "data:")) else pathlib.Path(base_dir, p).resolve().as_uri()
        return q
    out = []
    for i, s in enumerate(slides, 1):
        t = s.get("tipo", "texto")
        fundo = s.get("fundo") or ("destaque" if t == "cta" else ("escuro" if i % 2 else "claro"))
        if estilo == "tweet": fundo = "escuro" if cfg.get("tweet_escuro") else "claro"
        ch = f'<div class="chapeu">{E(s["chapeu"])}</div>' if s.get("chapeu") else ""
        extra, cls = "", ""
        if t == "capa":
            body = f'{ch}<h1>{hl(s.get("titulo"))}</h1>'
            if s.get("foto"):
                cls = " comfoto"; body = f'{ch}<h1 style="font-size:{s.get("tamanho", 130)}px">{hl(s.get("titulo"))}</h1>'
                extra = f'<div class="foto"><img src="{img(s["foto"])}"></div><div style="position:absolute;left:80px;bottom:160px;width:440px"><p class="sub">{E(s.get("sub"))}</p><div class="swipe">Arrasta pro lado →</div></div>'
            else:
                body += (f'<p class="sub">{E(s.get("sub"))}</p>' if s.get("sub") else "") + '<div class="swipe">Arrasta pro lado →</div>'
        elif t == "lista":
            its = "".join(f'<div class="item"><i>{k}</i><div><b>{E(a[0] if isinstance(a, list) else a)}</b>' + (f'<span>{E(a[1])}</span>' if isinstance(a, list) and len(a) > 1 else "") + '</div></div>' for k, a in enumerate(s.get("itens", []), 1))
            body = f'{ch}<h2>{hl(s.get("titulo"))}</h2><div class="itens">{its}</div>'
        elif t == "chat":
            body = f'{ch}<h2>{hl(s.get("titulo"))}</h2><div class="chat"><div class="eu">{E(s.get("pergunta"))}</div><div class="ia">{E(s.get("resposta"))}</div></div>' + (f'<div class="nota">{E(s["nota"])}</div>' if s.get("nota") else "")
        elif t == "comparacao":
            a, b = s.get("a", ["Antes"]), s.get("b", ["Depois"])
            col = lambda L, c: f'<div class="{c}"><h3>{E(L[0])}</h3>' + "".join(f"<p>{E(x)}</p>" for x in L[1:]) + "</div>"
            body = f'{ch}<h2>{hl(s.get("titulo"))}</h2><div class="cmp">{col(a, "a")}{col(b, "b")}</div>' + (f'<div class="conc">{E(s["conclusao"])}</div>' if s.get("conclusao") else "")
        elif t == "numero":
            body = f'{ch}<div class="big">{E(s.get("numero"))}</div><h2 style="margin-top:20px">{hl(s.get("titulo"))}</h2>' + (f'<p class="txt">{E(s["texto"])}</p>' if s.get("texto") else "")
        elif t == "resumo":
            body = f'{ch}<h2>{hl(s.get("titulo", "Resumo"))}</h2><ul class="check">' + "".join(f"<li>{E(x)}</li>" for x in s.get("itens", [])) + "</ul>"
        elif t == "cta":
            body = (f'<div class="big" style="font-size:220px">{E(s["numero"])}</div>' if s.get("numero") else "") + f'<h2>{hl(s.get("titulo"))}</h2>' + (f'<p class="txt">{E(s["texto"])}</p>' if s.get("texto") else "")
            body += f'<div class="caixa"><small>{E(s.get("acao", "Comenta"))}</small><strong>{E(s.get("palavra", ""))}</strong><p>{E(s.get("depois", ""))}</p></div>'
        else:
            body = f'{ch}<h2>{hl(s.get("titulo"))}</h2>' + (f'<p class="txt">{E(s["texto"])}</p>' if s.get("texto") else "")
        if estilo == "tweet":
            nome = E(cfg.get("nome") or cfg.get("arroba", "").lstrip("@"))
            av = cfg.get("avatar") or cfg.get("foto_perfil")
            avh = f'<img src="{img(av)}">' if av else E((nome or "?")[:1].upper())
            body = f'<div class="tw"><div class="twh"><div class="av">{avh}</div><div><b>{nome}<i>✓</i></b><span>{arroba}</span></div></div>{body}</div>'
        if estilo == "jornal":
            nm = E(cfg.get("jornal_nome") or ("O Diário de " + (cfg.get("nome") or cfg.get("arroba", "").lstrip("@") or "Hoje")))
            ed = E(s.get("edicao") or cfg.get("jornal_edicao") or "Edição de hoje")
            pg = E(s.get("pagina") or f"Pág. {i}")
            body = f'{body}'
            mast = f'<div class="mast"><div class="l1"><span>{arroba}</span><span>{ass}</span></div><div class="nm">{nm}</div><div class="l2"><span>{ed}</span><span>{pg}</span></div></div>'
            if s.get("carimbo"):
                c1 = E(s["carimbo"]).replace("|", "<br>")
                extra += f'<div class="carimbo">{c1}' + (f'<small>{E(s.get("carimbo_data"))}</small>' if s.get("carimbo_data") else "") + '</div>'
        else:
            mast = ""
        if H == 1920:
            cls += " story"; body = body.replace("Arrasta pro lado →", "Toca pra continuar →"); extra = extra.replace("Arrasta pro lado →", "Toca pra continuar →").replace("bottom:160px", "bottom:320px")
        out.append(f'<section class="s {fundo}{cls}" id="s{i}"><div class="bar"></div><div class="top"><span>{ass}</span><span>{arroba}</span></div>{mast}<div class="c">{body}</div>{extra}<div class="prog"><div class="t"><span style="width:{i / T * 100:.1f}%"></span></div><b>{i}/{T}</b></div></section>')
    return f'<!doctype html><html lang="pt-BR"><head><meta charset="utf-8"><link href="https://fonts.googleapis.com/css2?{fam}&display=swap" rel="stylesheet"><style>{css}</style></head><body>{"".join(out)}</body></html>', T, estilo, H

def render(html_path, outdir, T, H=1350):
    try:
        from playwright.sync_api import sync_playwright
        with sync_playwright() as p:
            exe = next((x for x in ["/opt/pw-browsers/chromium"] if os.path.exists(x)), None)
            b = p.chromium.launch(**({"executable_path": exe} if exe else {}))
            pg = b.new_page(viewport={"width": 1080, "height": H})
            pg.goto(pathlib.Path(html_path).resolve().as_uri()); pg.wait_for_timeout(1500)
            pg.evaluate("document.fonts.ready")
            for i in range(1, T + 1):
                pg.locator(f"#s{i}").screenshot(path=os.path.join(outdir, f"slide-{i}.png"))
            b.close(); return "playwright"
    except Exception as e:
        err = str(e)
    node = shutil.which("node")
    if node:
        js = f"""const pw=(()=>{{for(const m of ['playwright','/home/claude/.npm-global/lib/node_modules/playwright']){{try{{return require(m)}}catch(e){{}}}}}})();
(async()=>{{const fs=require('fs');const ex=['/opt/pw-browsers/chromium'].find(x=>fs.existsSync(x));
const b=await pw.chromium.launch(ex?{{executablePath:ex}}:{{}});const p=await b.newPage({{viewport:{{width:1080,height:{H}}}}});
await p.goto('{pathlib.Path(html_path).resolve().as_uri()}');await p.waitForTimeout(1500);await p.evaluate(()=>document.fonts.ready);
for(let i=1;i<={T};i++){{await p.locator('#s'+i).screenshot({{path:'{os.path.abspath(outdir)}/slide-'+i+'.png'}});}}await b.close();}})();"""
        r = subprocess.run([node, "-e", js], capture_output=True, text=True)
        if r.returncode == 0: return "node"
    return None

if __name__ == "__main__":
    a = sys.argv[1:]
    if len(a) < 2: print(__doc__); sys.exit(1)
    cfg = json.load(open(a[0], encoding="utf-8")); outdir = a[1]; os.makedirs(outdir, exist_ok=True)
    if "--galeria" in a:
        amostra = [{"tipo": "capa", "chapeu": "Estilo", "titulo": "Seu título *forte* aqui", "sub": "Uma linha de promessa."},
                   {"tipo": "lista", "fundo": "claro", "chapeu": "Passo a passo", "titulo": "3 passos", "itens": [["Primeiro passo", "detalhe curto"], ["Segundo passo", "detalhe curto"], ["Terceiro passo", "detalhe curto"]]},
                   {"tipo": "cta", "titulo": "Quer o *guia*?", "acao": "Comenta", "palavra": "GUIA", "depois": "que eu te mando."}]
        feitos = []
        for e in ESTILOS:
            c2 = dict(cfg, estilo=e, slides=amostra); d2 = os.path.join(outdir, e); os.makedirs(d2, exist_ok=True)
            doc, T, _, H = build(c2, os.path.dirname(os.path.abspath(a[0])))
            hp = os.path.join(d2, "carrossel.html"); open(hp, "w", encoding="utf-8").write(doc)
            if render(hp, d2, T, H): feitos.append(e)
        try:
            from PIL import Image, ImageDraw
            from PIL import ImageFont
            W = Image.new("RGB", (3 * 360 + 40, len(feitos) * 500 + 20), "#DDDDDD"); dr = ImageDraw.Draw(W)
            try: fnt = ImageFont.truetype(next(p for p in ["/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf", "/System/Library/Fonts/Supplemental/Arial Bold.ttf", "C:/Windows/Fonts/arialbd.ttf"] if os.path.exists(p)), 15)
            except Exception: fnt = None
            for r, e in enumerate(feitos):
                dr.text((12, r * 500 + 10), f"{r + 1}. {e.upper()} · {ESTILOS[e]}"[:120], fill="#111111", font=fnt)
                for k in range(3):
                    W.paste(Image.open(os.path.join(outdir, e, f"slide-{k + 1}.png")).convert("RGB").resize((360, 450)), (10 + k * 370, r * 500 + 36))
            W.save(os.path.join(outdir, "galeria-estilos.png")); print(f"Galeria pronta: {os.path.join(outdir, 'galeria-estilos.png')}")
        except Exception:
            print(f"Estilos gerados em {outdir}: " + ", ".join(feitos))
        sys.exit(0)
    doc, T, estilo, H = build(cfg, os.path.dirname(os.path.abspath(a[0])))
    hp = os.path.join(outdir, "carrossel.html"); open(hp, "w", encoding="utf-8").write(doc)
    if "--so-html" in a: print(f"HTML pronto: {hp}"); sys.exit(0)
    how = render(hp, outdir, T, H)
    if how: print(f"{T} slides gerados em {outdir} · estilo: {estilo}")
    else: print(f"Sem navegador para gerar imagens. HTML pronto em {hp}: abra no navegador e faça print de cada slide, ou monte no Canva."); sys.exit(2)
