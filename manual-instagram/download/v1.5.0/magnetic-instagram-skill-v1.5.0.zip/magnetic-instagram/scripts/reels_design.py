#!/usr/bin/env python3
"""reels_design.py - Reels em motion design (MP4 1080x1920) feito em código com o HyperFrames (HeyGen, Apache 2.0).
Sem IA de vídeo: a animação é uma página e o HyperFrames grava quadro a quadro. Zero crédito de vídeo.

uso:
  python3 reels_design.py reels.json saida/            # gera saida/reels-design.mp4, saida/capa.jpg e saida/previa.jpg
  python3 reels_design.py reels.json saida/ --previa   # versão rascunho rápida + previa.jpg (um quadro por cena)
  python3 reels_design.py --checar                     # confere Node, FFmpeg e navegador e instala o que faltar

reels.json:
{
  "arroba": "@fulano", "cor_destaque": "#D15434", "cor_escura": "#0F0D0C", "cor_clara": "#F7F4F1",
  "fundo": "escuro" | "claro", "fonte_titulo": "Barlow Condensed", "fonte_texto": "Plus Jakarta Sans",
  "audio": "minha-voz.mp3",            # opcional: a voz da pessoa (ou trilha). Sem isso, sai sem som (música entra no Instagram)
  "cenas": [
    {"tipo": "gancho", "chapeu": "Pra quem vende serviço", "titulo": "Seu cliente|espera *3 horas*|pela resposta?"},
    {"tipo": "lista", "chapeu": "Um agente de IA faz", "itens": ["Responde em segundos", "Marca o horário", "Salva no CRM"]},
    {"tipo": "numero", "chapeu": "Em setembro", "valor": 21.5, "casas": 1, "prefixo": "", "sufixo": " bi",
     "frase": "de automações rodaram no HighLevel", "fonte": "Fonte: HighLevel, out/2026"},
    {"tipo": "antes_depois", "titulo": "A mesma agência", "antes": {"rotulo": "Antes", "itens": ["5 ferramentas", "Print no WhatsApp"]},
     "depois": {"rotulo": "Depois", "itens": ["1 sistema", "Aprovação por link"]}, "resultado": "*-10 h* por semana"},
    {"tipo": "passos", "titulo": "Agente no WhatsApp|em *3 passos*", "passos": [{"texto": "Conecta o número", "imagem": "print1.png"}, ...]},
    {"tipo": "mito_verdade", "afirmacoes": [{"texto": "IA substitui o atendente", "selo": "MITO", "explicacao": "Ela tira o repetitivo."}, ...]},
    {"tipo": "grafico", "titulo": "Leads por mês", "barras": [{"rotulo": "Jul", "valor": 40}, ...], "frase": "*3x* em 90 dias", "fonte": "..."},
    {"tipo": "imagem", "chapeu": "Na prática", "titulo": "O painel|do *cliente*", "imagens": ["tela1.png", "tela2.png"]},
    {"tipo": "contagem", "chapeu": "Aula ao vivo", "evento": "Agentes de IA na prática", "data": "Quinta, 20h", "de": 3},
    {"tipo": "cta", "chapeu": "Quer o passo a passo?", "palavra": "AGENTE", "depois": "que eu te mando no direct."}
    # sem palavra-chave: {"tipo": "cta", "chamada": "Compartilha com|quem *precisa*", "depois": "e me segue pra mais conteúdo."}
  ]
}
Regras: a 1ª cena é o gancho e a última é a cta. "*palavra*" pinta com a cor de destaque e "|" quebra a linha.
Cada cena pode ter "duracao" (segundos); sem isso, o tempo sai do tamanho do texto. Número, dado e fonte: só reais.
"""
import json, sys, os, re, html, shutil, subprocess, tempfile, glob, base64

AQUI = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, AQUI)
try:
    from carrossel import fontes_embutidas
except Exception:
    def fontes_embutidas(f): return ""

HF_VERSAO = "0.8.158"
GSAP_VERSAO = "3.14.2"
MOTOR = os.path.join(os.path.expanduser("~"), ".magnetic-reels")
W, H = 1080, 1920

def E(t): return html.escape(str(t or ""))
def hl(t): return re.sub(r"\*(.+?)\*", r"<em>\1</em>", E(t))
def linhas(t): return "<br>".join(hl(x) for x in (t if isinstance(t, list) else str(t).split("|")))
def palavras(*ts): return sum(len(re.findall(r"\w+", str(t or ""))) for t in ts)

# ------------------------------------------------------------------ motor (Node + HyperFrames + navegador)
def sh(cmd, **kw):
    return subprocess.run(cmd, capture_output=True, text=True, **kw)

def preparar_motor(verboso=True):
    """Instala uma vez o HyperFrames e o GSAP numa pasta da pessoa (~/.magnetic-reels). Devolve (bin, env) ou erro legível."""
    erros = []
    node, npm = shutil.which("node"), shutil.which("npm") or shutil.which("npm.cmd")
    if not node or not npm:
        return None, None, "Falta o Node.js 22 ou mais novo. Baixe em nodejs.org (versão LTS), instale e rode de novo."
    v = sh([node, "-v"]).stdout.strip().lstrip("v").split(".")[0]
    if v.isdigit() and int(v) < 22:
        return None, None, f"O Node.js instalado é a versão {v}. Precisa ser 22 ou mais novo (nodejs.org)."
    ff = shutil.which("ffmpeg")
    if not ff:
        return None, None, ("Falta o FFmpeg. No Windows: winget install Gyan.FFmpeg. No Mac: brew install ffmpeg. "
                            "No Linux: sudo apt install ffmpeg. Depois rode de novo.")
    os.makedirs(MOTOR, exist_ok=True)
    binp = os.path.join(MOTOR, "node_modules", ".bin", "hyperframes" + (".cmd" if os.name == "nt" else ""))
    gs = os.path.join(MOTOR, "node_modules", "gsap", "dist", "gsap.min.js")
    if not (os.path.exists(binp) and os.path.exists(gs)):
        if verboso: print("Instalando o motor de vídeo (uma vez só, 1 a 3 minutos)...", flush=True)
        if not os.path.exists(os.path.join(MOTOR, "package.json")):
            open(os.path.join(MOTOR, "package.json"), "w").write('{"name":"magnetic-reels","private":true}')
        r = sh([npm, "i", "--silent", f"hyperframes@{HF_VERSAO}", f"gsap@{GSAP_VERSAO}"], cwd=MOTOR, timeout=900)
        if not os.path.exists(binp):
            return None, None, "Não consegui instalar o HyperFrames pelo npm: " + (r.stderr or r.stdout)[-400:]
    env = dict(os.environ, HYPERFRAMES_SKIP_SKILLS="1", HYPERFRAMES_NO_TELEMETRY="1", DO_NOT_TRACK="1")
    if not env.get("HYPERFRAMES_BROWSER_PATH"):
        ok = sh([binp, "browser", "ensure"], cwd=MOTOR, env=env, timeout=600)
        if ok.returncode != 0:
            cand = [shutil.which(x) for x in ("chrome-headless-shell", "google-chrome", "google-chrome-stable", "chromium", "chromium-browser")]
            cand += glob.glob("/opt/pw-browsers/chromium_headless_shell-*/*/headless_shell")
            cand += glob.glob(os.path.expanduser("~/.cache/ms-playwright/chromium_headless_shell-*/*/headless_shell"))
            cand += [r"C:\Program Files\Google\Chrome\Application\chrome.exe", r"C:\Program Files (x86)\Google\Chrome\Application\chrome.exe",
                     "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome"]
            achou = next((c for c in cand if c and os.path.exists(c)), None)
            if not achou:
                return None, None, "Falta um navegador pra gravar o vídeo. Instale o Google Chrome e rode de novo."
            env["HYPERFRAMES_BROWSER_PATH"] = achou
    return binp, env, None

# ------------------------------------------------------------------ cenas
def dur_padrao(c):
    t = c.get("tipo")
    if c.get("duracao"): return float(c["duracao"])
    base = {"gancho": 2.6, "lista": 1.6, "numero": 3.6, "antes_depois": 4.6, "passos": 1.4, "mito_verdade": 1.0,
            "grafico": 4.4, "imagem": 3.4, "contagem": 4.2, "cta": 3.4}.get(t, 3.0)
    n = len(c.get("itens") or c.get("passos") or c.get("afirmacoes") or [])
    por = {"lista": 1.2, "passos": 1.8, "mito_verdade": 2.6}.get(t, 0)
    leitura = palavras(c.get("chapeu"), c.get("titulo"), c.get("frase"), c.get("depois")) / 3.2
    return round(max(base + n * por, leitura + 1.4), 2)

def img(p, base, proj, nome):
    src = p if os.path.isabs(p) else os.path.join(base, p)
    ext = os.path.splitext(src)[1].lower() or ".png"
    destino = os.path.join(proj, "midia", nome + ext); os.makedirs(os.path.dirname(destino), exist_ok=True)
    shutil.copy(src, destino); return "midia/" + nome + ext

def cena_html(i, c, t0, d, base, proj):
    """Devolve (html, js) da cena. Todo tempo do js é absoluto (t0 + atraso)."""
    tp, s = c.get("tipo"), f"s{i}"
    cap = f'<div class="tag">{hl(c["chapeu"])}</div>' if c.get("chapeu") else ""
    J = []
    def a(sel, de, para, at, dur=.5, ease="power3.out", extra=""):
        J.append(f'tl.fromTo("#{s} {sel}",{de},{{...{para},duration:{dur},ease:"{ease}"{extra}}},{t0 + at:.2f});')
    corpo = ""
    if tp == "gancho":
        corpo = f'{cap}<div class="big">{linhas(c.get("titulo"))}</div>'
        a(".tag", "{opacity:0,y:30}", "{opacity:1,y:0}", .1, .4)
        a(".big", "{opacity:0,y:90,scale:.92}", "{opacity:1,y:0,scale:1}", .25, .65, "back.out(1.6)")
        J.append(f'tl.fromTo("#{s} .big em",{{scale:1}},{{scale:1.06,duration:.25,yoyo:true,repeat:3,ease:"sine.inOut"}},{t0 + 1.1:.2f});')
    elif tp == "lista":
        its = c.get("itens", [])
        tit = f'<div class="mid">{linhas(c["titulo"])}</div>' if c.get("titulo") else ""
        li = "".join(f'<div class="item it{k}{" ult" if k == len(its) - 1 and c.get("destaque_ultimo", True) and len(its) > 2 else ""}"><b>{k + 1}</b><span>{hl(x)}</span></div>' for k, x in enumerate(its))
        corpo = f'{cap}{tit}<div class="lista">{li}</div>'
        a(".tag", "{opacity:0,y:30}", "{opacity:1,y:0}", .1, .4); a(".mid", "{opacity:0,y:40}", "{opacity:1,y:0}", .2, .5)
        passo = (d - 1.2) / max(1, len(its))
        for k in range(len(its)):
            a(f".it{k}", "{opacity:0,x:-140}", "{opacity:1,x:0}", .6 + k * passo, .5)
    elif tp == "numero":
        v, casas = float(c.get("valor", 0)), int(c.get("casas", 0))
        fonte = f'<div class="fonte">{E(c["fonte"])}</div>' if c.get("fonte") else ""
        corpo = (f'{cap}<div class="num"><span class="pre">{E(c.get("prefixo", ""))}</span><span class="n">0</span>'
                 f'<span class="suf">{E(c.get("sufixo", ""))}</span></div><div class="mid">{hl(c.get("frase", ""))}</div>{fonte}')
        a(".tag", "{opacity:0,y:30}", "{opacity:1,y:0}", .1, .4); a(".num", "{opacity:0,scale:.7}", "{opacity:1,scale:1}", .2, .5, "back.out(1.7)")
        J.append(f'(()=>{{const o={{v:0}},el=document.querySelector("#{s} .n");tl.to(o,{{v:{v},duration:{min(2.0, d - 1.6):.2f},ease:"power2.out",'
                 f'onUpdate:()=>{{el.textContent=o.v.toLocaleString("pt-BR",{{minimumFractionDigits:{casas},maximumFractionDigits:{casas}}})}}}},{t0 + .3:.2f});}})();')
        a(".mid", "{opacity:0,y:40}", "{opacity:1,y:0}", min(2.2, d - 1.2), .5); a(".fonte", "{opacity:0}", "{opacity:1}", min(2.5, d - 1), .4)
    elif tp == "antes_depois":
        A, B = c.get("antes", {}), c.get("depois", {})
        la = "".join(f"<li>{hl(x)}</li>" for x in A.get("itens", [])); lb = "".join(f"<li>{hl(x)}</li>" for x in B.get("itens", []))
        tit = f'<div class="mid">{linhas(c["titulo"])}</div>' if c.get("titulo") else ""
        res = f'<div class="res">{hl(c["resultado"])}</div>' if c.get("resultado") else ""
        corpo = (f'{cap}{tit}<div class="ad"><div class="col an"><h4>{E(A.get("rotulo", "Antes"))}</h4><ul>{la}</ul></div>'
                 f'<div class="col dp"><h4>{E(B.get("rotulo", "Depois"))}</h4><ul>{lb}</ul></div></div>{res}')
        a(".mid", "{opacity:0,y:40}", "{opacity:1,y:0}", .1, .5); a(".an", "{opacity:0,x:-120}", "{opacity:1,x:0}", .5, .6)
        a(".dp", "{opacity:0,x:120}", "{opacity:1,x:0}", 1.5, .6); a(".res", "{opacity:0,scale:.8}", "{opacity:1,scale:1}", min(2.8, d - 1.2), .5, "back.out(1.8)")
    elif tp == "passos":
        ps = c.get("passos", [])
        bl = ""
        for k, p in enumerate(ps):
            p = p if isinstance(p, dict) else {"texto": p}
            im = f'<img src="{img(p["imagem"], base, proj, f"{s}p{k}")}">' if p.get("imagem") else ""
            bl += f'<div class="passo ps{k}"><b>{k + 1}</b><span>{hl(p["texto"])}</span>{im}</div>'
        corpo = f'{cap}<div class="mid">{linhas(c.get("titulo", ""))}</div><div class="passos">{bl}</div>'
        a(".tag", "{opacity:0,y:30}", "{opacity:1,y:0}", .1, .4); a(".mid", "{opacity:0,y:40}", "{opacity:1,y:0}", .2, .5)
        passo = (d - 1.2) / max(1, len(ps))
        for k in range(len(ps)):
            a(f".ps{k}", "{opacity:0,x:160}", "{opacity:1,x:0}", .7 + k * passo, .55)
            a(f".ps{k} img", "{opacity:0,x:200,rotation:6}", "{opacity:1,x:0,rotation:-2}", .9 + k * passo, .6, "back.out(1.4)")
    elif tp == "mito_verdade":
        af = c.get("afirmacoes", [])
        bl = ""
        for k, x in enumerate(af):
            mito = str(x.get("selo", "")).upper().startswith("M")
            bl += (f'<div class="mv mv{k}"><div class="frase">{hl(x["texto"])}</div><div class="selo {"mito" if mito else "verd"}">{"MITO" if mito else "VERDADE"}</div>'
                   f'<div class="exp">{hl(x.get("explicacao", ""))}</div></div>')
        corpo = f'{cap}<div class="mvs">{bl}</div>'
        a(".tag", "{opacity:0,y:30}", "{opacity:1,y:0}", .1, .4)
        passo = (d - .6) / max(1, len(af))
        for k in range(len(af)):
            t = .4 + k * passo
            a(f".mv{k}", "{opacity:0,y:60}", "{opacity:1,y:0}", t, .45)
            a(f".mv{k} .selo", "{opacity:0,scale:2.4,rotation:-18}", "{opacity:1,scale:1,rotation:-8}", t + .9, .35, "back.out(2)")
            a(f".mv{k} .exp", "{opacity:0}", "{opacity:1}", t + 1.3, .4)
            if k < len(af) - 1:
                J.append(f'tl.to("#{s} .mv{k}",{{opacity:0,y:-60,duration:.35}},{t0 + t + passo - .4:.2f});')
    elif tp == "grafico":
        br = c.get("barras", []); mx = max([float(b["valor"]) for b in br] or [1])
        bars = "".join(f'<div class="b b{k}"><u>{E(b.get("mostrar", b["valor"]))}</u><i></i><span>{E(b["rotulo"])}</span></div>' for k, b in enumerate(br))
        fonte = f'<div class="fonte">{E(c["fonte"])}</div>' if c.get("fonte") else ""
        corpo = f'{cap}<div class="mid">{linhas(c.get("titulo", ""))}</div><div class="graf">{bars}</div><div class="res">{hl(c.get("frase", ""))}</div>{fonte}'
        a(".mid", "{opacity:0,y:40}", "{opacity:1,y:0}", .1, .5)
        for k in range(len(br)):
            a(f".b{k} i", "{height:'0%'}", f"{{height:'{float(br[k]['valor']) / mx * 82:.1f}%'}}", .5 + k * .3, .7, "power2.out")
            a(f".b{k} u", "{opacity:0}", "{opacity:1}", 1.0 + k * .3, .3)
        a(".res", "{opacity:0,scale:.8}", "{opacity:1,scale:1}", min(.9 + len(br) * .3 + .4, d - 1.2), .5, "back.out(1.8)")
        a(".fonte", "{opacity:0}", "{opacity:1}", min(1.8 + len(br) * .3, d - .8), .4)
    elif tp == "imagem":
        ims = c.get("imagens", [])[:3]
        tit = f'<div class="mid">{linhas(c["titulo"])}</div>' if c.get("titulo") else ""
        fig = "".join(f'<img class="tela t{k}" src="{img(p, base, proj, f"{s}i{k}")}">' for k, p in enumerate(ims))
        corpo = f'{cap}{tit}<div class="telas n{len(ims)}">{fig}</div>'
        a(".tag", "{opacity:0,y:30}", "{opacity:1,y:0}", .1, .4); a(".mid", "{opacity:0,y:40}", "{opacity:1,y:0}", .2, .5)
        for k in range(len(ims)):
            a(f".t{k}", "{opacity:0,y:200,rotation:0}", f"{{opacity:1,y:0,rotation:{[-3, 3, -1][k]}}}", .6 + k * .5, .6, "back.out(1.3)")
        J.append(f'tl.fromTo("#{s} .telas",{{scale:1}},{{scale:1.06,duration:{d:.2f},ease:"none"}},{t0:.2f});')
    elif tp == "contagem":
        de = int(c.get("de", 3))
        nums = "".join(f'<span class="cd c{k}">{de - k}</span>' for k in range(de))
        corpo = (f'{cap}<div class="mid">{hl(c.get("evento", ""))}</div><div class="cds">{nums}</div>'
                 f'<div class="res">{hl(c.get("data", ""))}</div>')
        a(".tag", "{opacity:0,y:30}", "{opacity:1,y:0}", .1, .4); a(".mid", "{opacity:0,y:40}", "{opacity:1,y:0}", .2, .5)
        passo = (d - 2.0) / max(1, de)
        for k in range(de):
            t = .7 + k * passo
            a(f".c{k}", "{opacity:0,scale:2.2}", "{opacity:1,scale:1}", t, .35, "power4.out")
            if k < de - 1: J.append(f'tl.to("#{s} .c{k}",{{opacity:0,scale:.6,duration:.25}},{t0 + t + passo - .25:.2f});')
        a(".res", "{opacity:0,y:40}", "{opacity:1,y:0}", d - 1.2, .45)
    elif tp == "cta":
        pal = str(c.get("palavra", ""))
        if not pal:   # chamada sem palavra-chave (ex.: "Compartilha com quem precisa e me segue")
            corpo = f'{cap}<div class="big" style="font-size:132px">{linhas(c.get("chamada", "Me segue pra mais"))}</div><div class="sub">{hl(c.get("depois", ""))}</div>'
            a(".tag", "{opacity:0,y:30}", "{opacity:1,y:0}", .1, .4); a(".big", "{opacity:0,scale:.85}", "{opacity:1,scale:1}", .25, .55, "back.out(1.7)")
            a(".sub", "{opacity:0,y:20}", "{opacity:1,y:0}", .9, .4)
            return f'<div id="{s}" class="sc clip" data-start="{t0:.2f}" data-duration="{d:.2f}" data-track-index="1"><div class="in">{corpo}</div></div>', J
        letras = "".join(f'<span class="l l{k}">{E(ch)}</span>' for k, ch in enumerate(pal))
        corpo = (f'{cap}<div class="cta">Comenta</div><div class="cta"><span class="kw">{letras}</span></div>'
                 f'<div class="sub">{hl(c.get("depois", ""))}</div>')
        a(".tag", "{opacity:0,y:30}", "{opacity:1,y:0}", .1, .4); a(".cta", "{opacity:0,scale:.8}", "{opacity:1,scale:1}", .25, .45, "back.out(1.8)")
        for k in range(len(pal)):
            a(f".l{k}", "{opacity:0,y:-120}", "{opacity:1,y:0}", .6 + k * .07, .35, "bounce.out")
        a(".sub", "{opacity:0,y:20}", "{opacity:1,y:0}", .9 + len(pal) * .07, .4)
    else:
        raise SystemExit(f"Tipo de cena desconhecido: {tp}")
    # saída suave da cena (menos a última)
    return f'<div id="{s}" class="sc clip" data-start="{t0:.2f}" data-duration="{d:.2f}" data-track-index="1"><div class="in">{corpo}</div></div>', J

def montar(c, base, proj):
    ac, dk, lt = c.get("cor_destaque", "#D15434"), c.get("cor_escura", "#0F0D0C"), c.get("cor_clara", "#F7F4F1")
    claro = c.get("fundo", "escuro") == "claro"
    bg, fg = (lt, dk) if claro else (dk, lt)
    FT, FX = c.get("fonte_titulo", "Barlow Condensed"), c.get("fonte_texto", "Plus Jakarta Sans")
    cenas, t, tempos, htmls, js = c["cenas"], 0.0, [], [], []
    durs = [dur_padrao(x) for x in cenas]
    aud = ""
    if c.get("audio"):
        src = c["audio"] if os.path.isabs(c["audio"]) else os.path.join(base, c["audio"])
        ff = shutil.which("ffprobe")
        if ff:
            r = sh([ff, "-v", "error", "-show_entries", "format=duration", "-of", "csv=p=0", src])
            try:
                ad = float(r.stdout.strip())
                if ad > sum(durs): durs[-1] += ad - sum(durs)
            except ValueError: pass
    for i, (x, d) in enumerate(zip(cenas, durs)):
        h, j = cena_html(i, x, t, d, base, proj)
        htmls.append(h); js += j; tempos.append((t, d)); t += d
    total = round(t, 2)
    if c.get("audio"):
        aud = f'<audio class="clip" src="{img(c["audio"], base, proj, "audio")}" data-start="0" data-duration="{total}" data-volume="1"></audio>'
    css = f"""
*{{margin:0;padding:0;box-sizing:border-box}}
html,body{{width:{W}px;height:{H}px;overflow:hidden;background:{bg}}}
#root{{position:relative;width:{W}px;height:{H}px;font-family:'{FX}',sans-serif;color:{fg};background:{bg}}}
.sc{{position:absolute;left:0;right:0;top:250px;height:1250px;padding:0 90px;display:flex;align-items:center}}
.in{{width:100%}}
em{{font-style:normal;color:{ac}}}
.tag{{font:800 32px '{FX}';letter-spacing:.14em;color:{ac};text-transform:uppercase;margin-bottom:22px}}
.big{{font:900 172px/.9 '{FT}';text-transform:uppercase;letter-spacing:-.01em}}
.mid{{font:900 112px/.95 '{FT}';text-transform:uppercase;margin-bottom:30px}}
.lista{{display:grid;gap:34px;margin-top:20px}}
.item{{display:flex;align-items:center;gap:32px;font:800 62px/1.15 '{FX}'}}
.item b{{flex:none;width:118px;height:118px;border-radius:30px;background:{ac};color:#fff;font:900 76px/118px '{FT}';text-align:center}}
.item.ult{{color:{ac}}}
.num{{font:900 300px/.9 '{FT}';color:{ac};letter-spacing:-.02em;transform-origin:left center}}
.num .pre,.num .suf{{font-size:150px}}
.fonte{{font:500 30px '{FX}';opacity:.65;margin-top:26px}}
.ad{{display:grid;grid-template-columns:1fr 1fr;gap:26px;margin-top:10px}}
.col{{border-radius:34px;padding:40px 34px;min-height:560px}}
.col h4{{font:900 76px '{FT}';text-transform:uppercase;margin-bottom:22px}}
.col ul{{list-style:none;display:grid;gap:22px;font:700 44px/1.2 '{FX}'}}
.an{{background:{"#e6ded7" if claro else "#2a2522"};color:{"#7a6f68" if claro else "#9b918a"}}}
.an li{{text-decoration:line-through;text-decoration-thickness:4px}}
.dp{{background:{ac};color:#fff}}
.res{{display:inline-block;margin-top:40px;background:{fg};color:{bg};font:900 92px/1 '{FT}';text-transform:uppercase;padding:22px 34px;border-radius:24px}}
.res em{{color:{ac}}}
.passos{{display:grid;gap:30px}}
.passo{{display:flex;align-items:center;gap:28px;font:800 56px/1.15 '{FX}'}}
.passo b{{flex:none;width:104px;height:104px;border-radius:50%;background:{ac};color:#fff;font:900 66px/104px '{FT}';text-align:center}}
.passo span{{flex:1}}
.passo img{{flex:none;width:300px;border-radius:22px;box-shadow:0 24px 60px #00000055}}
.mvs{{position:relative;height:900px}}
.mv{{position:absolute;inset:0}}
.mv .frase{{font:900 110px/.95 '{FT}';text-transform:uppercase}}
.selo{{display:inline-block;margin-top:40px;font:900 120px '{FT}';padding:6px 34px;border:12px solid;border-radius:24px}}
.selo.mito{{color:#E0453A;border-color:#E0453A}}.selo.verd{{color:#2FA866;border-color:#2FA866}}
.exp{{font:600 52px/1.3 '{FX}';margin-top:40px;opacity:.9}}
.graf{{display:flex;align-items:flex-end;gap:30px;height:620px;margin-top:20px}}
.b{{flex:1;height:100%;display:flex;flex-direction:column;justify-content:flex-end;align-items:center;gap:14px;position:relative}}
.b i{{display:block;width:100%;height:0;background:{ac};border-radius:18px 18px 6px 6px}}
.b u{{text-decoration:none;font:900 54px '{FT}'}}
.b span{{font:700 36px '{FX}';opacity:.8}}
.telas{{position:relative;height:880px;display:flex;justify-content:center;align-items:center}}
.tela{{position:absolute;width:640px;border-radius:30px;box-shadow:0 30px 80px #00000066}}
.telas.n2 .t0{{left:20px;top:40px;width:560px}}.telas.n2 .t1{{right:20px;top:220px;width:560px}}
.telas.n3 .t0{{left:0;top:0;width:500px}}.telas.n3 .t1{{right:0;top:160px;width:500px}}.telas.n3 .t2{{left:180px;top:380px;width:500px}}
.cds{{position:relative;height:420px}}
.cd{{position:absolute;left:0;font:900 420px/1 '{FT}';color:{ac}}}
.cta{{font:900 150px/.95 '{FT}';text-transform:uppercase}}
.kw{{display:inline-block;background:{ac};color:#fff;padding:8px 34px;border-radius:24px;margin-top:20px}}
.l{{display:inline-block}}
.sub{{font:500 50px/1.35 '{FX}';margin-top:34px;opacity:.85}}
.hd{{position:absolute;top:150px;left:90px;font:700 32px '{FX}';opacity:.6}}
.bar{{position:absolute;left:90px;bottom:330px;height:10px;width:0;background:{ac};border-radius:6px}}
"""
    js_txt = "\n".join(js)
    pagina = f"""<!doctype html>
<html lang="pt-BR" data-resolution="portrait"><head><meta charset="UTF-8"><meta name="viewport" content="width={W}, height={H}">
<script src="gsap.min.js"></script><style>{fontes_embutidas([FT, FX])}{css}</style></head><body>
<div id="root" data-composition-id="main" data-start="0" data-duration="{total}" data-width="{W}" data-height="{H}">
<div class="hd clip" data-start="0" data-duration="{total}" data-track-index="0">{E(c.get("arroba", ""))}</div>
{"".join(htmls)}
<div class="bar clip" data-start="0" data-duration="{total}" data-track-index="2"></div>
{aud}
</div>
<script>
const tl = gsap.timeline({{ paused: true }});
{js_txt}
tl.fromTo(".bar",{{width:0}},{{width:{W - 180},duration:{total},ease:"none"}},0);
window.__timelines["main"] = tl;
tl.seek(0);
</script></body></html>"""
    return pagina, tempos, total

def main():
    if "--checar" in sys.argv:
        b, env, err = preparar_motor()
        print(err or "Tudo pronto: Node, FFmpeg, navegador e HyperFrames."); sys.exit(1 if err else 0)
    args = [a for a in sys.argv[1:] if not a.startswith("--")]
    if len(args) < 2: print(__doc__); sys.exit(1)
    previa = "--previa" in sys.argv
    cfg, out = args[0], os.path.abspath(args[1])
    c = json.load(open(cfg, encoding="utf-8")); base = os.path.dirname(os.path.abspath(cfg))
    if c["cenas"][0].get("tipo") != "gancho" or c["cenas"][-1].get("tipo") != "cta":
        raise SystemExit("A 1ª cena precisa ser 'gancho' e a última 'cta'.")
    binp, env, err = preparar_motor()
    if err: raise SystemExit(err)
    proj = os.path.join(out, "projeto"); os.makedirs(proj, exist_ok=True)
    shutil.copy(os.path.join(MOTOR, "node_modules", "gsap", "dist", "gsap.min.js"), proj)
    pagina, tempos, total = montar(c, base, proj)
    open(os.path.join(proj, "index.html"), "w", encoding="utf-8").write(pagina)
    open(os.path.join(proj, "hyperframes.json"), "w").write('{"name":"reels-design"}')
    if total > 60: print(f"Aviso: o Reels ficou com {total:.0f} s. Mire em 15 a 45 s: corte cenas ou itens.")
    mp4 = os.path.join(out, "reels-rascunho.mp4" if previa else "reels-design.mp4")
    r = sh([binp, "render", "-o", mp4, "-q", "draft" if previa else "high"], cwd=proj, env=env, timeout=1800)
    if not os.path.exists(mp4):
        raise SystemExit("O vídeo não foi gerado:\n" + (r.stdout + r.stderr)[-1500:])
    ff = shutil.which("ffmpeg")
    quadros = []
    for k, (t0, d) in enumerate(tempos):
        q = os.path.join(out, f".q{k}.png")
        sh([ff, "-loglevel", "error", "-y", "-ss", f"{t0 + d * .8:.2f}", "-i", mp4, "-frames:v", "1", "-vf", "scale=360:-1", q])
        if os.path.exists(q): quadros.append(q)
    try:
        from PIL import Image
        ims = [Image.open(q) for q in quadros]
        if ims:
            fol = Image.new("RGB", (360 * len(ims), ims[0].height), "white")
            for k, im in enumerate(ims): fol.paste(im, (k * 360, 0))
            fol.save(os.path.join(out, "previa.jpg"), quality=85)
    except Exception: pass
    for q in quadros: os.remove(q)
    if not previa:
        sh([ff, "-loglevel", "error", "-y", "-ss", f"{tempos[0][0] + tempos[0][1] * .8:.2f}", "-i", mp4, "-frames:v", "1", os.path.join(out, "capa.jpg")])
    print(f"OK: {mp4} · {total:.1f} s · {len(tempos)} cenas{' · rascunho' if previa else ''}")

if __name__ == "__main__":
    main()
