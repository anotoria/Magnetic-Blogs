# Opção 7: Stories do dia

Stories não são um feed menor. O feed é como estranhos acham a pessoa; os Stories são como quem já segue decide se vale comprar dela. Só seguidores veem, então o trabalho aqui é profundidade, não alcance.

## Entrada

Pergunte: "O que está acontecendo hoje?" (um atendimento, uma entrega, um bastidor, um resultado, um erro). Use a configuração pra saber a oferta, a chamada e se ela aparece no vídeo.

## O formato do dia (3 a 7 telas)

```
1       ABERTURA   algo acontecendo hoje, com rosto ou mão aparecendo.
2-3     O MEIO     o conteúdo: o processo, o resultado, o erro.
4       O PEDIDO   uma figurinha: enquete, caixa de perguntas, quiz ou link.
5       O FECHO    a resposta, o resultado ou o gancho de amanhã.
```

O pedido vai na tela 4, não na 7: a cada toque menos gente fica.

## Formato especial: O Diário (resumo do que saiu ontem)

Quando a pessoa quiser lembrar os seguidores do que foi postado no dia anterior, troque o visual: as telas viram páginas de um jornal impresso com o nome do jornal dela no topo (ex.: "O Diário Magnético"). Funciona porque quebra o padrão dos Stories de sempre e dá cara de notícia ao post de ontem.

```
1  CAPA          manchete do post de ontem + a capa do post como "foto da matéria" + carimbo SAIU ONTEM
2  PÁG. 2        "O que mudou, em N notas": os pontos do post, só com dados que estão na legenda
3  CADERNO       o segundo post do dia (se houve), em formato de matéria ou passo a passo
4  CLASSIFICADOS "Procura-se..." com a solução e a palavra-chave: "Tratar com: comenta PALAVRA no post de ontem"
```

Depois do jornal, volte ao visual normal pra falar do que sai hoje. Pra gerar as telas: `carrossel.py` com `"estilo": "jornal"` e `"formato": "story"` (veja a referência do carrossel). Nunca invente número ou resultado na manchete: use só o que está no post.

## As figurinhas e pra que servem

| Figurinha | Função | Quando usar |
|---|---|---|
| **Enquete** | o toque mais barato que existe | quer volume de resposta |
| **Caixa de perguntas** | colher as palavras exatas do público | quer ideias de conteúdo ou objeções, palavra por palavra |
| **Quiz** | ensinar deixando errar | tem um erro comum no nicho |
| **Controle deslizante** | termômetro | nada importante; diversão |
| **Link** | o único lugar clicável além da bio | tem um destino real |
| **Contagem regressiva** | prazo que dá pra seguir | lançamento, live, fechamento de turma |
| **Adicione o seu** | alcance fora dos seguidores, às vezes | pergunta que qualquer um do nicho responde |

A caixa de perguntas é a mais subestimada: cada resposta vira legenda, gancho de Reels (fórmula 16) ou abertura de conversa nas palavras do público. Sugira guardar as respostas.

## Regras

- **Rosto ou mão na primeira tela.** Texto em fundo colorido é pulado.
- **Uma ideia por tela.** Ninguém lê parágrafo em Story.
- **Texto no meio** (1080×1920): nada acima de 250 px nem abaixo de 1600 px.
- **Fale com uma pessoa.** "Você", no singular.
- **Não repostar o próprio post sem comentário.** Se for apontar pra um post, diga o que aconteceu e por que vale voltar lá.
- **Venda nos Stories:** 3 telas de contexto, 1 de oferta, 1 de prova. Vende mais que post de feed e não custa alcance.
- **Eles agem primeiro, depois você responde.** Resposta automática por palavra-chave é recurso oficial; mandar direct em massa pra quem não interagiu dá bloqueio.
- Se ela não aparece no vídeo (configuração), use tela do computador, mãos, bastidor e texto.

## Entrega

```
STORIES · terça · 5 telas

1  [selfie andando]        "Terceiro pedido de reembolso do ano. Mesmo motivo."
2  [gravação de tela]      a cláusula, destacada
3  [falando]               "Aprovação é sentimento. Entrega é data."
4  [enquete]               "Já perdeu dinheiro com aprovação atrasada?"  Sim / Ainda não
5  [texto na foto]         "Responde aqui que eu te mando a cláusula."

Depois: responda cada pessoa que votou "Sim". Esse é o funil inteiro.
```

Nada é postado pela skill. A pessoa grava e posta.
