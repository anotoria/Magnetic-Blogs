# Opção 12, tipo 2: Reels em motion design (feito em código)

Um Reels vertical (MP4 1080×1920, 15 a 45 s) em que tudo é design animado: gancho grande, lista que entra item por item, número subindo, gráfico, antes e depois, mito ou verdade, telas do sistema e a palavra-chave caindo letra por letra no final. Não usa IA de vídeo: a animação é escrita como uma página e o HyperFrames (projeto aberto da HeyGen, licença Apache 2.0) grava quadro a quadro. Por isso não gasta crédito de vídeo e não tem marca d'água.

**O aviso honesto (diga isso se a pessoa perguntar ou esperar outra coisa):** código faz texto, tela, número, gráfico e design. Não faz pessoa nem cena realista. Se ela quiser aparecer, ela grava, e o vídeo dela entra como cena com telas por cima (veja "O vídeo da pessoa", no fim).

## Antes da primeira vez

Rode `python3 scripts/reels_design.py --checar`. Ele confere e instala sozinho o motor de vídeo (uma vez só, de 1 a 3 minutos). Se faltar algo que ele não instala, explique em português simples e com um passo por vez:

- **Node.js 22 ou mais novo:** baixar em nodejs.org (botão LTS), instalar com "Avançar" até o fim e abrir o Claude de novo.
- **FFmpeg:** Windows `winget install Gyan.FFmpeg`; Mac `brew install ffmpeg`; Linux `sudo apt install ffmpeg`. Ofereça rodar o comando pela pessoa se o ambiente deixar.
- **Navegador:** o Google Chrome instalado já serve.

Se o ambiente não deixar instalar nada (só chat, sem computador): entregue o roteiro cena a cena e diga que o vídeo sai quando ela usar o Claude no computador (Claude Code ou o app com uma pasta conectada).

## Entrada (uma pergunta por vez, só o que faltar)

1. **Sobre o quê?** Um roteiro da opção 3, um carrossel, um post do Radar ou só o tema. Se for só o tema, escreva o roteiro antes pelas regras da opção 3 (3 ganchos, nota, o melhor).
2. **Palavra-chave do comentário** e o que a pessoa recebe. Se a chamada for "compartilha e me segue", a cena `cta` vai sem `palavra` e com `chamada` (ex.: "Compartilha com|quem *precisa*") e `depois` ("e me segue pra mais conteúdo.").
3. **Imagens:** prints do sistema, telas do carrossel ou fotos da pessoa, se ela quiser que apareçam.
4. **Áudio (opcional):** a voz dela gravada no celular (o mais forte) ou nada. Música entra direto no Instagram, na hora de postar, com as músicas liberadas pela plataforma.

Cores, fontes, fundo (escuro ou claro) e @ vêm da configuração. Não copie o visual de um Reels de referência: use sempre a marca da pessoa.

## Os tipos de cena

| Tipo | Pra que serve | Campos |
|---|---|---|
| `gancho` | 1ª cena, sempre. Frase grande que bate na tela | `chapeu`, `titulo` |
| `lista` | 2 a 5 itens entrando um por vez (o último ganha destaque) | `chapeu`, `titulo` (opcional), `itens` |
| `numero` | número que sobe do zero + o que ele significa | `chapeu`, `valor`, `casas`, `prefixo`, `sufixo`, `frase`, `fonte` |
| `antes_depois` | tela dividida, antes riscado em cinza e depois na cor | `titulo`, `antes` {`rotulo`, `itens`}, `depois` {...}, `resultado` |
| `passos` | 2 a 4 passos, cada um com um print entrando de lado | `titulo`, `passos` [{`texto`, `imagem`}] |
| `mito_verdade` | afirmações uma por vez com selo MITO ou VERDADE | `afirmacoes` [{`texto`, `selo`, `explicacao`}] |
| `grafico` | barras crescendo + a frase do resultado | `titulo`, `barras` [{`rotulo`, `valor`}], `frase`, `fonte` |
| `imagem` | 1 a 3 telas entrando com zoom lento | `chapeu`, `titulo`, `imagens` |
| `contagem` | convite com contagem regressiva (live, aula, lançamento) | `chapeu`, `evento`, `data`, `de` |
| `cta` | última cena, sempre. A palavra caindo letra por letra (ou a chamada de compartilhar) | `chapeu`, `palavra`, `depois` ou `chamada`, `depois` |

Modelos prontos de roteiro (escolha pelo assunto):
- **Lista animada:** gancho → lista de 3 a 5 → cta. Ex.: "5 erros que fazem você perder cliente no [nicho]".
- **Número que choca:** gancho → numero → lista curta do que isso significa → cta.
- **Antes e depois:** gancho → antes_depois → cta.
- **Passo a passo com prints:** gancho → passos (com as telas) → cta.
- **Mito ou verdade:** gancho → mito_verdade com 3 afirmações → cta.
- **Resultado em gráfico:** gancho → grafico → cta.
- **Convite:** gancho → contagem → cta.

## Regras do texto

- **Gancho em até 2 segundos de leitura**, nas fórmulas de `references/ganchos.md` e no padrão de ganchos da pessoa. Nada de "hoje vou falar sobre".
- Uma ideia por cena. Títulos com no máximo 3 linhas curtas (`|` quebra a linha, `*palavra*` pinta de destaque).
- **Nunca invente número, dado, cliente ou resultado.** Número só com fonte real no campo `fonte`. Gráfico de exemplo leva "Dados de exemplo" na fonte. Sem dado real, use outro tipo de cena.
- O tempo de cada cena sai do tamanho do texto. Pra mudar, use `"duracao"` na cena. Mire em 15 a 45 s no total.
- Conteúdo importante fica longe das bordas de cima e de baixo (a ferramenta já respeita a área segura do Instagram).
- Tire a cara de IA (`references/escrita.md`).

## Como gerar

1. Mostre o roteiro cena a cena (tipo + texto) e espere o "ok".
2. Monte o `reels.json` (formato completo no topo de `scripts/reels_design.py`) numa pasta de trabalho, com as imagens ao lado.
3. Rode a prévia: `python3 scripts/reels_design.py reels.json saida/ --previa`. Sai um rascunho rápido (`reels-rascunho.mp4`) e a `previa.jpg` (um quadro de cada cena). Olhe a prévia: texto cortado, sobreposto ou pequeno demais se corrige antes.
4. Mande a prévia pra pessoa e peça ajustes em português ("gancho maior", "troca a cor", "tira o terceiro item").
5. Com o "pode gerar", rode sem `--previa`. Sai `reels-design.mp4` em qualidade de entrega e a `capa.jpg`.
6. Entregue o vídeo com a legenda pronta (regras da opção 4, no máximo 5 hashtags) e ofereça agendar (opção 10, `type: reel`, um vídeo só).

Se der erro, a ferramenta mostra o motivo. Os mais comuns: faltou Node ou FFmpeg (veja "Antes da primeira vez"), imagem com nome errado no JSON, ou a internet bloqueou a primeira instalação (rode de novo quando tiver internet).

## Molde da marca

Depois do primeiro Reels aprovado, salve o `reels.json` dele como molde no histórico da pessoa (cores, fundo, fontes e o tipo de roteiro que ela gostou). Nos próximos, só troque texto e tema: os Reels saem com a mesma cara.

## O vídeo da pessoa

- **Só legenda animada no vídeo dela:** use a Mesa de Corte, se ela tiver.
- **Vídeo dela com telas, números e títulos por cima:** se o plugin oficial do HyperFrames estiver instalado (`/hyperframes`), use o modo `/talking-head-recut`. Senão, monte um Reels em motion design com as telas e diga onde encaixar o vídeo dela no CapCut.

## Créditos

HyperFrames: HeyGen, licença Apache 2.0 (github.com/heygen-com/hyperframes). Mantenha o crédito se alguém perguntar como o vídeo foi feito.

Nada é postado sem a pessoa dizer "sim".
