#!/usr/bin/env python3
"""legenda.py - checa a legenda do Instagram antes de postar.

Mostra primeiro o que o feed exibe antes do "...mais" (uns 125 caracteres) e depois checa:
tamanho, primeira linha, algo concreto no começo, hashtags (máximo 5), um pedido só, link no texto,
palavra-chave da chamada, termos de busca, excesso de emoji, caracteres invisíveis e vícios de texto de IA.

uso:
  python3 legenda.py legenda.txt
  python3 legenda.py legenda.txt --busca "atendimento no whatsapp,agenda de clinica" --palavra GUIA
  python3 legenda.py legenda.txt --limpar > legenda-limpa.txt     # só remove caracteres invisíveis
"""
import re, sys, textwrap, unicodedata

def sa(t): return "".join(c for c in unicodedata.normalize("NFD", t.lower()) if unicodedata.category(c) != "Mn")
INVIS = re.compile("[​‌‍⁠﻿­᠎‪-‮]")
EMOJI = re.compile("[\U0001F300-\U0001FAFF☀-➿\U0001F1E6-\U0001F1FF]")
TAG = re.compile(r"(?<![\w&])#([\wÀ-ÿ]+)")
URL = re.compile(r"(https?://|www\.|\b[\w-]+\.(com|com\.br|net|io|app|link|me|br)\b)", re.I)
GENERICAS = {"viral", "fyp", "foryou", "foryoupage", "explore", "explorepage", "instagood", "reels", "reelsinstagram", "trend", "trending", "viralizar", "engajamento", "seguidores", "likes"}
PEDIDOS = {"comentar": r"\bcoment[ae]\b|\bcomenta\b|\bdigite\b|\bescreve\b", "salvar": r"\bsalv[ae]\b", "compartilhar": r"\bcompartilh[ae]\b|\bmanda (pra|para)\b|\benvia (pra|para)\b",
           "seguir": r"\bme segue\b|\bsiga\b|\bsegue (o|a|meu|minha|a gente)\b", "link": r"\blink na bio\b|\bclique\b|\bclica\b|\bacesse\b", "direct": r"\bchama no direct\b|\bme chama\b|\bmanda (um )?direct\b|\bmanda dm\b"}
VICIOS = ["no mundo de hoje", "nos dias atuais", "voce ja parou pra pensar", "vale ressaltar", "e importante destacar", "virada de chave", "alavancar", "potencializar",
          "desbloquear", "mergulhar", "game changer", "no final do dia", "sem mais delongas", "e sobre isso", "jornada", "robusto", "descubra como", "ola, pessoal", "fala, galera"]

def main():
    a = sys.argv[1:]
    if not a: print(__doc__); sys.exit(1)
    txt = open(a[0], encoding="utf-8").read()
    if "--limpar" in a: sys.stdout.write(INVIS.sub("", txt)); return
    busca = [x.strip() for x in a[a.index("--busca") + 1].split(",") if x.strip()] if "--busca" in a else []
    palavra = a[a.index("--palavra") + 1].strip() if "--palavra" in a else ""
    t = txt.strip(); s = sa(t); res = []
    def ok(n, m): res.append(("OK", n, m))
    def av(n, m): res.append(("ATENÇÃO", n, m))
    def rp(n, m): res.append(("REPROVADO", n, m))

    vis = t.replace("\n", " ")[:125]
    print("\n  O QUE O FEED MOSTRA")
    print("  +" + "-" * 56 + "+")
    for l in textwrap.wrap(vis, 54) or [""]: print(f"  | {l:<54} |")
    print("  +" + "-" * 44 + " ... mais +\n")

    n = len(t)
    (ok if n <= 2200 else rp)("TAMANHO", f"{n} / 2200 caracteres")
    l1 = t.split("\n")[0].strip()
    if not l1: rp("PRIMEIRA LINHA", "começa com linha vazia")
    elif l1.startswith("#") or EMOJI.match(l1): rp("PRIMEIRA LINHA", "começa com hashtag ou emoji; comece pela frase")
    elif re.match(r"(oi|ola|fala|e ai|bom dia|boa tarde|boa noite)\b", sa(l1)): rp("PRIMEIRA LINHA", "começa com cumprimento; comece pelo gancho ou pelo pedido")
    elif len(l1) > 125: av("PRIMEIRA LINHA", f"{len(l1)} caracteres: o feed corta em 125 no meio da ideia")
    else: ok("PRIMEIRA LINHA", f"{len(l1)} caracteres, cabe antes do corte")
    conc = bool(re.search(r"\d|r\$|%", vis, re.I)) or bool(re.search(r"(?<!^)(?<![.!?]\s)\b[A-ZÁÉÍÓÚÂÊÔÃÕÇ][a-záéíóúâêôãõç]{2,}", vis[1:]))
    (ok if conc else av)("COMEÇO CONCRETO", "tem número, valor ou nome no trecho visível" if conc else "nenhum número, valor ou nome no trecho visível")
    tags = TAG.findall(t); gen = [x for x in tags if sa(x) in GENERICAS]
    if len(tags) > 5: rp("HASHTAGS", f"{len(tags)} hashtags. O Instagram aceita no máximo 5 desde dez/2025")
    elif gen: av("HASHTAGS", f"{len(tags)} hashtags, genéricas que não dizem nada: " + " ".join("#" + x for x in gen))
    else: ok("HASHTAGS", f"{len(tags)} hashtag(s)" + (": " + " ".join("#" + x for x in tags) if tags else ""))
    tipos = [k for k, p in PEDIDOS.items() if re.search(p, s)]
    if not tipos: av("UM PEDIDO", "nenhum pedido: diga o que a pessoa deve fazer (a chamada)")
    elif len(tipos) == 1: ok("UM PEDIDO", f"um pedido: {tipos[0]}")
    elif len(tipos) == 2: av("UM PEDIDO", f"dois pedidos ({', '.join(tipos)}). O ideal é um só; se manter o segundo, que seja bem mais fraco")
    else: rp("UM PEDIDO", f"{len(tipos)} pedidos ({', '.join(tipos)}). Dois pedidos valem zero: fique com um")
    if URL.search(t): rp("LINK", "tem link no texto. Legenda não é clicável: link vai na bio, no direct ou nos Stories")
    else: ok("LINK", "sem link no texto")
    if palavra:
        pw = re.search(r"\b" + re.escape(palavra) + r"\b", t)
        if " " in palavra: rp("PALAVRA-CHAVE", "a palavra tem espaço; tem que ser uma palavra só")
        elif not pw: rp("PALAVRA-CHAVE", f"a palavra {palavra} não aparece exatamente assim na legenda")
        else: ok("PALAVRA-CHAVE", f"{palavra} aparece igual à automação")
    if busca:
        tem = [b for b in busca if sa(b) in s]
        falta = [b for b in busca if b not in tem]
        (ok if not falta else av)("BUSCA", f"{len(tem)}/{len(busca)} termos no texto" + (f". Falta: {', '.join(falta)}" if falta else ""))
    em = len(EMOJI.findall(t)); dens = em / max(1, n) * 100
    (ok if dens <= 4 else av)("EMOJI", f"{em} emoji(s), {dens:.1f} a cada 100 caracteres" + ("" if dens <= 4 else ": use como pontuação, não enfeite"))
    inv = len(INVIS.findall(txt))
    (ok if not inv else rp)("INVISÍVEIS", "nenhum caractere invisível" if not inv else f"{inv} caractere(s) invisível(is). Rode com --limpar")
    vic = [v for v in VICIOS if v in s]
    trav = t.count("—")
    if vic or trav > 2: av("CARA DE IA", (f"expressões: {', '.join(vic)}" if vic else "") + (f"{'; ' if vic else ''}{trav} travessões" if trav > 2 else ""))
    else: ok("CARA DE IA", "nenhum vício comum encontrado")

    for st, nm, m in res: print(f"  {st:<10} {nm:<16} {m}")
    rep = sum(1 for r in res if r[0] == "REPROVADO"); at = sum(1 for r in res if r[0] == "ATENÇÃO")
    print("\n  RESULTADO: " + ("PRONTA" if not rep and not at else "PRONTA, decida os pontos de atenção" if not rep else f"{rep} item(ns) reprovado(s): corrija antes de postar"))

if __name__ == "__main__": main()
