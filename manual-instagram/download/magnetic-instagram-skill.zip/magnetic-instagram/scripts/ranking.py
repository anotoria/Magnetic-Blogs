#!/usr/bin/env python3
"""ranking.py - ranqueia carrosseis (curtidas+comentarios) e/ou Reels (reproducoes) pelo quanto passaram da mediana do PROPRIO perfil.
uso: python3 ranking.py posts.json [--formato carrossel|reels|ambos] [--dias 60] [--min 1.3] [--tema "a,b"] [--top 10] [--eu seu_arroba] > ranking.json"""
import json, sys, statistics, collections, datetime, unicodedata, re
def sa(t): return "".join(c for c in unicodedata.normalize("NFD", (t or "").lower()) if unicodedata.category(c) != "Mn")
a = sys.argv[1:]
def arg(k, d): return a[a.index(k) + 1] if k in a else d
fmt, dias, lo, top = arg("--formato", "ambos"), int(arg("--dias", 60)), float(arg("--min", 1.3)), int(arg("--top", 10))
eu = arg("--eu", "").lstrip("@").lower()
tema = [sa(x.strip()) for x in arg("--tema", "").split(",") if x.strip()]
raw = json.load(open(a[0], encoding="utf-8")); itens = raw.get("items", raw) if isinstance(raw, dict) else raw
itens = [x for x in itens if not x.get("error") and x.get("ownerUsername")]
def eng(p): return max(0, p.get("likesCount") or 0) + (p.get("commentsCount") or 0)
def plays(p): return p.get("videoPlayCount") or p.get("videoViewCount") or 0
def is_car(p): return p.get("type") == "Sidecar"
def is_reel(p): return p.get("type") == "Video"
por = collections.defaultdict(list)
for p in itens: por[p["ownerUsername"]].append(p)
corte = (datetime.datetime.utcnow() - datetime.timedelta(days=dias)).strftime("%Y-%m-%d")
res = {"carrosseis": [], "reels": []}; meus = {"carrosseis": [], "reels": []}; perfis, pouco = [], []
def base(u, p, m, val, med, cap):
    return {"perfil": u, "multiplo": round(m, 2), "valor": int(val), "mediana": int(med), "data": p["timestamp"][:10],
            "link": f"https://www.instagram.com/{'reel' if is_reel(p) else 'p'}/{p['shortCode']}/", "legenda": re.sub(r"\s+", " ", cap)[:300],
            **({"duracao_s": round(p.get("videoDuration") or 0)} if is_reel(p) else {})}
for u, ps in por.items():
    if len(ps) < 8: pouco.append(u); continue
    cars, reels = [p for p in ps if is_car(p)], [p for p in ps if is_reel(p)]
    med_e = statistics.median([eng(p) for p in ps]) or 1
    med_r = statistics.median([plays(p) for p in reels]) if len(reels) >= 4 else None
    perfis.append({"perfil": u, "posts": len(ps), "pct_carrossel": round(100 * len(cars) / len(ps)), "pct_reels": round(100 * len(reels) / len(ps)),
                   "mediana": int(med_e), "mediana_reproducoes": int(med_r) if med_r else None})
    for p in ps:
        if (p.get("timestamp") or "")[:10] < corte: continue
        cap = p.get("caption") or ""
        if is_car(p) and fmt in ("carrossel", "ambos"): k, val, med = "carrosseis", eng(p), med_e
        elif is_reel(p) and fmt in ("reels", "ambos") and med_r: k, val, med = "reels", plays(p), med_r
        else: continue
        r = base(u, p, val / (med or 1), val, med, cap)
        if u.lower() == eu: meus[k].append(r); continue
        if tema and not any(t in sa(cap) for t in tema): continue
        if r["multiplo"] >= lo: res[k].append(r)
for k in res: res[k].sort(key=lambda r: -r["multiplo"]); meus[k].sort(key=lambda r: -r["multiplo"])
perfis.sort(key=lambda r: -r["mediana"])
print(json.dumps({"data_rodada": datetime.date.today().isoformat(), "formato": fmt, "posts_lidos": len(itens),
    "carrosseis_comparados": sum(1 for p in itens if is_car(p)), "reels_comparados": sum(1 for p in itens if is_reel(p)),
    "carrosseis": res["carrosseis"][:top], "reels": res["reels"][:top],
    "meus": {k: [m for m in meus[k] if m["multiplo"] >= 1][:2] for k in meus},
    "perfis": perfis, "perfis_ignorados": pouco}, ensure_ascii=False, indent=1))
