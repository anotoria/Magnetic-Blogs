#!/usr/bin/env python3
"""pagina.py - monta a pagina do Radar personalizada.
uso: python3 pagina.py ranking.json pagina.json > radar.html
pagina.json = {"arroba":"@fulano","nicho":"...","cor_destaque":"#D15434","cor_escura":"#0F0D0C","cor_clara":"#F7F4F1",
 "fonte_titulo":"Barlow Condensed","fonte_texto":"Plus Jakarta Sans",
 "achados":[["titulo","texto"],...3], "moldar":{"<link>":"como moldar em 1-2 frases"}, "ganchos":{"<link do reels>":"gancho dos 3 primeiros segundos"}, "focos":{"perfil":"foco em poucas palavras"}}"""
import json, sys, html, math
R = json.load(open(sys.argv[1], encoding="utf-8")); C = json.load(open(sys.argv[2], encoding="utf-8"))
E = lambda x: html.escape(str(x or ""))
def n(x): return f"{int(x):,}".replace(",", ".")
def d(s): return f"{s[8:10]}/{s[5:7]}" if s else ""
def mult(x): return str(x).replace(".", ",") + "×"
ac, dk, lt = C.get("cor_destaque", "#D15434"), C.get("cor_escura", "#111111"), C.get("cor_clara", "#F7F5F2")
ft, fb = C.get("fonte_titulo", "Barlow Condensed"), C.get("fonte_texto", "Plus Jakarta Sans")
gf = "https://fonts.googleapis.com/css2?family=" + ft.replace(" ", "+") + ":wght@700;900&family=" + fb.replace(" ", "+") + ":wght@400;600;800&display=swap"
def linhas(lista, rotulo_val):
    if not lista: return ""
    mx = math.log10(max([c["multiplo"] for c in lista] + [2]) + 1)
    out = ""
    for i, c in enumerate(lista, 1):
        mold = C.get("moldar", {}).get(c["link"]); gan = C.get("ganchos", {}).get(c["link"])
        extra = (f'<div class="mold"><b>Gancho:</b> “{E(gan)}”</div>' if gan else "") + (f'<div class="mold"><b>Como moldar:</b> {E(mold)}</div>' if mold else "")
        w = max(4, round(100 * math.log10(c["multiplo"] + 1) / mx))
        out += f'''<tr><td class="num">{i}</td><td><a href="{E(c['link'])}" target="_blank" rel="noopener">@{E(c['perfil'])}</a><div class="cap">{E(c['legenda'][:150])}…</div>{extra}</td>
<td class="mult"><div class="bar"><span style="width:{w}%"></span></div><b>{mult(c['multiplo'])}</b></td><td class="num">{n(c.get('valor', c.get('engajamento', 0)))}</td><td class="num">{n(c['mediana'])}</td><td class="num">{d(c['data'])}</td></tr>'''
    return f'''<div class="tbl"><table><thead><tr><th class="num">#</th><th>Perfil, assunto e como moldar</th><th>Vezes a média</th><th class="num">{rotulo_val}</th><th class="num">Média do perfil</th><th class="num">Data</th></tr></thead><tbody>{out}</tbody></table></div>'''
tab_car = linhas(R.get("carrosseis", []), "Curtidas + coment.")
tab_reel = linhas(R.get("reels", []), "Reproduções")
achados = "".join(f'<div class="find{" lead" if i == 0 else ""}"><h3>{E(t)}</h3><p>{E(x)}</p></div>' for i, (t, x) in enumerate(C.get("achados", [])[:3]))
M = R.get("meus", []); M = (M.get("carrosseis", []) + M.get("reels", [])) if isinstance(M, dict) else M
M.sort(key=lambda m: -m["multiplo"])
meus = "".join(f'<li><a href="{E(m["link"])}" target="_blank" rel="noopener"><b>{mult(m["multiplo"])} a sua média</b></a> · {"Reels" if "/reel/" in m["link"] else "Carrossel"} · {d(m["data"])}<div class="cap">{E(m["legenda"][:150])}…</div></li>' for m in M[:3])
def tag(p): return '<span class="pill hot">mais carrossel</span>' if p["pct_carrossel"] >= 40 else ('<span class="pill">quase só Reels</span>' if p["pct_carrossel"] < 10 else "")
perfis = "".join(f'<tr><td><a href="https://www.instagram.com/{E(p["perfil"])}/" target="_blank" rel="noopener">@{E(p["perfil"])}</a></td><td>{E(C.get("focos",{}).get(p["perfil"],""))}</td><td class="num">{p["posts"]}</td><td class="num">{p["pct_carrossel"]}%</td><td class="num">{p.get("pct_reels","")}%</td><td class="num">{n(p["mediana"])}</td><td>{tag(p)}</td></tr>' for p in R.get("perfis", []))
dr = R.get("data_rodada", ""); dr = f"{dr[8:10]}/{dr[5:7]}/{dr[:4]}" if dr else ""
print(f'''<title>Radar {E(C.get("arroba",""))}</title>
<link rel="stylesheet" href="{gf}">
<style>
:root{{--bg:{lt};--surface:#FFFFFF;--ink:{dk};--muted:color-mix(in srgb,{dk} 62%,{lt});--line:color-mix(in srgb,{dk} 12%,{lt});--accent:{ac};--accent-soft:color-mix(in srgb,{ac} 14%,{lt});--bar:color-mix(in srgb,{dk} 8%,{lt})}}
@media (prefers-color-scheme:dark){{:root:not([data-theme="light"]){{--bg:{dk};--surface:color-mix(in srgb,{dk} 88%,#fff);--ink:{lt};--muted:color-mix(in srgb,{lt} 65%,{dk});--line:color-mix(in srgb,{lt} 14%,{dk});--accent-soft:color-mix(in srgb,{ac} 22%,{dk});--bar:color-mix(in srgb,{lt} 12%,{dk});color-scheme:dark}}}}
:root[data-theme="dark"]{{--bg:{dk};--surface:color-mix(in srgb,{dk} 88%,#fff);--ink:{lt};--muted:color-mix(in srgb,{lt} 65%,{dk});--line:color-mix(in srgb,{lt} 14%,{dk});--accent-soft:color-mix(in srgb,{ac} 22%,{dk});--bar:color-mix(in srgb,{lt} 12%,{dk});color-scheme:dark}}
body{{background:var(--bg);color:var(--ink);font:15px/1.55 "{fb}",system-ui,sans-serif}}
.wrap{{max-width:1040px;margin:0 auto;padding:32px 16px 56px;display:grid;gap:40px}}
.eyebrow{{font-weight:600;font-size:12px;letter-spacing:.12em;text-transform:uppercase;color:var(--accent)}}
h1,h2{{font-family:"{ft}","Arial Narrow",sans-serif;font-weight:900;text-transform:uppercase;line-height:.95;margin:0;text-wrap:balance}}
h1{{font-size:clamp(40px,8vw,72px)}} h2{{font-size:30px;margin-bottom:14px}}
.meta{{color:var(--muted);margin-top:10px}} .meta b{{color:var(--ink)}}
.finds{{display:grid;grid-template-columns:repeat(auto-fit,minmax(260px,1fr));gap:16px}}
.find{{background:var(--surface);border:1px solid var(--line);border-radius:10px;padding:18px}} .find h3{{margin:0 0 6px;font-size:16px}} .find p{{margin:0;color:var(--muted)}}
.find.lead{{border-color:var(--accent);background:var(--accent-soft)}}
.tbl{{overflow-x:auto;background:var(--surface);border:1px solid var(--line);border-radius:10px}}
table{{width:100%;border-collapse:collapse;min-width:680px}}
th{{text-align:left;font-size:11px;letter-spacing:.08em;text-transform:uppercase;color:var(--muted);padding:12px 14px;border-bottom:1px solid var(--line)}}
td{{padding:12px 14px;border-bottom:1px solid var(--line);vertical-align:top}} tr:last-child td{{border-bottom:0}}
.num{{font-variant-numeric:tabular-nums;text-align:right;white-space:nowrap}} th.num{{text-align:right}}
a{{color:var(--ink);font-weight:800;text-decoration-color:var(--accent);text-underline-offset:3px}} a:focus-visible{{outline:2px solid var(--accent);outline-offset:2px}}
.cap{{color:var(--muted);font-size:13px;margin-top:4px;max-width:52ch}} .mold{{font-size:13px;margin-top:6px;max-width:52ch}} .mold b{{color:var(--accent)}}
.mult{{min-width:150px}} .mult b{{font-family:"{ft}",sans-serif;font-size:22px;color:var(--accent)}}
.bar{{height:6px;background:var(--bar);border-radius:3px;margin:6px 0 2px}} .bar span{{display:block;height:100%;background:var(--accent);border-radius:3px}}
.pill{{font-size:12px;padding:2px 8px;border-radius:99px;border:1px solid var(--line);color:var(--muted);white-space:nowrap}} .pill.hot{{border-color:var(--accent);color:var(--accent)}}
ul.mine{{list-style:none;padding:0;margin:0;display:grid;gap:14px}} ul.mine li{{background:var(--surface);border:1px solid var(--line);border-radius:10px;padding:16px}}
.note{{color:var(--muted);font-size:13px;max-width:70ch}}
.cta{{display:grid;grid-template-columns:repeat(auto-fit,minmax(240px,1fr));gap:16px}}
.step{{background:var(--surface);border:1px solid var(--line);border-radius:10px;padding:18px;display:flex;flex-direction:column;gap:8px}}
.step small{{font-size:11px;letter-spacing:.1em;text-transform:uppercase;color:var(--accent);font-weight:800}} .step h3{{margin:0;font-size:17px}} .step p{{margin:0;color:var(--muted);font-size:14px}}
.step a{{margin-top:auto}}
</style>
<div class="wrap">
<header><div class="eyebrow">Radar Magnetic · Carrosséis e Reels · {E(C.get("nicho",""))}</div><h1>Radar {E(C.get("arroba",""))}</h1>
<p class="meta">Rodada de <b>{dr}</b> · <b>{len(R.get("perfis",[]))} perfis</b> · <b>{n(R.get("posts_lidos",0))} posts</b> lidos · <b>{R.get("carrosseis_comparados",0)} carrosséis</b> e <b>{R.get("reels_comparados",0)} Reels</b> comparados com a média de cada perfil</p></header>
{f'<section><h2>O que a rodada mostrou</h2><div class="finds">{achados}</div></section>' if achados else ""}
{f'<section><h2>Carrosséis pra moldar</h2><p class="note">Ordem pelo quanto cada carrossel passou da média de curtidas + comentários do próprio perfil.</p>{tab_car}</section>' if tab_car else ""}
{f'<section><h2>Reels pra moldar</h2><p class="note">Ordem pelo quanto cada Reels passou da média de reproduções do próprio perfil.</p>{tab_reel}</section>' if tab_reel else ""}
{f'<section><h2>Os seus que mais passaram da média</h2><ul class="mine">{meus}</ul></section>' if meus else ""}
<section><h2>Seus perfis de referência</h2><div class="tbl"><table><thead><tr><th>Perfil</th><th>Foco</th><th class="num">Posts lidos</th><th class="num">% carrossel</th><th class="num">% Reels</th><th class="num">Engajamento típico</th><th></th></tr></thead><tbody>{perfis}</tbody></table></div></section>
<section><h2>Transforme isso em renda</h2><p class="note">Esse Radar é um pedaço do método que o Rodrigo Mendes usa com agências na Magnetic Flows.</p><div class="cta">
<div class="step"><small>Primeira renda extra · meta de R$10 mil/mês</small><h3>Revenda CRM, automação e IA</h3><p>Pros negócios da sua cidade, pagando $1 por mês por subconta, sem mensalidade fixa pra começar.</p><a href="https://ghlbrazil.com/" target="_blank" rel="noopener">ghlbrazil.com →</a></div>
<div class="step"><small>Negócio de verdade · meta de R$40 mil/mês</small><h3>Venda recorrência, não horas</h3><p>Comunidade gratuita com mais de 2.000 membros e mais de 119 aulas.</p><a href="https://comunidade.magneticflows.com/" target="_blank" rel="noopener">comunidade.magneticflows.com →</a></div>
<div class="step"><small>Operação em escala · meta de R$200 mil/mês</small><h3>Sistema operacional de IA completo</h3><p>Site, atendimento com IA, conteúdo e vendas num lugar só. Teste grátis por 14 dias.</p><a href="https://rodrigomendesfn.com.br/" target="_blank" rel="noopener">rodrigomendesfn.com.br →</a></div>
</div><p class="note">Os valores são metas de faturamento, não promessa de ganho. O resultado depende do seu trabalho, da sua oferta e do seu mercado.</p></section>
<footer class="note">Radar Magnetic · método Magnetic Flows por Rodrigo Mendes (@rodrigomendesfn). Dados públicos do Instagram coletados pelo Apify; salvamentos e compartilhamentos não são públicos e ficam de fora.</footer>
</div>''')
