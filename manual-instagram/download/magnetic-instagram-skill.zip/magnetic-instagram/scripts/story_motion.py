#!/usr/bin/env python3
"""story_motion.py - gera um Story animado (vídeo MP4 1080x1920, 15 s) chamando pro post do dia,
com efeitos sonoros sincronizados e narração opcional.

uso:
  python3 story_motion.py story.json saida/            # gera saida/story-motion.mp4
  python3 story_motion.py story.json saida/ --previa   # só 5 imagens de prévia (rápido)

story.json:
{
  "arroba": "@fulano", "assinatura": "MARCA",
  "cor_destaque": "#D45333", "cor_escura": "#0E0D0B", "cor_clara": "#F8F4F1",
  "fonte_titulo": "Anton", "fonte_texto": "Plus Jakarta Sans",
  "selo": "POST NOVO NO AR",
  "titulo": ["Seu negócio", "no *topo* do", "Google Maps?"],     # 2 a 3 linhas curtas, *palavra* pinta de destaque
  "apoio": "O Claude te ajuda com *3 prompts*. Tá tudo no post de hoje.",
  "resumo_rotulo": "No post de hoje", "resumo_titulo": "O que você|vai descobrir",
  "imagens": ["slide-1.jpg", "slide-3.jpg", "slide-4.jpg", "slide-7.jpg"],   # 1 a 4 telas do post (4:5); a 1ª é a capa
  "itens": ["Os 3 critérios que o Google usa", "3 prompts pra colar no Claude", "Avaliações no automático"],
  "pedido": "Quer os 3 prompts prontos? Comenta no post:",
  "palavra": "GOOGLE3P",
  "depois": "que eu te mando o guia em PDF com os 3 prompts prontos.",
  "final_rotulo": "Não deixa pra depois", "final_titulo": "Vai lá|*agora*",
  "final_texto": "Entra no meu perfil, abre o *post do Google Maps* e comenta a palavra.",
  "rodape": "IA · CRM · AUTOMAÇÃO",
  "sons": true,
  "narracao": {
    "modo": "nenhuma" | "gratis" | "elevenlabs" | "audio",
    "falas": ["frase da abertura", "frase do resumo", "frase do pedido", "frase do final"],
    "voz": "pm_alex",                            # modo gratis: pm_alex, pm_santa ou pf_dora (Kokoro); se não der, Microsoft ou Piper
    "elevenlabs_chave": "", "elevenlabs_voz": "", # modo elevenlabs (ou variável ELEVENLABS_API_KEY)
    "audios": ["fala1.mp3", "..."]                # modo audio: 4 arquivos (um por cena) ou 1 arquivo só
  }
}
Importante: NADA no vídeo pode pedir "toque aqui" — vídeo de Story não tem nada clicável.
Na palavra falada, escreva como se fala (ex.: "Google três pê"), não como se escreve.
"""
import json, sys, os, re, html, shutil, subprocess, tempfile, base64, urllib.request, tarfile, wave, struct, math, random

AQUI = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, AQUI)
try:
    from carrossel import fontes_embutidas
except Exception:
    def fontes_embutidas(f): return ""

DUR = 15.0
FPS = 30
CENAS = [0.0, 3.2, 8.2, 12.2]          # início de cada cena (abertura, resumo, pedido, final)

def E(t): return html.escape(str(t or ""))
def hl(t): return re.sub(r"\*(.+?)\*", r"<em>\1</em>", E(t))
def linhas(t): return "<br>".join(hl(x) for x in str(t).split("|"))

def img64(p, base):
    p = p if os.path.isabs(p) else os.path.join(base, p)
    ext = os.path.splitext(p)[1].lower().strip(".").replace("jpg", "jpeg")
    return f"data:image/{ext};base64," + base64.b64encode(open(p, "rb").read()).decode()

# --------------------------------------------------------------- HTML animado
def montar_html(c, base):
    ac, dk, lt = c.get("cor_destaque", "#D45333"), c.get("cor_escura", "#0E0D0B"), c.get("cor_clara", "#F8F4F1")
    FT, FX = c.get("fonte_titulo", "Anton"), c.get("fonte_texto", "Plus Jakarta Sans")
    fontes = fontes_embutidas([FT, FX])
    imgs = [img64(p, base) for p in c["imagens"][:4]]
    capa = imgs[0]
    n = len(imgs)
    # trilho do carrossel: divide 4,2 s entre as telas
    if n > 1:
        passos = []
        seg = 100 / (n - 1 + 0.25)
        for i in range(n):
            a = i * seg; b = min(100, a + seg * 0.7)
            passos.append(f"{a:.1f}%,{b:.1f}%{{transform:translateX(-{i*640}px)}}")
        swipe = "@keyframes swipe{" + "".join(passos) + "100%{transform:translateX(-" + str((n - 1) * 640) + "px)}}"
    else:
        swipe = "@keyframes swipe{to{transform:none}}"
    tit = c.get("titulo", ["Post novo"])[:3]
    tam = 158 if max(len(re.sub(r"\*", "", x)) for x in tit) > 9 else 210
    t_lin = "".join(f'<span class="a" style="animation:slam .55s {0.4+i*0.35:.2f}s both">{hl(x)}</span>' for i, x in enumerate(tit))
    fim_tit = 0.4 + (len(tit) - 1) * 0.35
    pal = str(c.get("palavra", "EU QUERO")).upper()
    tam_pal = max(110, min(300, int(900 / max(1, len(pal)) * 1.55)))
    letras = "".join(f'<span class="a" style="animation:drop .4s {8.85+i*0.09:.2f}s both">{E(ch)}</span>' for i, ch in enumerate(pal))
    dig = "".join(f'<b class="a" style="animation:show .01s {10.75+i*0.08:.2f}s both">{E(ch)}</b>' for i, ch in enumerate(pal))
    itens = "".join(f'<div class="chip a" style="animation:left .45s {4.7+i*0.9:.2f}s both"><em>{i+1}</em>{E(x)}</div>' for i, x in enumerate(c.get("itens", [])[:3]))
    track = "".join(f'<img src="{s}">' for s in imgs)
    arroba, assin = E(c.get("arroba", "")), E(c.get("assinatura", ""))
    top = lambda d, cor="": f'<div class="top a" style="animation:up .5s {d}s both;{cor}"><span>{assin}</span><span>{arroba.upper()}</span></div>'
    return f"""<!doctype html><html lang="pt-BR"><head><meta charset="utf-8"><style>{fontes}
:root{{--ink:{dk};--or:{ac};--cr:{lt}}}
*{{margin:0;padding:0;box-sizing:border-box}}
html,body{{width:1080px;height:1920px;overflow:hidden;background:var(--ink)}}
body{{font-family:'{FX}',sans-serif;color:#fff;position:relative}}
em{{font-style:normal;color:var(--or)}}
.scene{{position:absolute;inset:0;overflow:hidden;opacity:0}}
.T{{font-family:'{FT}',sans-serif;text-transform:uppercase;line-height:.95;letter-spacing:1px;font-weight:900}}
.lbl{{font-weight:800;letter-spacing:6px;font-size:30px;color:var(--or);text-transform:uppercase}}
.top{{position:absolute;top:120px;left:80px;right:80px;display:flex;justify-content:space-between;font-weight:700;font-size:22px;letter-spacing:4px;color:rgba(255,255,255,.55)}}
.light .top{{color:rgba(0,0,0,.45)}}
@keyframes sceneIn{{from{{opacity:0}}to{{opacity:1}}}}
@keyframes sceneOut{{from{{opacity:1;transform:none}}to{{opacity:0;transform:translateY(-120px) scale(.96)}}}}
@keyframes slam{{0%{{opacity:0;transform:scale(1.8) rotate(-4deg);filter:blur(14px)}}60%{{opacity:1;transform:scale(.96);filter:blur(0)}}100%{{opacity:1;transform:scale(1)}}}}
@keyframes up{{from{{opacity:0;transform:translateY(70px)}}to{{opacity:1;transform:none}}}}
@keyframes left{{from{{opacity:0;transform:translateX(-90px)}}to{{opacity:1;transform:none}}}}
@keyframes pop{{0%{{opacity:0;transform:scale(.3)}}70%{{opacity:1;transform:scale(1.12)}}100%{{opacity:1;transform:scale(1)}}}}
@keyframes grow{{from{{transform:scaleX(0)}}to{{transform:scaleX(1)}}}}
@keyframes blink{{0%,100%{{opacity:1}}50%{{opacity:.25}}}}
@keyframes pulse{{0%,100%{{transform:scale(1)}}50%{{transform:scale(1.06)}}}}
@keyframes drop{{0%{{opacity:0;transform:translateY(-220px) rotate(-12deg)}}65%{{opacity:1;transform:translateY(16px)}}100%{{opacity:1;transform:none}}}}
@keyframes caret{{0%,49%{{opacity:1}}50%,100%{{opacity:0}}}}
@keyframes show{{to{{opacity:1}}}}
@keyframes zoomBg{{from{{transform:scale(1)}}to{{transform:scale(1.15)}}}}
{swipe}
.a{{opacity:0;animation-fill-mode:both;animation-timing-function:cubic-bezier(.2,.8,.2,1)}}
.glow{{position:absolute;width:1150px;height:1150px;border-radius:50%;background:radial-gradient(circle,{ac}55,transparent 65%)}}
#A{{background:var(--ink);animation:sceneIn .01s 0s both,sceneOut .45s 3.05s forwards ease-in}}
#A .glow{{left:200px;top:700px;animation:zoomBg 3.5s 0s both linear}}
.live{{position:absolute;top:330px;left:80px;display:flex;align-items:center;gap:18px;background:rgba(255,255,255,.08);border:2px solid rgba(255,255,255,.15);padding:18px 30px;border-radius:60px;font-weight:800;font-size:30px;letter-spacing:4px}}
.live i{{width:22px;height:22px;border-radius:50%;background:var(--or);display:block;animation:blink 1s infinite}}
#A h1{{position:absolute;left:76px;right:60px;top:510px;font-size:{tam}px}}
#A h1 span{{display:block}}
#A .bar{{position:absolute;left:80px;top:{510+len(tit)*int(tam*0.95)+50}px;width:560px;height:16px;background:var(--or);transform-origin:left}}
#A p{{position:absolute;left:80px;right:110px;top:{510+len(tit)*int(tam*0.95)+120}px;font-size:52px;line-height:1.25;font-weight:600}}
#B{{background:var(--cr);color:var(--ink);animation:sceneIn .35s 3.2s both,sceneOut .45s 8.05s forwards ease-in}}
#B .lbl{{position:absolute;top:260px;left:80px}}
#B h2{{position:absolute;top:310px;left:80px;font-size:118px}}
.stage{{position:absolute;top:560px;left:0;right:0;height:800px}}
.card{{position:absolute;left:220px;top:0;width:640px;height:800px;border-radius:28px;overflow:hidden;box-shadow:0 40px 80px rgba(0,0,0,.35)}}
.track{{display:flex;height:100%;animation:swipe 4.2s 3.8s both cubic-bezier(.7,0,.2,1)}}
.track img{{width:640px;height:800px;flex:none;object-fit:cover}}
.ghost{{position:absolute;top:40px;width:560px;height:720px;border-radius:26px;background:rgba(0,0,0,.13)}}
.g1{{left:120px;transform:rotate(-7deg)}} .g2{{left:400px;transform:rotate(7deg)}}
.chips{{position:absolute;top:1420px;left:80px;right:80px;display:flex;flex-direction:column;gap:20px}}
.chip{{display:flex;align-items:center;gap:22px;font-size:40px;font-weight:700}}
.chip em{{flex:none;width:62px;height:62px;border-radius:16px;background:var(--or);color:#fff;font-family:'{FT}';font-size:38px;display:flex;align-items:center;justify-content:center}}
#C{{background:linear-gradient(160deg,{ac} 0%,{ac} 50%,{ac}CC 100%);animation:sceneIn .35s 8.2s both,sceneOut .45s 12.05s forwards ease-in}}
#C .lead{{position:absolute;top:300px;left:80px;right:80px;font-size:58px;font-weight:700;line-height:1.2}}
.box{{position:absolute;top:560px;left:80px;right:80px;background:var(--ink);border-radius:36px;padding:56px 60px 60px}}
.word{{display:flex;flex-wrap:wrap;gap:2px;font-family:'{FT}';font-weight:900;font-size:{tam_pal}px;line-height:1;margin-top:10px;color:var(--or)}}
.box small{{display:block;font-size:42px;line-height:1.3;color:rgba(255,255,255,.85);margin-top:18px}}
.cbar{{position:absolute;top:1330px;left:80px;right:80px;background:#fff;border-radius:80px;padding:26px 30px;display:flex;align-items:center;gap:24px;color:#111;box-shadow:0 30px 60px rgba(0,0,0,.25)}}
.av{{width:80px;height:80px;border-radius:50%;background:var(--ink);flex:none}}
.typed{{font-size:46px;font-weight:800;display:flex;align-items:center;position:relative;flex:1}}
.ph{{position:absolute;left:0;color:rgba(0,0,0,.35);font-weight:600;font-size:40px}}
.cur{{width:5px;height:52px;background:var(--or);margin-left:6px;animation:caret .8s infinite}}
.send{{font-weight:800;font-size:38px;color:#3897F0}}
#D{{background:var(--ink);animation:sceneIn .35s 12.2s both}}
#D .glow{{left:-60px;top:640px}}
#D .lbl{{position:absolute;top:290px;left:80px}}
#D h2{{position:absolute;top:375px;left:80px;font-size:180px}}
#D p{{position:absolute;top:765px;left:80px;right:80px;font-size:48px;font-weight:600;line-height:1.3}}
.thumb{{position:absolute;top:960px;left:380px;width:320px;height:400px}}
.thumb img{{width:100%;height:100%;object-fit:cover;border-radius:22px;outline:6px solid var(--or);outline-offset:8px;display:block}}
.thumb span{{position:absolute;top:-34px;left:50%;transform:translateX(-50%);background:var(--or);color:#fff;font-weight:800;font-size:24px;letter-spacing:4px;padding:10px 22px;border-radius:30px;white-space:nowrap}}
.pill{{position:absolute;top:1400px;left:90px;right:90px;text-align:center}}
.pill div{{background:#fff;color:#111;border-radius:80px;padding:30px 20px;font-family:'{FT}';font-weight:900;font-size:{min(72, int(1500/ (9+len(pal))))}px;letter-spacing:2px;text-transform:uppercase}}
.sig{{position:absolute;bottom:215px;left:0;right:0;text-align:center;font-weight:800;font-size:40px;letter-spacing:2px}}
.sig small{{display:block;font-weight:600;font-size:26px;letter-spacing:5px;color:rgba(255,255,255,.5);margin-top:10px}}
</style></head><body>
<section class="scene" id="A"><div class="glow"></div>{top(.1)}
 <div class="live a" style="animation:left .5s .15s both"><i></i>{E(c.get("selo","POST NOVO NO AR"))}</div>
 <h1 class="T">{t_lin}</h1>
 <div class="bar a" style="opacity:1;animation:grow .5s {fim_tit+0.4:.2f}s both cubic-bezier(.7,0,.2,1)"></div>
 <p class="a" style="animation:up .55s {fim_tit+0.65:.2f}s both">{hl(c.get("apoio",""))}</p></section>
<section class="scene light" id="B">{top(3.3)}
 <div class="lbl a" style="animation:left .5s 3.35s both">{E(c.get("resumo_rotulo","No post de hoje"))}</div>
 <h2 class="T a" style="animation:up .55s 3.45s both">{linhas(c.get("resumo_titulo","O que você|vai descobrir"))}</h2>
 <div class="stage"><div class="ghost g1 a" style="animation:show .3s 3.75s both"></div><div class="ghost g2 a" style="animation:show .3s 3.8s both"></div>
 <div class="card a" style="animation:pop .6s 3.5s both"><div class="track">{track}</div></div></div>
 <div class="chips">{itens}</div></section>
<section class="scene" id="C">{top(8.3, "color:rgba(255,255,255,.75)")}
 <div class="lead a" style="animation:up .5s 8.35s both">{hl(c.get("pedido","Comenta no post:"))}</div>
 <div class="box a" style="animation:pop .55s 8.55s both"><div class="lbl" style="color:#fff;opacity:.7">Comenta</div>
  <div class="word" style="animation:pulse 1s 10.2s 2 ease-in-out">{letras}</div>
  <small class="a" style="animation:up .5s 9.6s both">{hl(c.get("depois",""))}</small></div>
 <div class="cbar a" style="animation:up .5s 10s both"><div class="av"></div><div class="typed">
  <span class="ph a" style="opacity:1;animation:sceneOut .01s 10.7s forwards">Adicione um comentário...</span>{dig}<span class="cur"></span></div>
  <span class="send a" style="animation:pop .35s 11.35s both">Publicar</span></div></section>
<section class="scene" id="D"><div class="glow"></div>{top(12.3)}
 <div class="lbl a" style="animation:left .5s 12.35s both">{E(c.get("final_rotulo","Não deixa pra depois"))}</div>
 <h2 class="T a" style="animation:slam .55s 12.45s both">{linhas(c.get("final_titulo","Vai lá|*agora*"))}</h2>
 <p class="a" style="animation:up .5s 12.9s both">{hl(c.get("final_texto","Entra no meu perfil, abre o post de hoje e comenta a palavra."))}</p>
 <div class="thumb a" style="animation:pop .5s 13.2s both"><img src="{capa}"><span>O POST É ESTE</span></div>
 <div class="pill a" style="animation:pop .5s 13.6s both"><div style="animation:pulse .9s 14.1s infinite ease-in-out">COMENTA <em>{E(pal)}</em></div></div>
 <div class="sig a" style="animation:up .5s 13.8s both">{arroba}<small>{E(c.get("rodape",""))}</small></div></section>
<script>window.seek=ms=>document.getAnimations().forEach(a=>{{a.pause();a.currentTime=ms}});</script>
</body></html>"""

# --------------------------------------------------------------- quadros
def render_quadros(html_path, pasta, tempos):
    os.makedirs(pasta, exist_ok=True)
    try:
        from playwright.sync_api import sync_playwright
        with sync_playwright() as p:
            exe = next((x for x in ["/opt/pw-browsers/chromium"] if os.path.exists(x)), None)
            b = p.chromium.launch(**({"executable_path": exe} if exe else {}))
            pg = b.new_page(viewport={"width": 1080, "height": 1920})
            pg.goto("file://" + os.path.abspath(html_path)); pg.evaluate("document.fonts.ready"); pg.wait_for_timeout(600)
            for i, t in enumerate(tempos):
                pg.evaluate(f"seek({t*1000})")
                pg.screenshot(path=os.path.join(pasta, f"f{i:04d}.jpg"), type="jpeg", quality=92)
            b.close(); return True
    except Exception:
        pass
    node = shutil.which("node")
    if not node: return False
    js = f"""const pw=(()=>{{for(const m of ['playwright','playwright-core','/home/claude/.npm-global/lib/node_modules/playwright']){{try{{return require(m)}}catch(e){{}}}}}})();
(async()=>{{const fs=require('fs');const ex=['/opt/pw-browsers/chromium'].find(x=>fs.existsSync(x));
const b=await pw.chromium.launch(ex?{{executablePath:ex}}:{{}});const p=await b.newPage({{viewport:{{width:1080,height:1920}}}});
await p.goto('file://{os.path.abspath(html_path)}');await p.evaluate(()=>document.fonts.ready);await p.waitForTimeout(600);
const T={json.dumps(tempos)};for(let i=0;i<T.length;i++){{await p.evaluate(ms=>seek(ms),T[i]*1000);
await p.screenshot({{path:'{os.path.abspath(pasta)}/f'+String(i).padStart(4,'0')+'.jpg',type:'jpeg',quality:92}});}}await b.close();}})();"""
    r = subprocess.run([node, "-e", js], capture_output=True, text=True)
    return r.returncode == 0

# --------------------------------------------------------------- sons (sintetizados, sem direitos autorais)
SR = 44100
def sons_wav(destino, n_letras):
    try:
        import numpy as np
    except Exception:
        return False
    N = int(SR * DUR); mix = np.zeros((N, 2)); rng = np.random.default_rng(7)
    t = lambda d: np.arange(int(SR * d)) / SR
    def lp(x, a):  # filtro simples
        y = np.empty_like(x); acc = 0.0
        for i, v in enumerate(x): acc += a * (v - acc); y[i] = acc
        return y
    def add(sig, at, g=1.0, pan=0.0, m=None):
        m = mix if m is None else m
        i = int(at * SR); sig = sig[:max(0, N - i)]
        m[i:i+len(sig), 0] += sig * g * (1 - pan) ; m[i:i+len(sig), 1] += sig * g * (1 + pan)
    def impact():
        x = t(0.6); f = 110*np.exp(-x*9)+45
        b = np.sin(2*np.pi*np.cumsum(f)/SR)*np.exp(-x*6)
        c = rng.standard_normal(len(x))*np.exp(-x*60)*0.25
        return np.tanh((b+c)*1.6)*0.9
    def whoosh(d=0.5, up=True):
        x = t(d); n = rng.standard_normal(len(x))
        n = n - np.convolve(n, np.ones(8)/8, "same")          # tira o grave
        e = np.sin(np.pi*np.linspace(0, 1, len(x)))**1.5
        k = np.linspace(.3, 1, len(x)) if up else np.linspace(1, .3, len(x))
        return n*e*k*0.5
    def pop(f=700):
        x = t(0.18); fr = f*(1+0.8*np.exp(-x*40))
        return np.sin(2*np.pi*np.cumsum(fr)/SR)*np.exp(-x*28)*0.6
    def key():
        x = t(0.05); n = rng.standard_normal(len(x)); n = n - np.convolve(n, np.ones(6)/6, "same")
        return n*np.exp(-x*120)*0.9
    def ding():
        x = t(1.0); s = sum(np.sin(2*np.pi*f*x)*a for f, a in [(1318, .6), (1976, .35), (2637, .15)])
        return s*np.exp(-x*5)*0.5
    def riser(d=0.9):
        x = t(d); f = 200+900*(x/d)**2
        return np.sin(2*np.pi*np.cumsum(f)/SR)*0.3*(x/d)**2
    def kick():
        x = t(0.3); f = 150*np.exp(-x*25)+48
        return np.sin(2*np.pi*np.cumsum(f)/SR)*np.exp(-x*9)
    def hat():
        x = t(0.05); n = rng.standard_normal(len(x)); n = n - np.convolve(n, np.ones(4)/4, "same")
        return n*np.exp(-x*80)*0.4
    def bass(f, d):
        x = t(d); s = np.sin(2*np.pi*f*x) + 0.3*np.sin(4*np.pi*f*x)
        return s*np.minimum(1, x*40)*np.exp(-x*2.2)*0.5
    trilha = np.zeros((N, 2)); beat = 0.5; notas = [55, 55, 65.4, 49]; b = 0
    while b*beat < DUR:
        at = b*beat
        if not (7.6 < at < 8.2):
            add(kick(), at, .55, m=trilha); add(hat(), at+beat/2, .25, .3, m=trilha)
            if b % 2 == 0: add(bass(notas[(b//8) % 4], 1.0), at, .35, m=trilha)
        b += 1
    fade = np.ones(N); fade[:int(.3*SR)] = np.linspace(0, 1, int(.3*SR)); fade[-int(1.2*SR):] = np.linspace(1, 0, int(1.2*SR))
    mix += trilha*fade[:, None]*0.55
    for s0 in (0.4, 0.75, 1.1): add(impact(), s0+0.30, .9)
    add(whoosh(.55), 2.85, .8)
    add(pop(600), 3.9, .8)
    for s0 in (4.56, 5.65, 6.74): add(whoosh(.32, False), s0, .6, -.3)
    add(riser(), 7.15, .7); add(whoosh(.55), 7.85, .8)
    add(impact(), 8.2, .7); add(pop(800), 8.9, .6); add(pop(900), 10.3, .4)
    for i in range(n_letras): add(key(), 10.75+i*0.08, .6)
    add(ding(), 11.55, .6); add(whoosh(.55), 11.85, .8)
    add(impact(), 12.75, 1.0); add(pop(700), 13.55, .6); add(pop(500), 13.95, .8)
    pk = np.max(np.abs(mix)) or 1; mix = np.tanh(mix/pk*1.1)*0.89
    with wave.open(destino, "wb") as w:
        w.setnchannels(2); w.setsampwidth(2); w.setframerate(SR)
        w.writeframes((mix*32767).astype("<i2").tobytes())
    return True

# --------------------------------------------------------------- narração
def _baixa(url, destino, cab=None, dados=None):
    try:
        req = urllib.request.Request(url, data=dados, headers=cab or {})
        with urllib.request.urlopen(req, timeout=60) as r: open(destino, "wb").write(r.read())
        return os.path.getsize(destino) > 1000
    except Exception:
        pass
    if dados is None and shutil.which("curl"):   # plano B pra download simples
        r = subprocess.run(["curl", "-sSL", "-o", destino, url], capture_output=True, timeout=900)
        return r.returncode == 0 and os.path.exists(destino) and os.path.getsize(destino) > 1000
    return False

def voz_elevenlabs(falas, pasta, chave, voz):
    voz = voz or "pNInz6obpgDQGcFmaJgB"   # voz pública padrão da biblioteca; troque pela voz escolhida
    saida = []
    for i, f in enumerate(falas):
        d = os.path.join(pasta, f"fala{i+1}.mp3")
        ok = _baixa(f"https://api.elevenlabs.io/v1/text-to-speech/{voz}", d,
                    {"xi-api-key": chave, "Content-Type": "application/json", "Accept": "audio/mpeg"},
                    json.dumps({"text": f, "model_id": "eleven_multilingual_v2"}).encode())
        if not ok: return None
        saida.append(d)
    return saida

KOKORO = "https://github.com/thewh1teagle/kokoro-onnx/releases/download/model-files-v1.0/"
def voz_kokoro(falas, pasta, voz="pm_alex", velocidade=0.95):
    """Voz gratuita natural em português (Kokoro, offline). Vozes: pm_alex, pm_santa (masculinas), pf_dora (feminina)."""
    subprocess.run([sys.executable, "-m", "pip", "install", "-q", "--break-system-packages", "kokoro-onnx", "soundfile"], capture_output=True, timeout=600)
    import soundfile as sf
    from kokoro_onnx import Kokoro
    cache = os.path.join(os.path.expanduser("~"), ".cache", "magnetic-voz"); os.makedirs(cache, exist_ok=True)
    arqs = []
    for n in ("kokoro-v1.0.onnx", "voices-v1.0.bin"):
        d = os.path.join(cache, n)
        if not os.path.exists(d) or os.path.getsize(d) < 1_000_000:
            if not _baixa(KOKORO + n, d): raise RuntimeError("sem download da voz")
        arqs.append(d)
    k = Kokoro(*arqs); saida = []
    for i, f in enumerate(falas):
        a, sr = k.create(f, voice=voz if voz in ("pm_alex", "pm_santa", "pf_dora") else "pm_alex", speed=velocidade, lang="pt-br")
        d = os.path.join(pasta, f"fala{i+1}.wav"); sf.write(d, a, sr); saida.append(d)
    return saida

def voz_gratis(falas, pasta, voz, velocidade=0.95):
    # 1) Kokoro: natural e offline (melhor opção gratuita)
    try:
        return voz_kokoro(falas, pasta, voz or "pm_alex", velocidade), "gratuita natural (Kokoro, voz " + (voz if voz in ("pm_alex", "pm_santa", "pf_dora") else "pm_alex") + ")"
    except Exception:
        pass
    # 2) voz neural da Microsoft (edge-tts), se a rede deixar
    voz = voz if voz and voz.startswith("pt-BR") else "pt-BR-AntonioNeural"
    try:
        subprocess.run([sys.executable, "-m", "pip", "install", "-q", "--break-system-packages", "edge-tts"], capture_output=True, timeout=120)
        saida = []
        for i, f in enumerate(falas):
            d = os.path.join(pasta, f"fala{i+1}.mp3")
            subprocess.run([sys.executable, "-m", "edge_tts", "--voice", voz or "pt-BR-AntonioNeural", "--rate=+8%", "--text", f, "--write-media", d], capture_output=True, timeout=60)
            if not (os.path.exists(d) and os.path.getsize(d) > 1000): raise RuntimeError
            saida.append(d)
        return saida, "Microsoft (neural)"
    except Exception:
        pass
    # 2) voz offline Piper (pt-BR), baixada do GitHub
    try:
        subprocess.run([sys.executable, "-m", "pip", "install", "-q", "--break-system-packages", "piper-tts"], capture_output=True, timeout=300)
        cache = os.path.join(os.path.expanduser("~"), ".cache", "magnetic-voz"); os.makedirs(cache, exist_ok=True)
        modelo = os.path.join(cache, "pt-br-edresson-low.onnx")
        if not os.path.exists(modelo):
            tgz = os.path.join(cache, "v.tar.gz")
            if not _baixa("https://github.com/rhasspy/piper/releases/download/v0.0.2/voice-pt-br-edresson-low.tar.gz", tgz): return None, None
            with tarfile.open(tgz) as tf: tf.extractall(cache, filter="data") if hasattr(tarfile, "data_filter") else tf.extractall(cache)
        saida = []
        for i, f in enumerate(falas):
            d = os.path.join(pasta, f"fala{i+1}.wav")
            subprocess.run([sys.executable, "-m", "piper", "-m", modelo, "--length-scale", "0.85", "-f", d], input=f, text=True, capture_output=True, timeout=120)
            if not os.path.exists(d): return None, None
            saida.append(d)
        return saida, "Piper (offline, mais robótica)"
    except Exception:
        return None, None

def duracao(ff, arq):
    r = subprocess.run([ff.replace("ffmpeg", "ffprobe") if shutil.which(ff.replace("ffmpeg", "ffprobe")) else ff, "-i", arq], capture_output=True, text=True)
    m = re.search(r"Duration: (\d+):(\d+):([\d.]+)", r.stderr + r.stdout)
    return int(m.group(1))*3600 + int(m.group(2))*60 + float(m.group(3)) if m else 0

def faixa_voz(ff, falas_arq, pasta):
    """Encaixa uma fala no começo de cada cena (acelera um pouco se passar do tempo)."""
    if len(falas_arq) == 1:
        partes = [(falas_arq[0], 0.35, DUR - 0.4)]
    else:
        partes = []
        for i, a in enumerate(falas_arq[:4]):
            ini = CENAS[i] + (0.35 if i == 0 else 0.25)
            fim = (CENAS[i+1] - 0.15) if i < 3 else DUR - 0.1
            partes.append((a, ini, fim - ini))
    ins, filt = [], []
    for k, (a, ini, vaga) in enumerate(partes):
        d = duracao(ff, a); tempo = 1.0
        if d > vaga: tempo = min(1.35, d / vaga)
        ins += ["-i", a]
        filt.append(f"[{k}]atempo={tempo:.3f},aresample=44100,adelay={int(ini*1000)}:all=1[v{k}]")
    filt.append("".join(f"[v{k}]" for k in range(len(partes))) + f"amix=inputs={len(partes)}:normalize=0,highpass=f=90,acompressor=threshold=-20dB:ratio=3:makeup=4,apad=whole_dur={DUR},atrim=0:{DUR},aformat=channel_layouts=stereo[v]")
    out = os.path.join(pasta, "voz.wav")
    subprocess.run([ff, "-y", "-loglevel", "error", *ins, "-filter_complex", ";".join(filt), "-map", "[v]", out], check=True)
    return out

def achar_ffmpeg():
    ff = shutil.which("ffmpeg")
    if ff: return ff
    try:
        subprocess.run([sys.executable, "-m", "pip", "install", "-q", "--break-system-packages", "imageio-ffmpeg"], capture_output=True, timeout=300)
        import imageio_ffmpeg; return imageio_ffmpeg.get_ffmpeg_exe()
    except Exception:
        return None

# --------------------------------------------------------------- principal
def main():
    if len(sys.argv) < 3: print(__doc__); sys.exit(1)
    cfg_path, out = sys.argv[1], sys.argv[2]
    c = json.load(open(cfg_path, encoding="utf-8")); base = os.path.dirname(os.path.abspath(cfg_path))
    os.makedirs(out, exist_ok=True); trab = tempfile.mkdtemp()
    hp = os.path.join(out, "story-motion.html"); open(hp, "w", encoding="utf-8").write(montar_html(c, base))
    if "--previa" in sys.argv:
        ok = render_quadros(hp, out, [2.6, 4.4, 9.8, 11.7, 14.5])
        print("previa:", "ok" if ok else "sem navegador", out); return
    if not render_quadros(hp, os.path.join(trab, "q"), [i / FPS for i in range(int(DUR * FPS))]):
        print("ERRO: sem navegador pra gerar o vídeo. Entregue o HTML (story-motion.html) e explique."); sys.exit(2)
    ff = achar_ffmpeg()
    if not ff: print("ERRO: sem ffmpeg pra montar o vídeo."); sys.exit(3)
    pal = str(c.get("palavra", "")).upper()
    audio = None
    if c.get("sons", True) and sons_wav(os.path.join(trab, "sons.wav"), len(pal)): audio = os.path.join(trab, "sons.wav")
    nar = c.get("narracao") or {}; modo = nar.get("modo", "nenhuma"); info_voz = "sem narração"
    falas_arq = None
    if modo == "audio" and nar.get("audios"):
        falas_arq = [a if os.path.isabs(a) else os.path.join(base, a) for a in nar["audios"]]; info_voz = "áudio enviado pela pessoa"
    elif modo == "elevenlabs":
        chave = nar.get("elevenlabs_chave") or os.environ.get("ELEVENLABS_API_KEY", "")
        falas_arq = voz_elevenlabs(nar.get("falas", []), trab, chave, nar.get("elevenlabs_voz")) if chave else None
        info_voz = "ElevenLabs" if falas_arq else "ElevenLabs falhou (sem chave ou sem acesso) - saiu sem narração"
    elif modo == "gratis":
        falas_arq, qual = voz_gratis(nar.get("falas", []), trab, nar.get("voz"), float(nar.get("velocidade", 1.0)))
        info_voz = f"voz gratuita: {qual}" if falas_arq else "voz gratuita indisponível neste ambiente - saiu sem narração"
    if falas_arq:
        voz = faixa_voz(ff, falas_arq, trab)
        if audio:   # abaixa a trilha quando a voz fala
            mixa = os.path.join(trab, "mix.wav")
            subprocess.run([ff, "-y", "-loglevel", "error", "-i", audio, "-i", voz, "-filter_complex",
                "[1]asplit[vs][vm];[0][vs]sidechaincompress=threshold=0.03:ratio=6:attack=20:release=300,volume=0.8[m];[m][vm]amix=inputs=2:normalize=0", mixa], check=True)
            audio = mixa
        else:
            audio = voz
    final = os.path.join(out, "story-motion.mp4")
    cmd = [ff, "-y", "-loglevel", "error", "-framerate", str(FPS), "-i", os.path.join(trab, "q", "f%04d.jpg")]
    if audio: cmd += ["-i", audio, "-af", "loudnorm=I=-14:TP=-1.5:LRA=11", "-ar", "44100", "-c:a", "aac", "-b:a", "192k", "-shortest"]
    else: cmd += ["-f", "lavfi", "-t", str(DUR), "-i", "anullsrc=r=44100:cl=stereo", "-c:a", "aac", "-shortest"]
    cmd += ["-c:v", "libx264", "-pix_fmt", "yuv420p", "-profile:v", "high", "-crf", "18", "-movflags", "+faststart", final]
    subprocess.run(cmd, check=True)
    shutil.rmtree(trab, ignore_errors=True)
    print("ok", final, "|", info_voz)

if __name__ == "__main__":
    main()
