#!/usr/bin/env python3
"""gancho.py - dá nota de 0 a 100 para ganchos de Reels em português e ranqueia.

Mede cinco coisas que ganchos que prendem costumam ter:
  TAMANHO   dá pra falar em até ~3 segundos
  CONCRETO  tem número, valor, nome ou prazo
  RISCO     tem algo em jogo: perda, erro, custo, ganho, proibição
  FRENTE    a informação vem logo no começo, sem enrolação
  ALVO      fala com alguém ("você", "dono de clínica", "se você...")

Não é previsão de views: ela pega cumprimento, enrolação, gancho sem nada concreto
e gancho comprido demais. Quem decide se viraliza é o rosto, a edição e o público.
Confie mais no gráfico de retenção do Instagram do que nesta nota.

uso:
  python3 gancho.py ganchos.txt          # um gancho por linha, em ranking
  python3 gancho.py --gancho "frase"     # um só
  python3 gancho.py ganchos.txt --json
"""
import re, sys, json, unicodedata

def sa(t): return "".join(c for c in unicodedata.normalize("NFD", t.lower()) if unicodedata.category(c) != "Mn")
PAL = re.compile(r"[\wÀ-ÿ$%'’-]+", re.UNICODE)
NUM = re.compile(r"(r\$\s?\d|us\$\s?\d|\$\s?\d|\d)", re.I)
NUM_FALADO = set("dois duas tres quatro cinco seis sete oito nove dez onze doze quinze vinte trinta quarenta cinquenta cem cento cem mil milhao milhoes bilhao dobro triplo metade meia dezena duzia primeiro primeiros".split())
RISCO = set(sa(x) for x in """perdi perde perder perdendo perda prejuizo custou custa custo caro erro errado errando erros nunca ninguem pare para proibido cuidado
morre morreu acabou fim mentira verdade segredo escondem dinheiro lucro faturei faturamento ganhei ganha ganhar cliente clientes
demitido falencia quebrei quebrou devolver reembolso multa risco perigo pior melhor unico unica ultimo ultima rapido gratis gratuito
substituiu troquei dobrou dobrar triplicou lotou lotar vendeu vender vendas desistem desistiu""".split())
ALVO = re.compile(r"\b(voce|voces|seu|sua|seus|suas|te|contigo|se voce|dono|dona|donos|quem|pra quem|gestor|gestora|agencia|empreendedor|empreendedora|medico|dentista|advogado|corretor|nutricionista|personal|psicologo|coach|mae|pai)\b")
ENROLA = ["oi", "ola", "fala galera", "fala pessoal", "e ai", "eai", "bom dia", "boa tarde", "boa noite", "gente", "entao", "bom,", "hoje eu vou", "hoje vou", "nesse video", "neste video", "no video de hoje", "vamos falar", "eu queria", "deixa eu", "salve", "tudo bem"]
MATA = [("oi", "Cumprimento. Ninguém abriu o Reels pra ser cumprimentado."), ("ola", "Cumprimento. Ninguém abriu o Reels pra ser cumprimentado."),
        ("fala galera", "Cumprimento. Corte e comece pela afirmação."), ("fala pessoal", "Cumprimento. Corte e comece pela afirmação."),
        ("e ai", "Cumprimento. Corte e comece pela afirmação."), ("para de rolar", "Pedir atenção prova que ainda não mereceu."),
        ("pare de rolar", "Pedir atenção prova que ainda não mereceu."), ("nesse video", "Anunciar o vídeo gasta os 2 segundos que você tem."),
        ("neste video", "Anunciar o vídeo gasta os 2 segundos que você tem."), ("hoje eu vou", "Introdução. O vídeo começa na frase que viria no segundo 6."),
        ("se inscreve", "Pedido no começo. O pedido vai no final."), ("me segue", "Pedido no começo. O pedido vai no final.")]

def nota(g):
    t = g.strip(); s = sa(t); w = PAL.findall(t); n = len(w); ws = [sa(x) for x in w]
    r = {}
    # TAMANHO: ~2,6 palavras por segundo falado
    r["TAMANHO"] = 100 if 5 <= n <= 9 else 85 if n in (10, 11) else 70 if n in (3, 4) else 65 if 12 <= n <= 14 else 45 if 15 <= n <= 18 else 20 if 19 <= n <= 24 else 5 if n > 24 else 30
    conc = 0
    if NUM.search(t): conc += 70
    if any(x in NUM_FALADO for x in ws): conc += 45
    if re.search(r"(?<!^)(?<![.!?]\s)\b[A-ZÁÉÍÓÚÂÊÔÃÕÇ][a-záéíóúâêôãõç]{2,}", t[1:]): conc += 30
    if re.search(r"\b(dias?|semanas?|meses|m[eê]s|anos?|horas?|minutos?|segundos?|%|reais|mil)\b", s): conc += 20
    r["CONCRETO"] = min(100, conc) if conc else 15
    rk = sum(1 for x in ws if x in RISCO) + (1 if "?" in t else 0) + (1 if re.search(r"\bnao\b", s) else 0)
    r["RISCO"] = 100 if rk >= 2 else 75 if rk == 1 else 30
    ini = " ".join(ws[:3])
    fr = 100
    if any(ini.startswith(e) or s.startswith(e) for e in ENROLA): fr = 5
    elif ws and ws[0] in ("eu", "a", "o", "e", "mas", "tipo", "assim"): fr = 70
    r["FRENTE"] = fr
    r["ALVO"] = 100 if ALVO.search(s) else 60 if re.search(r"\b(eu|meu|minha|me)\b", s) else 35
    peso = {"TAMANHO": .2, "CONCRETO": .25, "RISCO": .2, "FRENTE": .2, "ALVO": .15}
    total = sum(r[k] * peso[k] for k in peso)
    mata = [m for p, m in MATA if s.startswith(p) or f" {p} " in f" {s} "][:1]
    if t.startswith("#") or (t and not t[0].isalnum() and t[0] not in '"“.¿?¡!R$'): mata.append("Começa com hashtag ou emoji. O começo tem que ser a afirmação.")
    if n > 24: mata.append("Longo demais: passa de 8 segundos falando. Corte pela metade.")
    if mata: total = min(total, 40)
    fraco = min(r, key=r.get)
    rot = "FORTE" if total >= 70 else "OK" if total >= 50 else "FRACO"
    return {"gancho": t, "nota": round(total, 1), "rotulo": rot, "palavras": n, "segundos": round(n / 2.6, 1), "pior": fraco, "notas": r, "problema": mata}

if __name__ == "__main__":
    a = sys.argv[1:]
    if not a: print(__doc__); sys.exit(1)
    if "--gancho" in a: gs = [a[a.index("--gancho") + 1]]
    else:
        src = sys.stdin if a[0] == "-" else open(a[0], encoding="utf-8")
        gs = [l.strip() for l in src if l.strip()]
    res = sorted((nota(g) for g in gs), key=lambda x: -x["nota"])
    if "--json" in a: print(json.dumps(res, ensure_ascii=False, indent=1)); sys.exit(0)
    print("RANKING DOS GANCHOS"); print("=" * 78)
    for i, x in enumerate(res):
        seta = "->" if i == 0 else "  "
        print(f"{seta} {x['nota']:5.1f} {x['rotulo']:<6} {x['gancho'][:62]}")
        print(f"        ~{x['segundos']}s falando · mais fraco: {x['pior']} ({x['notas'][x['pior']]})")
        for p in x["problema"]: print(f"        PROBLEMA: {p}")
    if res and res[0]["nota"] < 50: print("\nO melhor ficou abaixo de 50: o gancho ainda não existe. Reescreva antes do roteiro.")
