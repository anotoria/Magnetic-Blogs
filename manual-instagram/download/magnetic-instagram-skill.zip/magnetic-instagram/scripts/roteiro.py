#!/usr/bin/env python3
"""roteiro.py - cronometra um roteiro de Reels antes de gravar e aponta o que derruba a retenção.

Uma fala por linha (cada linha é um trecho/cena). Linhas que começam com [colchetes] são indicação de cena e não contam tempo.

Aponta:
  - gancho (primeira fala) passando de 3 segundos
  - trecho com mais de 4 segundos na mesma imagem
  - 3 trechos seguidos sem nada concreto (número, nome, valor, prazo)
  - falta de loop: a última fala não repete nenhuma palavra do gancho
  - diferença para a duração alvo

uso:
  python3 roteiro.py roteiro.txt --alvo 30
  python3 roteiro.py roteiro.txt --alvo 45 --ppm 170    # ppm = palavras por minuto de quem fala (padrão 160)
"""
import re, sys, unicodedata

def sa(t): return "".join(c for c in unicodedata.normalize("NFD", t.lower()) if unicodedata.category(c) != "Mn")
PAL = re.compile(r"[\wÀ-ÿ$%-]+")
PARA = set("que com para pra por uma umas uns um dos das nos nas pelo pela isso esse essa este esta aqui voce voces seu sua mais menos muito muita como quando onde porque entao tambem ainda agora depois antes sobre entre sem cada tudo nada todo toda ele ela eles elas meu minha teu tua foi ser ter tem tinha vai vou esta estou era sao nao sim".split())
CONC = re.compile(r"(\d|r\$|\$|%|\b(dias?|semanas?|meses|anos?|horas?|minutos?|mil|milh)\b)", re.I)

def main():
    a = sys.argv[1:]
    if not a: print(__doc__); sys.exit(1)
    alvo = float(a[a.index("--alvo") + 1]) if "--alvo" in a else None
    ppm = float(a[a.index("--ppm") + 1]) if "--ppm" in a else 160.0
    linhas = [l.strip() for l in open(a[0], encoding="utf-8") if l.strip() and not l.strip().startswith("[")]
    if not linhas: print("Roteiro vazio."); sys.exit(1)
    t, tot_p, avisos, rows = 0.0, 0, [], []
    seco = 0
    for i, l in enumerate(linhas):
        p = len(PAL.findall(l)); tot_p += p
        d = p / ppm * 60 + 0.25
        tag = "GANCHO" if i == 0 else ("FINAL" if i == len(linhas) - 1 else "")
        marca = ""
        if i == 0 and d > 3.0: avisos.append(f"O gancho leva {d:.1f}s. Tem que caber em 3s: corte palavras ou divida."); marca = "^ gancho longo"
        elif d > 4.0: avisos.append(f"Trecho {i + 1} fica {d:.1f}s na mesma imagem. Divida a fala ou mude o que aparece na tela no meio dela."); marca = f"^ {d:.1f}s parado"
        conc = bool(CONC.search(l)) or bool(re.search(r"(?<!^)\b[A-ZÁÉÍÓÚÂÊÔÃÕÇ][a-záéíóúâêôãõç]{2,}", l[1:]))
        seco = 0 if conc else seco + 1
        if seco == 3: avisos.append(f"Trechos {i - 1} a {i + 1} sem nada concreto (número, nome, valor, prazo). É ali que as pessoas saem.")
        rows.append((t, d, tag, l, marca)); t += d
    ini = {w for w in (sa(x) for x in PAL.findall(linhas[0])) if len(w) >= 4 and w not in PARA}
    fim = {w for w in (sa(x) for x in PAL.findall(linhas[-1])) if len(w) >= 4 and w not in PARA}
    loop = ini & fim
    print(f"ROTEIRO CRONOMETRADO  ·  {tot_p} palavras  ·  ~{t:.1f}s a {int(ppm)} ppm" + (f"  ·  alvo {alvo:.0f}s" if alvo else ""))
    print("=" * 78)
    for (ini_t, d, tag, l, marca) in rows:
        m, s = divmod(ini_t, 60)
        print(f"  {int(m)}:{s:04.1f}  {d:4.1f}s  {tag:<7}{l[:56]}{'...' if len(l) > 56 else ''}")
        if marca: print(f"{'':25}{marca}")
    print("-" * 78)
    if loop: print(f"  - Loop: o final repete \"{sorted(loop)[0]}\" do gancho. O replay emenda sozinho.")
    else: avisos.append("Sem loop: a última fala não repete nenhuma palavra do gancho. Traga uma palavra do começo pro final.")
    if alvo:
        dif = t - alvo
        if abs(dif) > 3:
            pal = abs(dif) * ppm / 60
            avisos.append(f"{abs(dif):.1f}s {'acima' if dif > 0 else 'abaixo'} do alvo. {'Corte' if dif > 0 else 'Acrescente'} umas {pal:.0f} palavras" + (" (ou grave mais curto: curto costuma ser melhor)." if dif < 0 else "."))
    for x in avisos: print(f"  - {x}")
    print("\nPRONTO PRA GRAVAR" if not avisos else f"\n{len(avisos)} ajuste(s) antes de gravar.")

if __name__ == "__main__": main()
