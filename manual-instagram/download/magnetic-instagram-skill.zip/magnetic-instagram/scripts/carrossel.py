#!/usr/bin/env python3
"""carrossel.py - monta o carrossel (1080x1350) a partir de um arquivo JSON e gera as imagens.

uso:
  python3 carrossel.py slides.json saida/            # gera saida/carrossel.html e saida/slide-N.png
  python3 carrossel.py slides.json saida/ --so-html  # só o HTML (para abrir no navegador)
  python3 carrossel.py config.json galeria/ --galeria  # amostra de todos os estilos com as cores da pessoa

Estilos ("estilo" no JSON): impacto, editorial, tweet, caderno, gradiente, minimal,
ou "alternar" (sorteia um diferente de "ultimo_estilo"). O estilo usado sai no final da execução.
No estilo tweet, use "nome" e "avatar" (foto da pessoa) no JSON.
"css_extra" (opcional) acrescenta ajustes finos de visual, por exemplo pra ficar parecido com um carrossel de exemplo da pessoa.

slides.json:
{
  "arroba": "@fulano", "assinatura": "opcional, texto pequeno no topo à esquerda",
  "cor_destaque": "#D15434", "cor_escura": "#0F0D0C", "cor_clara": "#F7F4F1",
  "fonte_titulo": "Barlow Condensed", "fonte_texto": "Plus Jakarta Sans",
  "slides": [
    {"tipo": "capa", "fundo": "escuro", "chapeu": "IA + Instagram", "titulo": "Texto *destacado*", "sub": "linha de promessa", "foto": "caminho/opcional.jpg"},
    {"tipo": "texto", "fundo": "claro", "chapeu": "...", "titulo": "...", "texto": "parágrafo curto"},
    {"tipo": "lista", "fundo": "escuro", "chapeu": "...", "titulo": "...", "itens": [["título", "detalhe"], ...]},
    {"tipo": "chat", "fundo": "claro", "chapeu": "...", "titulo": "...", "pergunta": "...", "resposta": "...", "nota": "..."},
    {"tipo": "comparacao", "fundo": "claro", "titulo": "...", "a": ["Antes", "item", "item"], "b": ["Depois", "item", "item"], "conclusao": "..."},
    {"tipo": "numero", "fundo": "escuro", "numero": "3x", "titulo": "...", "texto": "..."},
    {"tipo": "resumo", "fundo": "claro", "titulo": "Resumo", "itens": ["...", "..."]},
    {"tipo": "cta", "numero": "+200", "titulo": "...", "texto": "...", "acao": "Comenta", "palavra": "GUIA", "depois": "que eu te mando o link."}
  ]
}
Use *asteriscos* no título para pintar a palavra com a cor de destaque.
Fundo: "escuro", "claro" ou "destaque". O slide "cta" usa o destaque por padrão.
"""
import json, sys, os, html, re, shutil, subprocess, pathlib, base64, urllib.request, tarfile, tempfile

def E(t): return html.escape(str(t or ""))
def hl(t): return re.sub(r"\*(.+?)\*", r"<em>\1</em>", E(t))

CACHE = os.path.join(os.path.expanduser("~"), ".cache", "magnetic-fontes")
def _baixa(url):
    try:
        with urllib.request.urlopen(url, timeout=12) as r: return r.read()
    except Exception: return None
def fontes_embutidas(familias):
    """Tenta embutir as fontes no HTML (funciona mesmo sem internet no navegador). Fontes: jsDelivr ou pacote npm @fontsource."""
    css = []
    for fam in familias:
        slug = fam.strip().lower().replace(" ", "-")
        d = os.path.join(CACHE, slug); os.makedirs(d, exist_ok=True)
        pesos = [400, 500, 600, 700, 800, 900]
        faltam = [w for w in pesos for sub in ("latin", "latin-ext") if not os.path.exists(os.path.join(d, f"{sub}-{w}.woff2"))]
        if faltam and not os.path.exists(os.path.join(d, ".tentado")):
            ok_cdn = _baixa(f"https://cdn.jsdelivr.net/npm/@fontsource/{slug}/package.json") is not None
            for w in (pesos if ok_cdn else []):
                for sub in ("latin", "latin-ext"):
                    f = os.path.join(d, f"{sub}-{w}.woff2")
                    if os.path.exists(f): continue
                    b = _baixa(f"https://cdn.jsdelivr.net/npm/@fontsource/{slug}/files/{slug}-{sub}-{w}-normal.woff2")
                    if b: open(f, "wb").write(b)
            if not any(n.endswith(".woff2") for n in os.listdir(d)) and shutil.which("npm"):
                tmp = tempfile.mkdtemp()
                try:
                    subprocess.run(["npm", "pack", f"@fontsource/{slug}", "--silent"], cwd=tmp, capture_output=True, timeout=90)
                    for tg in [x for x in os.listdir(tmp) if x.endswith(".tgz")]:
                        with tarfile.open(os.path.join(tmp, tg)) as tf:
                            for m in tf.getmembers():
                                mm = re.search(rf"files/{re.escape(slug)}-(latin|latin-ext)-(\d00)-normal\.woff2$", m.name)
                                if mm: open(os.path.join(d, f"{mm.group(1)}-{mm.group(2)}.woff2"), "wb").write(tf.extractfile(m).read())
                except Exception: pass
            open(os.path.join(d, ".tentado"), "w").write("1")
        arqs = [n for n in sorted(os.listdir(d)) if re.match(r"(latin|latin-ext)-(\d00)\.woff2$", n) and int(n.split("-")[-1][:3]) >= 400]
        unico = len({n.split("-")[-1] for n in arqs}) == 1
        for n in arqs:
            mm = re.match(r"(latin|latin-ext)-(\d00)\.woff2$", n)
            rng = "U+0000-00FF,U+0131,U+0152-0153,U+02BB-02BC,U+02C6,U+02DA,U+02DC,U+2000-206F,U+2074,U+20AC,U+2122,U+2191,U+2193,U+2212,U+2215,U+FEFF,U+FFFD" if mm.group(1) == "latin" else "U+0100-024F,U+0259,U+1E00-1EFF,U+2020,U+20A0-20AB,U+20AD-20C0,U+2113,U+2C60-2C7F,U+A720-A7FF"
            b64 = base64.b64encode(open(os.path.join(d, n), "rb").read()).decode()
            css.append(f"@font-face{{font-family:'{fam}';font-weight:{'100 900' if unico else mm.group(2)};font-display:block;src:url(data:font/woff2;base64,{b64}) format('woff2');unicode-range:{rng}}}")
    return "".join(css)

ESTILOS = {
 "impacto":   "Títulos gigantes em caixa alta, fundo escuro e claro alternando, cartões com borda. Forte e direto.",
 "editorial": "Cara de revista: títulos em caixa baixa, linhas finas, números grandes vazados, muito respiro.",
 "tweet":     "Cada slide parece um post do X/Twitter com sua foto, nome e @. Ótimo pra opinião e bastidor.",
 "caderno":   "Folha pautada com marca-texto e anotações à mão. Ótimo pra passo a passo e dicas.",
 "gradiente": "Fundo em degradê com as cores da marca e cartões de vidro arredondados. Moderno, tecnologia.",
 "minimal":   "Um fundo, texto centralizado e enorme, quase nada de enfeite. Ótimo pra frases e reflexões.",
}
def _a(cor, alfa):
    cor = (cor or "#000000").strip()
    return cor + alfa if re.fullmatch(r"#[0-9a-fA-F]{6}", cor) else cor
def css_estilo(estilo, ac, dk, lt, FT, FX, FN, FE):
    if estilo == "editorial": return f"""
.bar{{display:none}} .top{{border-bottom:2px solid currentColor;margin:0 80px;padding:56px 0 22px;opacity:.75}}
h1,h2{{font-family:{FE};text-transform:none;letter-spacing:-.015em;line-height:1.04;font-weight:400}} h1{{font-size:132px}} h2{{font-size:90px}}
h1 em,h2 em{{font-style:italic}} .cmp h3,.conc,.caixa strong,.big,.item i{{font-family:{FE};font-weight:400;text-transform:none}}
.chapeu{{color:inherit;opacity:.7;border-top:2px solid var(--ac);display:inline-block;align-self:flex-start;padding-top:14px}}
.item{{background:none;border:none;border-top:2px solid rgba(128,128,128,.35);border-radius:0;padding:26px 0}}
.item i{{background:none;color:var(--ac);font-size:64px;width:90px;height:auto;line-height:1}}
.big{{color:transparent;-webkit-text-stroke:4px var(--ac)}} .destaque .big{{-webkit-text-stroke-color:#fff}}
.cmp>div{{border-radius:0;border:none;border-top:4px solid currentColor}} .cmp>div.b{{background:none;color:inherit;border-top-color:var(--ac)}} .cmp>div.b h3{{color:var(--ac)}}
.conc,.caixa{{border-radius:0}} .chat div{{border-radius:0}}
.prog .t{{height:2px}} .prog .t span{{height:2px}}
"""
    if estilo == "tweet": return f"""
.bar,.top{{display:none}} .s.escuro{{background:{dk}}} .s.claro{{background:#FFFFFF}}
.c{{padding:60px 70px 150px}}
.tw{{max-width:940px;width:100%;margin:0 auto}}
.twh{{display:flex;align-items:center;gap:26px;margin-bottom:40px}}
.twh .av{{width:120px;height:120px;border-radius:50%;background:var(--ac);color:#fff;display:flex;align-items:center;justify-content:center;font:800 48px {FX};overflow:hidden;flex:none}}
.twh .av img{{width:100%;height:100%;object-fit:cover}}
.twh b{{display:block;font:800 42px {FX}}} .twh b i{{display:inline-block;width:38px;height:38px;border-radius:50%;background:var(--ac);color:#fff;font:900 26px/38px {FX};text-align:center;font-style:normal;margin-left:10px;vertical-align:4px}}
.twh span{{font-size:32px;opacity:.6}}
h1,h2{{font-family:{FX};text-transform:none;font-weight:800;letter-spacing:-.01em;line-height:1.15}} h1{{font-size:88px}} h2{{font-size:66px}}
.chapeu{{text-transform:none;letter-spacing:0;font-size:30px}}
.item{{border-radius:18px}} .big{{font-family:{FX};font-weight:800}}
.comfoto .foto{{display:none}}
"""
    if estilo == "caderno": return f"""
.bar{{display:none}}
.s.claro{{background:repeating-linear-gradient(180deg,transparent 0 62px,{_a(dk,'14')} 62px 64px),{lt}}}
.s.escuro{{background:repeating-linear-gradient(180deg,transparent 0 62px,{_a(lt,'12')} 62px 64px),{dk}}}
.s::after{{content:"";position:absolute;top:0;bottom:0;left:56px;width:3px;background:{_a(ac,'99')}}}
h1,h2{{text-transform:none;letter-spacing:-.01em;line-height:1.08}} h1{{font-size:120px}} h2{{font-size:84px}}
h1 em,h2 em{{color:inherit;background:linear-gradient(180deg,transparent 58%,{_a(ac,'aa')} 58% 92%,transparent 92%);padding:0 6px}}
.chapeu{{font:700 54px {FN};text-transform:none;letter-spacing:0;transform:rotate(-2deg);align-self:flex-start}}
.nota,.swipe{{font-family:{FN};font-size:52px;text-transform:none;letter-spacing:0;border:none;padding-left:0}}
.item{{background:none;border:3px dashed rgba(128,128,128,.45);border-radius:14px}}
.item i{{border-radius:50%;transform:rotate(-6deg)}}
.check li::before{{content:"☑";font-family:{FX}}}
.caixa,.conc{{transform:rotate(-1deg);border-radius:10px}}
"""
    if estilo == "gradiente": return f"""
.bar{{display:none}}
.s.escuro{{background:radial-gradient(circle at 88% 8%,{_a(ac,'aa')} 0,transparent 42%),radial-gradient(circle at 0% 100%,{_a(ac,'55')} 0,transparent 40%),{dk}}}
.s.claro{{background:radial-gradient(circle at 90% 6%,{_a(ac,'55')} 0,transparent 40%),radial-gradient(circle at 0% 100%,{_a(ac,'30')} 0,transparent 45%),{lt}}}
.s.destaque{{background:linear-gradient(150deg,{ac} 0%,{dk} 130%)}}
.top{{margin:48px 80px 0;padding:14px 26px;border-radius:40px;background:rgba(128,128,128,.14);opacity:.85}}
h1,h2{{text-transform:none;letter-spacing:-.02em;line-height:1.02}} h1{{font-size:132px}} h2{{font-size:88px}}
.item,.cmp>div,.chat div,.caixa,.conc{{border-radius:34px;border:1px solid rgba(255,255,255,.18);box-shadow:0 20px 50px rgba(0,0,0,.18)}}
.escuro .item{{background:rgba(255,255,255,.07)}} .claro .item{{background:rgba(255,255,255,.75)}}
.item i{{border-radius:50%}}
"""
    if estilo == "minimal": return f"""
.bar{{display:none}} .top{{justify-content:center;opacity:.45}} .top span:first-child{{display:none}}
.c{{align-items:center;text-align:center;padding:40px 110px 150px}}
h1,h2{{text-transform:none;letter-spacing:-.02em;line-height:1.05}} h1{{font-size:124px}} h2{{font-size:92px}}
.chapeu{{align-self:center}} .itens,.check,.cmp,.chat{{width:100%;text-align:left}}
.item{{background:none;border:none;border-bottom:2px solid rgba(128,128,128,.3);border-radius:0}}
.chat div{{text-align:left}} .caixa{{width:100%}}
.prog{{left:50%;right:auto;transform:translateX(-50%);width:240px}}
"""
    return ""

def build(cfg, base_dir):
    ac, dk, lt = cfg.get("cor_destaque", "#D15434"), cfg.get("cor_escura", "#0F0D0C"), cfg.get("cor_clara", "#F7F4F1")
    ft, fx = cfg.get("fonte_titulo", "Barlow Condensed"), cfg.get("fonte_texto", "Plus Jakarta Sans")
    arroba, ass = E(cfg.get("arroba", "")), E(cfg.get("assinatura", ""))
    slides = cfg["slides"]; T = len(slides)
    estilo = (cfg.get("estilo") or "impacto").lower().strip()
    if estilo in ("alternar", "aleatorio", "aleatório", "variar"):
        import random
        op = [e for e in ESTILOS if e != (cfg.get("ultimo_estilo") or "").lower()]
        estilo = random.choice(op)
    if estilo not in ESTILOS: estilo = "impacto"
    fn = cfg.get("fonte_anotacao", "Caveat")
    fe = cfg.get("fonte_editorial", "DM Serif Display")
    emb = fontes_embutidas({ft, fx} | ({fn} if estilo == "caderno" else set()) | ({fe} if estilo == "editorial" else set()))
    FN = f"'{fn}','Comic Sans MS',cursive"
    FE = f"'{fe}',Georgia,'Times New Roman',serif"
    FT, FX = f"'{ft}',Impact,'Arial Narrow',sans-serif", f"'{fx}',Arial,Helvetica,sans-serif"
    fam = "&".join("family=" + f.replace(" ", "+") + ":wght@400;600;700;800;900" for f in {ft, fx})
    css = emb + f"""
*{{box-sizing:border-box;margin:0;padding:0}}
body{{background:#777}}
:root{{--ac:{ac};--dk:{dk};--lt:{lt}}}
.s{{width:1080px;height:1350px;position:relative;overflow:hidden;font-family:{FX};display:flex;flex-direction:column}}
.s.escuro{{background:var(--dk);color:var(--lt)}} .s.claro{{background:var(--lt);color:var(--dk)}}
.s.destaque{{background:var(--ac);color:#fff}}
.bar{{position:absolute;top:0;left:0;right:0;height:12px;background:var(--ac)}} .destaque .bar{{background:var(--dk)}}
.top{{display:flex;justify-content:space-between;padding:56px 80px 0;font:700 22px {FX};letter-spacing:.14em;text-transform:uppercase;opacity:.6}}
.c{{flex:1;display:flex;flex-direction:column;justify-content:center;padding:40px 80px 150px}}
.chapeu{{font:800 26px {FX};letter-spacing:.16em;text-transform:uppercase;color:var(--ac);margin-bottom:26px}}
.destaque .chapeu{{color:#fff;opacity:.85}}
h1,h2{{font-family:{FT};font-weight:900;text-transform:uppercase;line-height:1.02;letter-spacing:.005em}}
h1{{font-size:150px}} h2{{font-size:96px;margin-bottom:34px}}
h1 em,h2 em{{font-style:normal;color:var(--ac)}} .destaque h1 em,.destaque h2 em{{color:var(--dk)}}
.sub,.txt{{font-size:42px;line-height:1.38}} .sub{{margin-top:36px;opacity:.85}}
.txt{{opacity:.9}}
.swipe{{margin-top:44px;font:800 28px {FX};letter-spacing:.12em;text-transform:uppercase;color:var(--ac)}}
.foto{{position:absolute;right:80px;bottom:150px;width:440px;height:560px}}
.foto::before{{content:"";position:absolute;inset:0;transform:translate(20px,20px);background:var(--ac);border-radius:28px}}
.foto img{{position:relative;width:100%;height:100%;object-fit:cover;object-position:50% 20%;border-radius:28px;display:block}}
.comfoto .c{{justify-content:flex-start;padding-top:60px}} .comfoto .sub{{max-width:430px}}
.itens{{display:grid;gap:20px}}
.item{{display:flex;gap:24px;align-items:flex-start;border-radius:22px;padding:26px 28px;border:2px solid rgba(128,128,128,.28);background:rgba(128,128,128,.08)}}
.item i{{flex:none;width:66px;height:66px;border-radius:16px;background:var(--ac);color:#fff;font:900 38px/66px {FT};text-align:center;font-style:normal}}
.item b{{font:800 38px/1.2 {FX}}} .item span{{display:block;font-size:30px;line-height:1.35;opacity:.72;margin-top:6px}}
.chat{{display:flex;flex-direction:column;gap:22px}}
.chat div{{max-width:860px;border-radius:26px;padding:32px 36px;font-size:37px;line-height:1.4}}
.chat .eu{{align-self:flex-end;background:var(--ac);color:#fff;border-bottom-right-radius:6px}}
.chat .ia{{align-self:flex-start;border-bottom-left-radius:6px}}
.escuro .chat .ia{{background:var(--lt);color:var(--dk)}} .claro .chat .ia{{background:var(--dk);color:var(--lt)}}
.nota{{margin-top:40px;border-left:8px solid var(--ac);padding:8px 0 8px 26px;font:700 36px/1.35 {FX}}}
.cmp{{display:grid;grid-template-columns:1fr 1fr;gap:22px}}
.cmp>div{{border-radius:24px;padding:32px 28px;border:2px solid rgba(128,128,128,.28)}}
.cmp>div.b{{background:var(--ac);color:#fff;border-color:var(--ac)}}
.cmp h3{{font:900 54px {FT};text-transform:uppercase;margin-bottom:14px}}
.cmp p{{font-size:33px;line-height:1.35;padding:12px 0;border-bottom:1px solid rgba(128,128,128,.3)}}
.conc{{margin-top:36px;background:var(--dk);color:var(--lt);border-radius:22px;padding:28px 32px;font:900 54px/1.05 {FT};text-transform:uppercase}}
.escuro .conc{{background:var(--ac);color:#fff}}
.big{{font:900 300px/.9 {FT};color:var(--ac);margin-bottom:24px}} .destaque .big{{color:#fff}}
.check{{list-style:none;display:grid;gap:22px}}
.check li{{font:700 44px/1.3 {FX};padding-left:62px;position:relative}}
.check li::before{{content:"✓";position:absolute;left:0;top:-4px;font:900 48px {FT};color:var(--ac)}}
.caixa{{margin-top:50px;background:var(--dk);color:var(--lt);border-radius:28px;padding:40px 44px}}
.caixa small{{font:800 26px {FX};letter-spacing:.14em;text-transform:uppercase;color:var(--ac)}}
.caixa strong{{display:block;font:900 150px/.95 {FT};margin:8px 0}}
.caixa p{{font-size:34px}}
.prog{{position:absolute;left:80px;right:80px;bottom:62px;display:flex;align-items:center;gap:24px}}
.prog .t{{flex:1;height:6px;border-radius:6px;background:rgba(128,128,128,.3)}} .prog .t span{{display:block;height:100%;border-radius:6px;background:var(--ac)}}
.destaque .prog .t span{{background:#fff}}
.prog b{{font:800 26px {FX}}}
.s:target{{}}
@media screen{{.s{{margin:0 auto 30px}}}}
""" + css_estilo(estilo, ac, dk, lt, FT, FX, FN, FE) + cfg.get("css_extra", "")
    def img(p):
        if not p: return ""
        q = p if p.startswith(("http", "file:", "data:")) else pathlib.Path(base_dir, p).resolve().as_uri()
        return q
    out = []
    for i, s in enumerate(slides, 1):
        t = s.get("tipo", "texto")
        fundo = s.get("fundo") or ("destaque" if t == "cta" else ("escuro" if i % 2 else "claro"))
        if estilo == "tweet": fundo = "escuro" if cfg.get("tweet_escuro") else "claro"
        ch = f'<div class="chapeu">{E(s["chapeu"])}</div>' if s.get("chapeu") else ""
        extra, cls = "", ""
        if t == "capa":
            body = f'{ch}<h1>{hl(s.get("titulo"))}</h1>'
            if s.get("foto"):
                cls = " comfoto"; body = f'{ch}<h1 style="font-size:{s.get("tamanho", 130)}px">{hl(s.get("titulo"))}</h1>'
                extra = f'<div class="foto"><img src="{img(s["foto"])}"></div><div style="position:absolute;left:80px;bottom:160px;width:440px"><p class="sub">{E(s.get("sub"))}</p><div class="swipe">Arrasta pro lado →</div></div>'
            else:
                body += (f'<p class="sub">{E(s.get("sub"))}</p>' if s.get("sub") else "") + '<div class="swipe">Arrasta pro lado →</div>'
        elif t == "lista":
            its = "".join(f'<div class="item"><i>{k}</i><div><b>{E(a[0] if isinstance(a, list) else a)}</b>' + (f'<span>{E(a[1])}</span>' if isinstance(a, list) and len(a) > 1 else "") + '</div></div>' for k, a in enumerate(s.get("itens", []), 1))
            body = f'{ch}<h2>{hl(s.get("titulo"))}</h2><div class="itens">{its}</div>'
        elif t == "chat":
            body = f'{ch}<h2>{hl(s.get("titulo"))}</h2><div class="chat"><div class="eu">{E(s.get("pergunta"))}</div><div class="ia">{E(s.get("resposta"))}</div></div>' + (f'<div class="nota">{E(s["nota"])}</div>' if s.get("nota") else "")
        elif t == "comparacao":
            a, b = s.get("a", ["Antes"]), s.get("b", ["Depois"])
            col = lambda L, c: f'<div class="{c}"><h3>{E(L[0])}</h3>' + "".join(f"<p>{E(x)}</p>" for x in L[1:]) + "</div>"
            body = f'{ch}<h2>{hl(s.get("titulo"))}</h2><div class="cmp">{col(a, "a")}{col(b, "b")}</div>' + (f'<div class="conc">{E(s["conclusao"])}</div>' if s.get("conclusao") else "")
        elif t == "numero":
            body = f'{ch}<div class="big">{E(s.get("numero"))}</div><h2 style="margin-top:20px">{hl(s.get("titulo"))}</h2>' + (f'<p class="txt">{E(s["texto"])}</p>' if s.get("texto") else "")
        elif t == "resumo":
            body = f'{ch}<h2>{hl(s.get("titulo", "Resumo"))}</h2><ul class="check">' + "".join(f"<li>{E(x)}</li>" for x in s.get("itens", [])) + "</ul>"
        elif t == "cta":
            body = (f'<div class="big" style="font-size:220px">{E(s["numero"])}</div>' if s.get("numero") else "") + f'<h2>{hl(s.get("titulo"))}</h2>' + (f'<p class="txt">{E(s["texto"])}</p>' if s.get("texto") else "")
            body += f'<div class="caixa"><small>{E(s.get("acao", "Comenta"))}</small><strong>{E(s.get("palavra", ""))}</strong><p>{E(s.get("depois", ""))}</p></div>'
        else:
            body = f'{ch}<h2>{hl(s.get("titulo"))}</h2>' + (f'<p class="txt">{E(s["texto"])}</p>' if s.get("texto") else "")
        if estilo == "tweet":
            nome = E(cfg.get("nome") or cfg.get("arroba", "").lstrip("@"))
            av = cfg.get("avatar") or cfg.get("foto_perfil")
            avh = f'<img src="{img(av)}">' if av else E((nome or "?")[:1].upper())
            body = f'<div class="tw"><div class="twh"><div class="av">{avh}</div><div><b>{nome}<i>✓</i></b><span>{arroba}</span></div></div>{body}</div>'
        out.append(f'<section class="s {fundo}{cls}" id="s{i}"><div class="bar"></div><div class="top"><span>{ass}</span><span>{arroba}</span></div><div class="c">{body}</div>{extra}<div class="prog"><div class="t"><span style="width:{i / T * 100:.1f}%"></span></div><b>{i}/{T}</b></div></section>')
    return f'<!doctype html><html lang="pt-BR"><head><meta charset="utf-8"><link href="https://fonts.googleapis.com/css2?{fam}&display=swap" rel="stylesheet"><style>{css}</style></head><body>{"".join(out)}</body></html>', T, estilo

def render(html_path, outdir, T):
    try:
        from playwright.sync_api import sync_playwright
        with sync_playwright() as p:
            exe = next((x for x in ["/opt/pw-browsers/chromium"] if os.path.exists(x)), None)
            b = p.chromium.launch(**({"executable_path": exe} if exe else {}))
            pg = b.new_page(viewport={"width": 1080, "height": 1350})
            pg.goto(pathlib.Path(html_path).resolve().as_uri()); pg.wait_for_timeout(1500)
            pg.evaluate("document.fonts.ready")
            for i in range(1, T + 1):
                pg.locator(f"#s{i}").screenshot(path=os.path.join(outdir, f"slide-{i}.png"))
            b.close(); return "playwright"
    except Exception as e:
        err = str(e)
    node = shutil.which("node")
    if node:
        js = f"""const pw=(()=>{{for(const m of ['playwright','/home/claude/.npm-global/lib/node_modules/playwright']){{try{{return require(m)}}catch(e){{}}}}}})();
(async()=>{{const fs=require('fs');const ex=['/opt/pw-browsers/chromium'].find(x=>fs.existsSync(x));
const b=await pw.chromium.launch(ex?{{executablePath:ex}}:{{}});const p=await b.newPage({{viewport:{{width:1080,height:1350}}}});
await p.goto('{pathlib.Path(html_path).resolve().as_uri()}');await p.waitForTimeout(1500);await p.evaluate(()=>document.fonts.ready);
for(let i=1;i<={T};i++){{await p.locator('#s'+i).screenshot({{path:'{os.path.abspath(outdir)}/slide-'+i+'.png'}});}}await b.close();}})();"""
        r = subprocess.run([node, "-e", js], capture_output=True, text=True)
        if r.returncode == 0: return "node"
    return None

if __name__ == "__main__":
    a = sys.argv[1:]
    if len(a) < 2: print(__doc__); sys.exit(1)
    cfg = json.load(open(a[0], encoding="utf-8")); outdir = a[1]; os.makedirs(outdir, exist_ok=True)
    if "--galeria" in a:
        amostra = [{"tipo": "capa", "chapeu": "Estilo", "titulo": "Seu título *forte* aqui", "sub": "Uma linha de promessa."},
                   {"tipo": "lista", "fundo": "claro", "chapeu": "Passo a passo", "titulo": "3 passos", "itens": [["Primeiro passo", "detalhe curto"], ["Segundo passo", "detalhe curto"], ["Terceiro passo", "detalhe curto"]]},
                   {"tipo": "cta", "titulo": "Quer o *guia*?", "acao": "Comenta", "palavra": "GUIA", "depois": "que eu te mando."}]
        feitos = []
        for e in ESTILOS:
            c2 = dict(cfg, estilo=e, slides=amostra); d2 = os.path.join(outdir, e); os.makedirs(d2, exist_ok=True)
            doc, T, _ = build(c2, os.path.dirname(os.path.abspath(a[0])))
            hp = os.path.join(d2, "carrossel.html"); open(hp, "w", encoding="utf-8").write(doc)
            if render(hp, d2, T): feitos.append(e)
        try:
            from PIL import Image, ImageDraw
            from PIL import ImageFont
            W = Image.new("RGB", (3 * 360 + 40, len(feitos) * 500 + 20), "#DDDDDD"); dr = ImageDraw.Draw(W)
            try: fnt = ImageFont.truetype(next(p for p in ["/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf", "/System/Library/Fonts/Supplemental/Arial Bold.ttf", "C:/Windows/Fonts/arialbd.ttf"] if os.path.exists(p)), 15)
            except Exception: fnt = None
            for r, e in enumerate(feitos):
                dr.text((12, r * 500 + 10), f"{r + 1}. {e.upper()} · {ESTILOS[e]}"[:120], fill="#111111", font=fnt)
                for k in range(3):
                    W.paste(Image.open(os.path.join(outdir, e, f"slide-{k + 1}.png")).convert("RGB").resize((360, 450)), (10 + k * 370, r * 500 + 36))
            W.save(os.path.join(outdir, "galeria-estilos.png")); print(f"Galeria pronta: {os.path.join(outdir, 'galeria-estilos.png')}")
        except Exception:
            print(f"Estilos gerados em {outdir}: " + ", ".join(feitos))
        sys.exit(0)
    doc, T, estilo = build(cfg, os.path.dirname(os.path.abspath(a[0])))
    hp = os.path.join(outdir, "carrossel.html"); open(hp, "w", encoding="utf-8").write(doc)
    if "--so-html" in a: print(f"HTML pronto: {hp}"); sys.exit(0)
    how = render(hp, outdir, T)
    if how: print(f"{T} slides gerados em {outdir} · estilo: {estilo}")
    else: print(f"Sem navegador para gerar imagens. HTML pronto em {hp}: abra no navegador e faça print de cada slide, ou monte no Canva."); sys.exit(2)
