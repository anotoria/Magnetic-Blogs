#!/usr/bin/env python3
"""reels_motion.py - gera um Reels animado (MP4 1080x1920, 30 a 58 s) a partir de um roteiro em cenas,
com narração opcional (voz gratuita, ElevenLabs ou áudio da pessoa), legendas na tela sincronizadas,
trilha calma e efeitos sonoros. A trilha abaixa sozinha quando a voz fala.

uso:
  python3 reels_motion.py reels.json saida/            # gera saida/reels-motion.mp4 (+ capa.jpg)
  python3 reels_motion.py reels.json saida/ --previa   # uma imagem por cena (rápido, sem voz)

reels.json:
{
  "arroba": "@fulano", "cor_destaque": "#D45333", "cor_escura": "#0E0D0B", "cor_clara": "#F8F4F1",
  "fonte_titulo": "Anton", "fonte_texto": "Plus Jakarta Sans",
  "cenas": [
    {"tipo": "abertura", "chapeu": "IA para dono de negócio", "titulo": ["Seu negócio", "está no *top 3*", "do Google Maps?"],
     "imagem": "slide-1.jpg", "fala": "Se o seu negócio não aparece entre os três primeiros..."},
    {"tipo": "lista", "chapeu": "A boa notícia", "titulo": "3 critérios.|Você controla *2*.",
     "itens": ["Relevância", "Distância", "Destaque"], "apagado": 2, "fala": "..."},
    {"tipo": "imagem", "chapeu": "Prompt 1", "titulo": "Mapeie|o *top 3*", "imagens": ["slide-4.jpg", "slide-5.jpg"], "fala": "..."},
    ...
    {"tipo": "cta", "chapeu": "Quer os 3 prompts prontos?", "palavra": "GOOGLE3P", "depois": "que eu te mando o guia em PDF com:",
     "itens": ["Os 3 prompts completos", "..."], "fala": "Quer os três prompts prontos? Comenta Google três pê..."}
  ],
  "legendas": true,
  "narracao": {"modo": "nenhuma" | "gratis" | "elevenlabs" | "audio",
               "voz": "pm_alex", "velocidade": 0.9,          # gratis: pm_alex, pm_santa, pf_dora
               "elevenlabs_chave": "", "elevenlabs_voz": "",  # elevenlabs pela chave (ou variável ELEVENLABS_API_KEY)
               "audios": ["cena1.mp3", "..."]}                # audio: um arquivo por cena, na ordem (ex.: gerados no conector da ElevenLabs)
}
Regras: 4 a 10 cenas; a 1ª é "abertura" e a última "cta". Fala escrita como se fala ("Google três pê", números por extenso).
"*palavra*" pinta com a cor de destaque; "|" quebra a linha do título. Imagens 4:5 (as telas do carrossel) funcionam melhor.
"""
import json, sys, os, re, html, base64, shutil, subprocess, tempfile, wave
AQUI = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, AQUI)
from story_motion import fontes_embutidas, render_quadros, achar_ffmpeg, voz_elevenlabs, voz_gratis, duracao

FPS, GAP, INICIO, FIM = 30, 0.35, 0.4, 1.8
def E(t): return html.escape(str(t or ""))
def hl(t): return re.sub(r"\*(.+?)\*", r"<em>\1</em>", E(t))
def linhas(t): return "<br>".join(hl(x) for x in (t if isinstance(t, list) else str(t).split("|")))
def b64(p, base):
    p = p if os.path.isabs(p) else os.path.join(base, p)
    ext = os.path.splitext(p)[1].lower().strip(".").replace("jpg", "jpeg")
    return f"data:image/{ext};base64," + base64.b64encode(open(p, "rb").read()).decode()
def escuro(p, base):
    try:
        from PIL import Image
        im = Image.open(p if os.path.isabs(p) else os.path.join(base, p)).convert("L").resize((40, 50))
        return sum(im.getdata()) / 2000 < 110
    except Exception:
        return None

def anim(nome, d, atraso, extra="both"): return f"animation:{nome} {d}s {atraso:.2f}s {extra}"

# ------------------------------------------------------------------ tempos
def linha_do_tempo(cenas, duracoes):
    """duracoes = duração da fala de cada cena (ou None sem narração)."""
    ini, t = [], INICIO
    for c, d in zip(cenas, duracoes):
        if d is None:   # sem voz: tempo de leitura
            txt = c.get("fala") or re.sub(r"[*|]", " ", " ".join(c["titulo"]) if isinstance(c.get("titulo"), list) else str(c.get("titulo", "")))
            d = max(3.6, min(7.5, len(txt) / 16))
            if c.get("tipo") == "cta": d = max(d, 5.0)
        ini.append(t); t += d + GAP
    durs = [ (ini[i+1] - GAP - ini[i]) if i + 1 < len(ini) else (t - GAP - ini[i]) for i in range(len(ini)) ]
    total = round(t - GAP + FIM, 2)
    cena = [0.0] + [max(0, s - 0.3) for s in ini[1:]]
    return ini, durs, cena, total

# ------------------------------------------------------------------ HTML
def montar_html(c, base, ini, durs, cena_t, total):
    ac, dk, lt = c.get("cor_destaque", "#D45333"), c.get("cor_escura", "#0E0D0B"), c.get("cor_clara", "#F8F4F1")
    FT, FX = c.get("fonte_titulo", "Anton"), c.get("fonte_texto", "Plus Jakarta Sans")
    cenas = c["cenas"]; partes = []
    for i, sc in enumerate(cenas):
        t0 = cena_t[i]; t1 = cena_t[i + 1] if i + 1 < len(cenas) else None
        sai = f",sceneOut .4s {t1-0.05:.2f}s forwards ease-in" if t1 else ""
        vao = (t1 or total) - t0
        tipo = sc.get("tipo", "imagem")
        if tipo == "abertura":
            fundo = (f'<div class="bgimg" style="background-image:url({b64(sc["imagem"], base)});{anim("kb", vao+.5, 0, "both linear")}"></div><div class="shade"></div>'
                     if sc.get("imagem") else '<div class="glow"></div>')
            tit = sc.get("titulo", []); tit = tit if isinstance(tit, list) else str(tit).split("|")
            partes.append(f'''<section class="scene dark" style="animation:sceneIn .01s 0s both{sai}">{fundo}
 <div class="kick a" style="{anim('left',.5,.15)}">{E(sc.get('chapeu',''))}</div>
 <h1 class="T hook">{''.join(f'<span class="a" style="{anim("slam",.55,.35+j*.45)}">{hl(x)}</span>' for j,x in enumerate(tit[:4]))}</h1></section>''')
        elif tipo == "lista":
            ap = sc.get("apagado")
            rows = "".join(f'<div class="crit {"off" if ap == j+1 else ""} a" style="{anim("left",.45,t0+1.2+j*.45)}"><i>{j+1}</i><span>{E(x)}</span></div>' for j, x in enumerate(sc.get("itens", [])[:5]))
            partes.append(f'''<section class="scene dark" style="animation:sceneIn .35s {t0:.2f}s both{sai}"><div class="glow"></div>
 <div class="kick a" style="{anim('left',.5,t0+.1)}">{E(sc.get('chapeu',''))}</div>
 <h2 class="T a" style="{anim('slam',.55,t0+.25)}">{linhas(sc.get('titulo',''))}</h2>
 <div class="crits">{rows}</div></section>''')
        elif tipo == "cta":
            pal = str(sc.get("palavra", "EU QUERO")).upper()
            tam = max(100, min(200, int(1500 / max(1, len(pal)))))
            letras = "".join(f'<span class="a" style="{anim("drop",.4,t0+.9+j*.09)}">{E(ch)}</span>' for j, ch in enumerate(pal))
            bl = "".join(f'<li class="a" style="{anim("left",.45,t0+2.2+j*.35)}">{E(x)}</li>' for j, x in enumerate(sc.get("itens", [])[:4]))
            partes.append(f'''<section class="scene cta" style="animation:sceneIn .35s {t0:.2f}s both">
 <div class="kick a" style="{anim('left',.5,t0+.1)};color:#fff;opacity:.85">{E(sc.get('chapeu',''))}</div>
 <div class="ctabox a" style="{anim('pop',.55,t0+.35)}"><div class="kick" style="position:static;color:#fff;opacity:.6">Comenta</div>
 <div class="word" style="font-size:{tam}px;animation:pulse 1.1s {t0+2.0:.2f}s infinite ease-in-out">{letras}</div>
 <small class="a" style="{anim('up',.5,t0+1.6)}">{hl(sc.get('depois',''))}</small><ul>{bl}</ul></div>
 <div class="sig a" style="{anim('up',.5,t0+3.0)}">{E(c.get('arroba',''))}</div></section>''')
        else:
            imgs = sc.get("imagens") or ([sc["imagem"]] if sc.get("imagem") else [])
            esc = escuro(imgs[0], base) if imgs else None
            dark = (not esc) if esc is not None else (i % 2 == 1)   # fundo contrasta com a imagem
            if len(imgs) >= 2:
                meio = t0 + vao * .5
                trilho = (f'<img src="{b64(imgs[0], base)}" style="{anim("kb", vao+.5, t0, "both linear")}">'
                          f'<div class="slw a" style="{anim("slideIn",.5,meio)}"><img src="{b64(imgs[1], base)}" style="{anim("kb", vao*.5+.5, meio, "both linear")}"></div>')
            elif imgs:
                trilho = f'<img src="{b64(imgs[0], base)}" style="{anim("kb", vao+.5, t0, "both linear")}">'
            else:
                trilho = ""
            card = f'<div class="card a" style="{anim("pop",.6,t0+.4)}">{trilho}</div>' if trilho else ""
            partes.append(f'''<section class="scene {'dark' if dark else 'light'}" style="animation:sceneIn .35s {t0:.2f}s both{sai}">
 {'<div class="glow"></div>' if dark else ''}<div class="kick a" style="{anim('left',.5,t0+.1)}">{E(sc.get('chapeu',''))}</div>
 <h2 class="T a" style="{anim('up',.55,t0+.2)}">{linhas(sc.get('titulo',''))}</h2>{card}</section>''')
    caps = []
    if c.get("legendas", True):
        for i, sc in enumerate(cenas):
            f = sc.get("fala")
            if not f: continue
            pal, cur, blocos = f.split(), [], []
            for w in pal:
                cur.append(w)
                if len(cur) >= 5 or (re.search(r"[.:?!,]$", w) and len(cur) >= 3): blocos.append(" ".join(cur)); cur = []
            if cur: blocos.append(" ".join(cur))
            tot = sum(len(b) for b in blocos) or 1; t = ini[i]
            for b in blocos:
                d = durs[i] * len(b) / tot
                for k, v in (c.get("legenda_trocas") or {}).items(): b = b.replace(k, v)
                caps.append(f'<div class="cap" style="animation:capIn .18s {t:.2f}s both,capOut .12s {t+d-.06:.2f}s forwards"><span>{E(b)}</span></div>')
                t += d
    css = f"""{fontes_embutidas([FT, FX])}
:root{{--ink:{dk};--or:{ac};--cr:{lt}}}
*{{margin:0;padding:0;box-sizing:border-box}}
html,body{{width:1080px;height:1920px;overflow:hidden;background:var(--ink)}}
body{{font-family:'{FX}',sans-serif;color:#fff;position:relative}}
em{{font-style:normal;color:var(--or)}}
.scene{{position:absolute;inset:0;overflow:hidden;opacity:0}}
.dark{{background:var(--ink)}} .light{{background:var(--cr);color:var(--ink)}}
.T{{font-family:'{FT}',sans-serif;text-transform:uppercase;line-height:.98;letter-spacing:1px;font-weight:900}}
.kick{{position:absolute;top:290px;left:80px;font-weight:800;letter-spacing:6px;font-size:30px;color:var(--or);text-transform:uppercase}}
h2.T{{position:absolute;top:340px;left:80px;right:80px;font-size:112px}}
.card{{position:absolute;left:220px;top:620px;width:640px;height:800px;border-radius:28px;overflow:hidden;box-shadow:0 40px 90px rgba(0,0,0,.4)}}
.slw{{position:absolute;inset:0}} .card img{{position:absolute;inset:0;width:100%;height:100%;object-fit:cover}}
.glow{{position:absolute;width:1200px;height:1200px;border-radius:50%;background:radial-gradient(circle,{ac}40,transparent 65%);left:-60px;top:560px}}
.bgimg{{position:absolute;inset:-40px;background-size:220%;background-position:70% 100%;filter:blur(3px) brightness(.75)}}
.shade{{position:absolute;inset:0;background:linear-gradient(180deg,{dk}EB 0%,{dk}8C 45%,{dk}D9 100%)}}
.hook{{position:absolute;top:360px;left:76px;right:60px;font-size:150px}} .hook span{{display:block}}
.crits{{position:absolute;top:760px;left:80px;right:80px;display:flex;flex-direction:column;gap:26px}}
.crit{{display:flex;align-items:center;gap:30px;font-family:'{FT}';font-size:86px;text-transform:uppercase;background:rgba(255,255,255,.06);border:2px solid rgba(255,255,255,.12);border-radius:26px;padding:22px 34px}}
.crit i{{font-style:normal;width:100px;height:100px;border-radius:22px;background:var(--or);display:flex;align-items:center;justify-content:center;font-size:64px;flex:none}}
.crit.off{{color:rgba(255,255,255,.3)}} .crit.off i{{background:#444;color:rgba(255,255,255,.5)}} .crit.off span{{text-decoration:line-through;text-decoration-color:var(--or);text-decoration-thickness:8px}}
.cta{{background:linear-gradient(160deg,{ac},{ac} 55%,{ac}CC)}}
.ctabox{{position:absolute;top:360px;left:80px;right:80px;background:var(--ink);border-radius:36px;padding:56px 60px 60px}}
.word{{display:flex;flex-wrap:wrap;gap:2px;font-family:'{FT}';font-weight:900;line-height:1;margin-top:8px;color:var(--or)}}
.ctabox small{{display:block;font-size:42px;color:rgba(255,255,255,.85);margin:20px 0 14px}}
.ctabox ul{{list-style:none;display:flex;flex-direction:column;gap:14px}}
.ctabox li{{font-size:38px;font-weight:700;padding-left:40px;position:relative}}
.ctabox li:before{{content:"";position:absolute;left:0;top:16px;width:16px;height:16px;border-radius:50%;background:var(--or)}}
.sig{{position:absolute;top:1260px;left:0;right:0;text-align:center;font-weight:800;font-size:44px}}
.prog{{position:absolute;top:70px;left:80px;right:80px;height:8px;border-radius:8px;background:rgba(128,128,128,.25);z-index:5;overflow:hidden}}
.prog b{{display:block;height:100%;background:var(--or);transform-origin:left;animation:grow {total}s 0s both linear}}
.cap{{position:absolute;left:60px;right:60px;top:1470px;text-align:center;opacity:0;z-index:6}}
.cap span{{display:inline-block;background:{dk}E0;color:#fff;font-weight:800;font-size:46px;line-height:1.25;padding:16px 28px;border-radius:18px;max-width:900px;border:2px solid rgba(255,255,255,.14)}}
@keyframes sceneIn{{from{{opacity:0}}to{{opacity:1}}}}
@keyframes sceneOut{{from{{opacity:1;transform:none}}to{{opacity:0;transform:translateY(-100px) scale(.97)}}}}
@keyframes slam{{0%{{opacity:0;transform:scale(1.7) rotate(-3deg);filter:blur(12px)}}60%{{opacity:1;transform:scale(.97);filter:blur(0)}}100%{{opacity:1;transform:scale(1)}}}}
@keyframes up{{from{{opacity:0;transform:translateY(60px)}}to{{opacity:1;transform:none}}}}
@keyframes left{{from{{opacity:0;transform:translateX(-80px)}}to{{opacity:1;transform:none}}}}
@keyframes pop{{0%{{opacity:0;transform:scale(.4)}}70%{{opacity:1;transform:scale(1.05)}}100%{{opacity:1;transform:scale(1)}}}}
@keyframes grow{{from{{transform:scaleX(0)}}to{{transform:scaleX(1)}}}}
@keyframes pulse{{0%,100%{{transform:scale(1)}}50%{{transform:scale(1.05)}}}}
@keyframes drop{{0%{{opacity:0;transform:translateY(-200px) rotate(-10deg)}}65%{{opacity:1;transform:translateY(14px)}}100%{{opacity:1;transform:none}}}}
@keyframes kb{{from{{transform:scale(1)}}to{{transform:scale(1.08)}}}}
@keyframes slideIn{{from{{opacity:0;transform:translateX(100%)}}to{{opacity:1;transform:none}}}}
@keyframes capIn{{from{{opacity:0;transform:translateY(16px) scale(.96)}}to{{opacity:1;transform:none}}}}
@keyframes capOut{{to{{opacity:0}}}}
.a{{opacity:0;animation-fill-mode:both;animation-timing-function:cubic-bezier(.2,.8,.2,1)}}
"""
    return f"""<!doctype html><html lang="pt-BR"><head><meta charset="utf-8"><style>{css}</style></head><body>
{''.join(partes)}<div class="prog"><b></b></div>{''.join(caps)}
<script>window.seek=ms=>document.getAnimations().forEach(x=>{{x.pause();x.currentTime=ms}});</script></body></html>"""

# ------------------------------------------------------------------ áudio
SR = 44100
def trilha_e_efeitos(cenas, ini, cena_t, total, voz_arqs, ff, destino):
    import numpy as np
    N = int(SR * total); rng = np.random.default_rng(3)
    fx = np.zeros((N, 2)); bed = np.zeros((N, 2)); voz = np.zeros(N)
    t = lambda d: np.arange(int(SR * d)) / SR
    def add(buf, sig, at, g=1.0, pan=0.0):
        i = int(at * SR); sig = sig[:max(0, len(buf) - i)]
        if buf.ndim == 1: buf[i:i+len(sig)] += sig * g; return
        buf[i:i+len(sig), 0] += sig * g * (1 - pan); buf[i:i+len(sig), 1] += sig * g * (1 + pan)
    hpn = lambda n, k=8: n - np.convolve(n, np.ones(k) / k, "same")
    def impact():
        x = t(.6); f = 110*np.exp(-x*9)+45; b = np.sin(2*np.pi*np.cumsum(f)/SR)*np.exp(-x*6)
        return np.tanh((b + hpn(rng.standard_normal(len(x)))*np.exp(-x*60)*.25)*1.6)*.9
    def whoosh(d=.55, up=True):
        x = t(d); e = np.sin(np.pi*np.linspace(0, 1, len(x)))**1.5
        k = np.linspace(.3, 1, len(x)) if up else np.linspace(1, .3, len(x))
        return hpn(rng.standard_normal(len(x)))*e*k*.5
    def pop(f=600):
        x = t(.18); fr = f*(1+.8*np.exp(-x*40)); return np.sin(2*np.pi*np.cumsum(fr)/SR)*np.exp(-x*28)*.6
    key = lambda: hpn(rng.standard_normal(int(SR*.05)), 6)*np.exp(-t(.05)*120)*.9
    beat = .6; acordes = [(220, 261.6, 329.6), (196, 246.9, 293.7), (174.6, 220, 261.6), (196, 246.9, 293.7)]
    for comp in range(int(total / (beat * 4)) + 1):
        at = comp * beat * 4; x = t(beat * 4 + .5)
        pad = sum(np.sin(2*np.pi*f*x) + .3*np.sin(4*np.pi*f*x) for f in acordes[comp % 4]) / 3
        add(bed, pad * np.minimum(1, x/.6) * np.minimum(1, (beat*4+.5-x)/.5) * .18, at)
        for b in range(4):
            y = t(.3); f = 130*np.exp(-y*25)+48
            add(bed, np.sin(2*np.pi*np.cumsum(f)/SR)*np.exp(-y*9)*.45, at + b*beat)
            add(bed, hpn(rng.standard_normal(int(SR*.04)), 4)*np.exp(-t(.04)*90)*.18, at + b*beat + beat/2, pan=.3)
    fade = np.ones(N); fade[:int(SR*.5)] = np.linspace(0, 1, int(SR*.5)); fade[-int(SR*2):] = np.linspace(1, 0, int(SR*2))
    bed *= fade[:, None]
    for s in cena_t[1:]: add(fx, whoosh(), s - .3, .7)
    for i, sc in enumerate(cenas):
        t0 = cena_t[i]; tipo = sc.get("tipo", "imagem")
        if tipo == "abertura":
            tit = sc.get("titulo", []); n = len(tit if isinstance(tit, list) else str(tit).split("|"))
            for j in range(min(n, 4)): add(fx, impact(), .35 + j*.45 + .33, .8)
        elif tipo == "lista":
            add(fx, impact(), t0 + .58, .7)
            for j in range(len(sc.get("itens", [])[:5])): add(fx, pop(500 + j*80), t0 + 1.4 + j*.45, .5)
        elif tipo == "cta":
            add(fx, impact(), t0 + .73, .8)
            for j in range(len(str(sc.get("palavra", "")))): add(fx, key(), t0 + 1.16 + j*.09, .6)
        else:
            add(fx, pop(600), t0 + .82, .6)
            if len(sc.get("imagens") or []) >= 2:
                add(fx, whoosh(.45, False), t0 + ((cena_t[i+1] if i+1 < len(cena_t) else total) - t0)*.5, .6)
    if voz_arqs:
        import soundfile as sf
        for i, a in enumerate(voz_arqs):
            if not a: continue
            v, sr = sf.read(a); v = v if v.ndim == 1 else v.mean(1)
            if sr != SR: v = np.interp(np.arange(0, len(v), sr / SR), np.arange(len(v)), v)
            add(voz, v, ini[i])
        env = np.convolve(np.abs(voz), np.ones(int(SR*.08))/int(SR*.08), "same")
        duck = 1 - .55*np.clip(env / (env.max()*.15 + 1e-9), 0, 1)
        musica = (bed + fx) * duck[:, None]
        out = musica*.8 + voz[:, None]
    else:
        out = (bed*1.3 + fx)
    out = out / (np.max(np.abs(out)) + 1e-9) * .95
    with wave.open(destino, "wb") as w:
        w.setnchannels(2); w.setsampwidth(2); w.setframerate(SR); w.writeframes((out*32767).astype("<i2").tobytes())

def limpar_voz(ff, arq, pasta, i):
    """Tira silêncio do começo/fim e converte pra wav."""
    d = os.path.join(pasta, f"v{i}.wav")
    subprocess.run([ff, "-y", "-loglevel", "error", "-i", arq, "-af",
        "silenceremove=start_periods=1:start_threshold=-45dB,areverse,silenceremove=start_periods=1:start_threshold=-45dB,areverse",
        "-ar", str(SR), "-ac", "1", d], check=True)
    return d

# ------------------------------------------------------------------ principal
def main():
    if len(sys.argv) < 3: print(__doc__); sys.exit(1)
    cfgp, out = sys.argv[1], sys.argv[2]
    c = json.load(open(cfgp, encoding="utf-8")); base = os.path.dirname(os.path.abspath(cfgp))
    os.makedirs(out, exist_ok=True); trab = tempfile.mkdtemp()
    for pkg in ("numpy", "soundfile"):
        try: __import__(pkg)
        except Exception: subprocess.run([sys.executable, "-m", "pip", "install", "-q", "--break-system-packages", pkg], capture_output=True)
    ff = achar_ffmpeg()
    cenas = c["cenas"]; falas = [sc.get("fala", "") for sc in cenas]
    nar = c.get("narracao") or {}; modo = nar.get("modo", "nenhuma"); info = "sem narração"; voz_arqs = None
    previa = "--previa" in sys.argv
    if not previa and modo != "nenhuma":
        brutos = None
        if modo == "audio" and nar.get("audios"):
            brutos = [a if os.path.isabs(a) else os.path.join(base, a) for a in nar["audios"]]; info = "áudios enviados"
        elif modo == "elevenlabs":
            chave = nar.get("elevenlabs_chave") or os.environ.get("ELEVENLABS_API_KEY", "")
            brutos = voz_elevenlabs(falas, trab, chave, nar.get("elevenlabs_voz")) if chave else None
            info = "ElevenLabs" if brutos else "ElevenLabs falhou (sem chave ou sem acesso)"
        elif modo == "gratis":
            brutos, qual = voz_gratis(falas, trab, nar.get("voz", "pm_alex"), float(nar.get("velocidade", .9)))
            info = f"voz {qual}" if brutos else "voz gratuita indisponível"
        if brutos:
            voz_arqs = [limpar_voz(ff, a, trab, i) for i, a in enumerate(brutos)]
        else:
            print("AVISO:", info, "- seguindo sem narração")
    durs_voz = [duracao(ff, a) for a in voz_arqs] if voz_arqs else [None] * len(cenas)
    ini, durs, cena_t, total = linha_do_tempo(cenas, durs_voz)
    hp = os.path.join(out, "reels-motion.html")
    open(hp, "w", encoding="utf-8").write(montar_html(c, base, ini, durs, cena_t, total))
    if previa:
        ok = render_quadros(hp, out, [min(total - .1, s + 2.2) for s in cena_t])
        print("previa:", "ok" if ok else "sem navegador", out, "| duração estimada sem voz:", total, "s"); return
    if not render_quadros(hp, os.path.join(trab, "q"), [i / FPS for i in range(int(total * FPS))]):
        print("ERRO: sem navegador pra gerar o vídeo."); sys.exit(2)
    if not ff: print("ERRO: sem ffmpeg."); sys.exit(3)
    aud = os.path.join(trab, "audio.wav")
    try: trilha_e_efeitos(cenas, ini, cena_t, total, voz_arqs, ff, aud)
    except Exception as e: print("AVISO: sem áudio:", e); aud = None
    final = os.path.join(out, "reels-motion.mp4")
    cmd = [ff, "-y", "-loglevel", "error", "-framerate", str(FPS), "-i", os.path.join(trab, "q", "f%04d.jpg")]
    if aud: cmd += ["-i", aud, "-af", "highpass=f=60,loudnorm=I=-14:TP=-1.5:LRA=11", "-ar", "44100", "-c:a", "aac", "-b:a", "192k", "-shortest"]
    cmd += ["-c:v", "libx264", "-pix_fmt", "yuv420p", "-profile:v", "high", "-crf", "19", "-movflags", "+faststart", final]
    subprocess.run(cmd, check=True)
    subprocess.run([ff, "-y", "-loglevel", "error", "-ss", "2.2", "-i", final, "-frames:v", "1", os.path.join(out, "capa.jpg")])
    shutil.rmtree(trab, ignore_errors=True)
    aviso = "  ATENÇÃO: passou de 58 s, encurte as falas." if total > 58.5 else ("  ATENÇÃO: menos de 30 s." if total < 29 else "")
    print(f"ok {final} | {total:.1f} s | {info}{aviso}")

if __name__ == "__main__":
    main()
