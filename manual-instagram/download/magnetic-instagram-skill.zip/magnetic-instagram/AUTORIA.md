# Autoria e créditos obrigatórios

Quem copiar, adaptar, revender ou redistribuir este material (inteiro ou em parte) precisa manter, de forma visível, os créditos abaixo. Isso vale para a skill, o plugin, versões traduzidas, versões com outro nome e materiais derivados (cursos, e-books, templates) que usem estes textos.

## Crédito principal (obrigatório)

> Magnetic Instagram · criado por **Rodrigo Mendes** (@rodrigomendesfn), **Magnetic Flows** — https://rodrigomendesfn.com.br/

Em versões adaptadas, use: "Baseado no Magnetic Instagram, criado por Rodrigo Mendes (@rodrigomendesfn), Magnetic Flows — https://rodrigomendesfn.com.br/". Coautores de versões derivadas podem acrescentar o próprio nome, mas não podem remover os créditos anteriores.

## Créditos de terceiros (obrigatórios)

- Partes do método de Reels, legenda, perfil, semana, Stories, reaproveitamento e análise: adaptadas de "instagram-agent-skill", de Jake Schincariol (licença MIT) — https://github.com/Jakeschincariol/instagram-agent-skill

## Onde o crédito deve aparecer

- No início do SKILL.md (já está lá — não remova).
- No README ou na página de venda/distribuição.
- Na página do Radar gerada pela skill (seção final — não remova).

## Contato

Instagram @rodrigomendesfn · https://rodrigomendesfn.com.br/ · https://comunidade.magneticflows.com/
