# Opção 12: Reels Motion (vídeo animado narrado, 30 a 58 s)

Um Reels em vídeo feito a partir de um conteúdo (normalmente um carrossel pronto): cenas com movimento, as telas do carrossel aparecendo, legendas na tela sincronizadas com a fala, trilha calma, efeitos sonoros e narração opcional. Sai pronto pra postar (MP4 1080×1920) e pode ir direto pro agendamento (opção 10).

## Entrada (uma pergunta por vez)

1. **Sobre o quê?** Peça o carrossel (link, imagens ou o que a skill acabou de criar) ou o tema. Com carrossel, use as telas dele como imagens das cenas. Confirme em uma linha qual conteúdo vai usar.
2. **Palavra-chave do comentário** (ex.: "GOOGLE3P"). Se estiver no último slide, só confirme.
3. **Narração.** Pergunte exatamente assim:

```
Quer narração no Reels?

 1. Sim, com voz gratuita
 2. Sim, com ElevenLabs (voz mais realista)
 3. Não, só trilha, efeitos e legendas na tela
```

- **1. Voz gratuita:** ofereça as 3 vozes (Alex e Santa masculinas, Dora feminina). Se a pessoa não escolher, use Alex. Velocidade 0.9 (calma e clara). Se quiser ouvir antes, gere uma frase de amostra com cada voz e mande.
- **2. ElevenLabs:** antes de tudo, veja se a ElevenLabs já está conectada (ferramentas com "elevenlabs" no nome).
  - **Conectada:** gere um áudio por cena com a ferramenta de texto-pra-fala do conector, na voz que a pessoa escolher, e use o modo `audio` passando os arquivos na ordem das cenas.
  - **Não conectada:** peça pra conectar. Procure "ElevenLabs" no diretório de conectores e mostre o botão de conectar. Depois que ela conectar, siga como acima.
  - **Sem conector disponível ou se a pessoa não quiser conectar:** peça a chave da API da ElevenLabs (no site: Perfil → API Keys) e use o modo `elevenlabs`. Nunca guarde a chave na memória nem em arquivo da pessoa.
  - Se ela não quiser nada disso, ofereça a voz gratuita.
- **3. Sem narração:** as legendas viram o texto principal na tela e o tempo de cada cena é calculado pela leitura.

## O roteiro (5 a 10 cenas, de 30 a 58 s no total)

| Cena | Tipo | O que mostra | Fala |
|---|---|---|---|
| 1 | `abertura` | título que "bate" na tela em 2–4 linhas, capa do carrossel desfocada no fundo | o gancho (fórmulas de `references/ganchos.md`), até ~18 palavras |
| 2 | `lista` (opcional) | 2 a 5 itens que entram um por um; dá pra riscar um (`apagado`) | a virada ou a boa notícia |
| 3 a 8 | `imagem` | chapéu + título + 1 ou 2 telas do carrossel com zoom lento (2 telas = troca no meio da cena) | uma ideia por cena, até ~22 palavras |
| última | `cta` | a palavra caindo letra por letra + o que a pessoa recebe | "Quer X? Comenta PALAVRA, que eu te mando..." |

Regras do texto:
- **Uma ideia por cena.** Fala curta, frase de quem conversa, sem "cara de IA" (`references/escrita.md`).
- **Tempo:** cada cena dura o tempo da fala. Mire em 30 a 58 s no total. A ferramenta avisa se passar de 58 s: aí encurte as falas mais longas e gere de novo.
- **Escreva a fala como se fala:** "GOOGLE3P" vira "Google três pê", números por extenso. Use `legenda_trocas` pra legenda mostrar a forma escrita (`{"Google três pê": "GOOGLE3P"}`).
- Títulos com no máximo 2 linhas curtas; `*palavra*` pinta de destaque e `|` quebra a linha.
- Cores, fontes e @ vêm da configuração.
- Mostre o roteiro (cenas + falas) antes de gerar e espere o "ok".

## Como gerar

1. Copie as telas do carrossel pra uma pasta de trabalho.
2. Monte o `reels.json` (formato completo no topo de `scripts/reels_motion.py`) com as cenas, as falas, as cores e o bloco `narracao`.
3. Rode a prévia (`--previa`): sai uma imagem por cena. Olhe e corrija texto cortado ou sobreposto.
4. Gere o vídeo. A última linha diz a duração e qual voz foi usada. A primeira vez com voz gratuita demora mais (baixa a voz, uns 350 MB, uma vez só).
5. Entregue o vídeo com a legenda pronta (regras da opção 4, no máximo 5 hashtags) e ofereça agendar (opção 10, `type: reel`, um vídeo só). Também sai uma `capa.jpg`.

Sem navegador ou sem ffmpeg no ambiente: entregue o roteiro cena a cena e as falas pra pessoa montar no CapCut.

## Entrega

- Mande o vídeo e diga em uma frase como ele é (duração, voz, quantas cenas).
- A trilha e os efeitos são sintetizados pela ferramenta, sem direitos autorais. Se a pessoa for usar uma música do Instagram, sugira deixar em ~20% pra não brigar com a voz.
- Ajustes comuns: trocar a voz, deixar mais lento ou mais rápido (`velocidade` de 0.8 a 1.1), tirar um efeito, mudar uma fala. Refaça só o necessário.

Nada é postado sem a pessoa dizer "sim".
