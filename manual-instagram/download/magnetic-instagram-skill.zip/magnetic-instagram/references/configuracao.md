# Configuração inicial (opção 0 e primeira vez)

Feita uma vez só. Tudo que as outras opções precisam sai daqui, então faça com calma.

## Antes de começar: recomende um Projeto do Claude

Diga, em poucas linhas:

> Dica pra render mais: crie um **Projeto** no Claude chamado "Instagram @seuarroba" e use a skill sempre dentro dele. No fim desta configuração eu te entrego um arquivo com tudo. Você coloca esse arquivo nos arquivos do Projeto (ou cola nas instruções dele) e junta também seu logo, suas fotos e prints de posts seus. Assim toda conversa já começa sabendo seu nicho, suas cores e seu jeito de falar, sem perguntar de novo.

Se a pessoa já estiver dentro de um Projeto, só avise que vai deixar tudo salvo ali.

## As perguntas

Dê as boas-vindas em uma frase e diga que são algumas perguntas, uma por vez. Se a ferramenta de perguntas com opções estiver disponível, use nas perguntas de escolha; nas abertas, pergunte em texto. Aceite "pula" em qualquer uma que não seja obrigatória e siga.

**Sobre você e o negócio (obrigatórias)**
1. Seu nome e seu @ no Instagram.
2. O que você faz, em uma frase. E seu nicho, com 3 a 5 temas que quer comunicar.
3. Quem é seu cliente ideal: quem compra de você, com o máximo de detalhe (profissão, faixa de faturamento, cidade ou região, o que já tentou).
4. As 3 maiores dores ou desejos desse cliente, nas palavras dele. Se ela tiver prints de comentários, directs ou perguntas que recebe, peça: as palavras do cliente valem mais que qualquer resumo.
5. Sua oferta principal: o que vende, preço (ou faixa) e o que a pessoa ganha. Se tiver uma oferta de entrada e uma maior, anote as duas.
6. Sua chamada: como a pessoa pede (palavra-chave no comentário, ex.: "Comenta GUIA", link na bio, direct). Avise que a palavra tem que ser idêntica à da automação de direct, se ela usar uma.
7. Seus links: site, página de vendas, link da bio.

**Sua voz (muito importante para Reels e legendas)**
8. Cole 3 legendas ou roteiros seus que mais parecem com você. (Se ela não tiver, pergunte como fala: rápido e animado, calmo, engraçado, direto, técnico.)
9. Palavras e expressões que você usa muito, e as que nunca diria.
10. Você aparece nos vídeos? (sempre, às vezes, nunca) Fala para a câmera ou em narração?
11. Emoji nas legendas: nunca, pouco ou à vontade? Palavrão: sim, leve ou não?
12. 3 a 5 posições suas que parte do seu público discorda (ex.: "não precisa postar todo dia"). Elas viram os melhores Reels de opinião.

**Visual**
13. Cores da marca (códigos, ou "me manda um print de um post seu" — se ela mandar, extraia as cores principais do print).
14. Fontes. Se não souber, sugira uma dupla do Google Fonts: uma forte para títulos e uma leve para o texto (ex.: Barlow Condensed + Plus Jakarta Sans; Anton + Inter; Bebas Neue + DM Sans).
15. Fotos suas para capas de carrossel e logo (opcional). Se estiver em um Projeto, peça para ela subir nos arquivos do Projeto.
16. **Estilo dos carrosséis.** Gere a galeria com as cores e fontes dela (`python3 scripts/carrossel.py config.json galeria/ --galeria`, com um JSON só com cores, fontes, @, nome e foto) e mostre a imagem `galeria-estilos.png`. São 6 estilos: Impacto, Editorial, Tweet, Caderno, Gradiente e Minimal. Pergunte: "Qual estilo você quer? Pode escolher um fixo, pedir pra eu alternar entre eles (cada carrossel sai num estilo diferente, sempre nas suas cores) ou me mandar um print de um carrossel que você gosta." Se não der pra gerar a galeria, descreva os 6 estilos em uma linha cada.

**Rotina**
17. Quantos posts por semana você consegue manter de verdade, e de que tipo (carrossel, Reels, Stories)?
18. Seu fuso e os melhores horários (se não souber, deixe "a definir" — a opção 9 descobre).

**Radar (só se for usar a opção 1)**
19. Perfis de referência: "Você tem de 10 a 15 perfis do seu nicho que admira?" Se não tiver, você mesmo pesquisa: busca na web por "melhores perfis de [nicho] no Instagram" e, se o Apify estiver conectado, busca de perfis com os temas. Descarte perfis fora do nicho, de outro país (se ela for do Brasil) e com menos de 1.000 seguidores. Mostre 10 a 15 sugestões com uma linha sobre cada um para ela aprovar. Prefira quem posta bastante carrossel.
20. Formato preferido do Radar: carrossel, Reels ou os dois.
21. Rodada automática: quer que o Radar rode sozinho? Em quais dias e horário? (opcional)

A parte do HighLevel NÃO entra aqui. Ela é configurada só quando a pessoa pedir para agendar pela primeira vez (opção 10).

## O bloco de configuração

Monte com as respostas:

```
Configuração Magnetic Instagram
Nome e @: 
O que faço: 
Nicho e temas: 
Cliente ideal: 
Dores e desejos (nas palavras do cliente): 
Oferta principal (e preço): 
Oferta de entrada: 
Chamada (palavra-chave ou link): 
Links: 
Voz — exemplos meus: 
Voz — jeito de falar: 
Palavras que uso / nunca uso: 
Aparece no vídeo: 
Emoji / palavrão: 
Minhas posições: 
Cores: #......, #......, #......
Fontes: títulos ... / texto ...
Estilo dos carrosséis: (impacto, editorial, tweet, caderno, gradiente, minimal, "alternar" ou "igual ao meu exemplo")
Último estilo usado: (preenchido automaticamente)
Fotos e logo: (onde estão)
Rotina: (posts por semana e formatos)
Fuso e horários: 
Perfis de referência: @..., @..., @...
Formato preferido do Radar: 
Rodada automática: 
Página do Radar: (link, preenchido depois da primeira rodada)
Agendamento no HighLevel: (preenchido na opção 10)
```

## Onde salvar (em todos os lugares disponíveis)

1. **Projeto do Claude:** se a conversa estiver em um Projeto, gere o arquivo `instagram-config.md` com o bloco e entregue para ela colocar nos arquivos do Projeto (diga em uma linha como: abrir o Projeto, "Adicionar conteúdo", enviar o arquivo). Esse é o jeito recomendado.
2. **Memória do Claude**, se existir na conversa.
3. **Skill pessoal instagram-minha-config**, se a ferramenta de propor skills estiver disponível. Diga para ela clicar em salvar no cartão.
4. Se nada disso existir, entregue o bloco e o arquivo e peça para ela guardar e colar no começo da conversa quando for usar.

Se ela pediu rodada automática do Radar, crie a tarefa agendada (ver "Rodada agendada" no SKILL.md).

## Depois de salvar

Mostre um resumo de 3 linhas do que entendeu (nicho, cliente, oferta e chamada) e pergunte se está certo. Depois explique em uma linha que ela pode digitar INICIAR a qualquer momento pra voltar ao menu, e mostre o menu. Na primeira vez, sugira começar pela opção 1 (Radar) ou pela 5 (nota do perfil) — são as que dão o primeiro "uau".

## Mudar a configuração (opção 0)

Mostre o bloco atual e pergunte o que mudar. Atualize em todos os lugares onde está salvo e entregue o arquivo novo se ela usar Projeto.
