# Opção 6: Plano da semana

A sala de controle. As outras opções executam; esta decide o que executar. Ideal rodar uma vez por semana, no mesmo dia.

## Entrada

Use a configuração (temas, oferta, cliente, rotina, horários), o histórico (pra não repetir tema das últimas 2 semanas) e o que o Radar e a análise mostraram por último (formatos e fórmulas que estão funcionando no nicho — valem mais que as regras daqui).

Pergunte só uma coisa: **"O que aconteceu na sua semana?"** Uma conversa com cliente, um número, um erro, algo que você construiu, uma discussão. É daí que saem os posts. Se ela não tiver nada, use os temas da configuração e o Radar.

## O que postar

A quantidade é a da rotina da configuração. Se ela não disse, sugira de 4 a 5 posts por semana, pelo menos 2 Reels (é o formato que chega em quem não segue) e carrosséis pra aprofundar com quem já segue. Stories são diários e planejados à parte (opção 7).

Misture ao longo da semana, nunca dois do mesmo tipo seguidos:

| Tipo | Quantos | Função |
|---|---|---|
| **Prova** | 1 por semana | algo que aconteceu, com número. Reels ou carrossel. |
| **Ensino** | 1 a 2 por semana | uma coisa que dá pra fazer hoje. Reels ou carrossel. |
| **Opinião** | 1 por semana | uma posição que pode fazer perder seguidor (das "posições" da configuração). Reels. |
| **História** | 1 a cada 2 semanas | uma cena com um custo. Reels. |
| **Oferta** | 1 a cada 2 semanas | o que vende, dito sem vergonha. Carrossel ou Stories. |

Para uma conta que usa conteúdo pra vender, mantenha a proporção de umas 3 peças de atrair pra cada 1 de vender.

Para cada post: o tipo, o ângulo específico (não o tema: "IA" não é plano; "a proposta que perdi porque demorei 2 dias pra responder" é um Reels), o formato, o número da fórmula de gancho (`references/ganchos.md`) e o horário.

## Quando postar

Quando o público dela está acordado e fora do trabalho: pra consumidor final, normalmente começo da noite; pra público empresarial, começo da manhã ou almoço. Use o fuso do público.

Mas diga com clareza: **o horário importa muito menos que os 2 primeiros segundos.** O Instagram continua mostrando um Reels bom por dias. Se o gancho não funciona, ajustar horário é polir a coisa errada.

## A rodada de interação (20 minutos por dia, antes de postar)

Uma lista de 10 contas pra comentar de verdade (comentário com conteúdo, nunca "🔥🔥🔥"):
- **5 de alcance:** contas com o público que ela quer. Comentar cedo.
- **3 parecidas:** mesmo tamanho, mesmo assunto. É quem retribui.
- **2 compradores:** gente que pode comprar. Comentar por semanas antes de qualquer direct, e nunca vender no comentário.

Sugira as 10 a partir dos perfis de referência e do nicho da configuração.

## Entrega

```
SEMANA DE 12/10

SEG  só interação (20 min, lista abaixo)
TER  19h30  REELS      PROVA    fórmula 5  Tempo que encolheu — proposta de 5h pra 20 min
QUA  só Stories + interação
QUI  19h    CARROSSEL  ENSINO   capa: "A CLÁUSULA DE R$18 MIL"
SEX  19h30  REELS      OPINIÃO  fórmula 2  Pare e faça — pare de fazer reunião de diagnóstico
SÁB  —
DOM  18h    REELS      HISTÓRIA fórmula 21 Começo no meio da frase — o e-mail do reembolso

STORIES  todo dia, 3 a 5 telas, caixa de perguntas na quinta.
INTERAÇÃO  (5 alcance / 3 parecidas / 2 compradores)
  ...

Diga "escreve a terça" que eu faço.
```

Salve o plano onde der (Projeto, memória ou `instagram-plano.md`). Quando ela pedir um dia, faça pela opção 2 ou 3. Carrosséis prontos podem ser agendados pela opção 10. Nada é postado sem ela.
