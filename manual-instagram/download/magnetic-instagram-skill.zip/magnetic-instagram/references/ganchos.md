# As 26 fórmulas de gancho

Adaptadas para o português a partir do "instagram-agent-skill" (Jake Schincariol, licença MIT).

Um Reels tem dois ganchos ao mesmo tempo, e não são a mesma frase: **o que você fala** (uns 2 segundos) e **o que está escrito na tela** (é lido antes de ser ouvido, até 6 palavras). Os exemplos abaixo são genéricos: troque sempre pelo nicho, pelo cliente e pelos números da pessoa.

## Regras de todas as fórmulas

- Escreva a fala e o texto da tela separados. O da tela é mais curto e mais seco.
- Sem introdução. O vídeo começa na frase que você normalmente diria no segundo 6.
- Fale o número. "Muito" não é número.
- O primeiro quadro também é gancho: movimento ou texto na tela logo no 0:00.
- Se o gancho serviria pra qualquer outra pessoa do nicho, não é o seu. Coloque o que só ela pode dizer.
- Gancho é promessa: entregue antes da metade do vídeo.

## As fórmulas

| # | Nome | Molde | Exemplo | Na tela | Cuidado |
|---|---|---|---|---|---|
| 1 | Confissão de custo | {Valor} foi o que {um erro} me custou. | R$18 mil foi o que uma cláusula esquecida me custou. | R$18 MIL POR 1 LINHA | Valor inventado destrói a confiança. |
| 2 | Pare e faça | Pare de {ação comum}. Faça {alternativa}. | Pare de postar 3 vezes por dia. Poste 2 e responda todo comentário por uma hora. | PARE DE POSTAR 3X | Precisa da alternativa, senão é só bronca. |
| 3 | Ninguém te conta | Ninguém te conta que {verdade incômoda}. | Ninguém te conta que seus primeiros 30 Reels são pra dar errado. | NINGUÉM TE CONTA ISSO | A verdade tem que incomodar mesmo. |
| 4 | O substituto | {Isso} substituiu {coisa cara} por {preço}. | Uma ferramenta de R$60 substituiu o editor que eu pagava R$2 mil por mês. | R$2 MIL → R$60 | Não compare coisas que não fazem o mesmo trabalho. |
| 5 | Tempo que encolheu | Isso me tomava {tempo longo}. Agora leva {tempo curto}. | Proposta me tomava 5 horas. Agora leva 20 minutos. | 5 HORAS → 20 MIN | A proporção tem que ser crível. |
| 6 | O recibo | Fiz {coisa} por {N dias}. Aqui estão os números reais. | Postei um Reels por dia durante 60 dias. Olha o que aconteceu com meu direct. | 60 DIAS: OS NÚMEROS | Mostre os números de verdade, na tela. |
| 7 | Jeito errado, jeito certo | Você faz {coisa} errado, e a culpa não é sua. {Correção}. | Você escreve legenda errado, e a culpa não é sua. O Instagram esconde tudo depois da primeira linha. | SUA LEGENDA ESTÁ ERRADA | Não humilhe quem assiste. |
| 8 | Bastidor | Passei {N anos} {dentro da coisa}. O que a gente nunca falava. | Passei 6 anos vendendo pra agência. Isso a gente nunca colocava na proposta. | O QUE NINGUÉM FALA | Precisa de experiência real. |
| 9 | Pode copiar | Copia esse {material}. Levei {tempo} pra acertar. | Copia essa mensagem de follow-up de 4 linhas. Levei 2 anos pra acertar. | COPIA ESSE TEXTO | Entregue o material inteiro no vídeo. |
| 10 | Se isso, assista | Se você {situação}, esses {segundos} resolvem. | Se seus Reels têm visualização e zero seguidor, os próximos 40 segundos resolvem. | VIEW SEM SEGUIDOR? | A situação tem que ser bem específica. |
| 11 | Lista com favorito | {N} {coisas} que {resultado}. A número {k} ninguém usa. | 5 ajustes na legenda que dobram os salvamentos. O quarto ninguém faz. | 5 AJUSTES · O 4º | Cumpra: o favorito tem que ser bom. |
| 12 | A objeção | "{Objeção que o cliente fala}." Beleza. Esse é o jeito que funciona mesmo assim. | "Não quero aparecer no vídeo." Beleza. Esse é o jeito sem rosto que vende mesmo assim. | "NÃO QUERO APARECER" | Use a objeção nas palavras exatas do cliente. |
| 13 | Antes e depois na tela | {Mostra o antigo}. {Mostra o novo}. {Uma frase sobre a alavanca}. | Esse era meu perfil em março. Esse é hoje. Mudei só o nome. | ANTES / DEPOIS | O antes tem que ser real. |
| 14 | Chamado direto | {Grupo específico}, esse é o que você vem evitando. | Dono de clínica que atende pelo WhatsApp pessoal: esse é o vídeo que você vem evitando. | DONO DE CLÍNICA, OLHA ISSO | Grupo genérico ("empreendedor") não funciona. |
| 15 | Histórico de fracasso | Meus primeiros {N} {tentativas} deram nada. O que mudou no {N+1}. | Meus primeiros 47 Reels tiveram 300 views. O 48º teve 400 mil. Uma coisa mudou. | 47 FRACASSOS, 1 MUDANÇA | Diga qual foi a mudança. |
| 16 | A pergunta real | "{Pergunta exatamente como chegou}" — recebo toda semana. | "Como postar todo dia sem odiar?" Recebo essa toda semana. | "COMO POSTAR TODO DIA?" | Use perguntas reais (caixinha de Stories, direct). |
| 17 | Frente a frente | {A} contra {B}. Testei os dois por {tempo} e não foi nem perto. | Carrossel contra Reels. Testei os dois por 90 dias e não foi nem perto. | CARROSSEL X REELS | Precisa do teste de verdade. |
| 18 | Já começando | {Começa no meio da ação.} Olha o que isso faz. | Olha o que acontece quando eu colo a legenda do concorrente aqui. | OLHA ISSO | A ação tem que aparecer no primeiro segundo. |
| 19 | O prazo | {Coisa} muda em {data}. Faça {ação} antes. | O Instagram limitou a 5 hashtags por post. Arruma suas legendas antes do próximo post. | SÓ 5 HASHTAGS AGORA | Só com prazo ou mudança verdadeira. |
| 20 | Permissão | Você não precisa de {coisa que todo mundo diz que precisa}. | Você não precisa de nicho. Precisa de uma pessoa que você consegue nomear. | VOCÊ NÃO PRECISA DISSO | Tem que dar o que colocar no lugar. |
| 21 | Começo no meio da frase | "...e foi aí que {a virada}." | ...e foi aí que o cliente pediu o dinheiro de volta. Três dias depois de aprovar. | ...E FOI AÍ QUE | A virada precisa de consequência. |
| 22 | Ditado ao contrário | {Ditado conhecido, invertido.} | Quem espera sempre perde cliente. | QUEM ESPERA PERDE | Tem que ter argumento logo depois. |
| 23 | A estatística | {N}% de {grupo} {fato surpreendente}. | 7 em cada 10 clientes desistem se a resposta demora mais de 1 hora. | 7 EM 10 DESISTEM | Só com fonte real. Cite na legenda. |
| 24 | A novidade | Esse é o novo {coisa}. | Esse é o novo recurso do Instagram que ninguém ativou ainda. | O NOVO {COISA} | Tem que ser novo de verdade. |
| 25 | Resultado de outra pessoa | Teve um {pessoa} que {resultado} em {tempo}. | Teve um dentista que lotou a agenda em 3 semanas só mudando a bio. | 3 SEMANAS, AGENDA CHEIA | Caso real, com permissão, sem exagero. |
| 26 | O superlativo | O jeito mais {rápido / barato / fácil} de {resultado} é {resposta}. | O jeito mais rápido de ganhar confiança é juntar provas que ninguém discute. | O JEITO MAIS RÁPIDO | Precisa entregar a resposta em seguida. |

## Como escolher

- Proposta com número ou resultado → 1, 4, 5, 6, 15.
- Ensinar algo → 7, 9, 10, 11, 18.
- Opinião ou posição (da configuração) → 2, 3, 20, 22.
- Vender sem parecer anúncio → 12, 14, 16, 25.
- Novidade do nicho → 19, 24.
- Se o Radar mostrou uma fórmula no topo do nicho da pessoa, ela vale mais que qualquer regra desta tabela.
