# Opção 11: Story Motion (vídeo animado chamando pro post)

Um Story em vídeo de 15 segundos, com movimento, efeitos sonoros sincronizados e narração opcional, que resume o último post e pede pra pessoa ir até ele e comentar a palavra-chave. Sai pronto pra postar (MP4, 1080×1920).

## Entrada (uma pergunta por vez)

1. **Qual post?** Peça o link, o print da capa ou as imagens do carrossel. Se a skill acabou de criar o carrossel nesta conversa, ou se ele está no histórico, use esse e confirme em uma linha ("Vou usar o carrossel *tal*, certo?"). Nunca chute o post: se houver dúvida entre dois, pergunte.
2. **Qual palavra o post pede pra comentar?** Normalmente está no último slide. Se estiver visível, só confirme.
3. **Narração?** Pergunte exatamente assim:

```
Quer narração no vídeo?

 1. Sim, com voz gratuita
 2. Sim, com ElevenLabs (voz mais realista)
 3. Não, só trilha e efeitos
```

- **Voz gratuita:** vozes Alex e Santa (masculinas) ou Dora (feminina); padrão Alex. Modo `gratis` com `"voz": "pm_alex"`.
- **ElevenLabs:** siga o mesmo passo da opção 12 (`references/reels-motion.md`): se a ElevenLabs estiver conectada, gere os 4 áudios pelo conector e use o modo `audio`; se não estiver, peça pra conectar (procure "ElevenLabs" no diretório de conectores e mostre o botão); sem conector, peça a chave da API e use o modo `elevenlabs`. Nunca guarde a chave.
- Se a pessoa preferir gravar a própria voz, aceite os 4 áudios e use o modo `audio`.
- Com narração: escreva as 4 falas (abaixo) e mostre antes de gerar.

## O roteiro (4 cenas, 15 s, tempos fixos)

| Cena | Tempo | Na tela | Fala (se tiver narração) |
|---|---|---|---|
| 1. Gancho | 0–3 s | selo "Post novo no ar" + título do post em 2–3 linhas que "batem" na tela + frase de apoio | a pergunta do título (até ~7 palavras) |
| 2. Resumo | 3–8 s | até 4 telas do carrossel passando + 3 itens do que a pessoa vai aprender | o que tem no post (até ~14 palavras) |
| 3. Pedido | 8–12 s | a palavra caindo letra por letra + alguém digitando ela num comentário | "Quer X? Comenta PALAVRA." (até ~9 palavras) |
| 4. Final | 12–15 s | "Vai lá agora" + capa do post com o selo "O post é este" + botão "Comenta PALAVRA" | "Vai lá no meu perfil e comenta agora!" |

Regras do texto:
- **Nunca peça "toque aqui", "clique" ou "arrasta".** Vídeo de Story não tem nada clicável. O final manda ir ao perfil e comentar.
- Títulos curtos (2 a 3 linhas de até ~12 letras). Use `*palavra*` pra pintar com a cor de destaque.
- Falas escritas como se fala: "GOOGLE3P" vira "Google três pê"; números por extenso.
- Siga `references/escrita.md`.
- Cores, fontes, @ e assinatura vêm da configuração.

## Como gerar

1. Copie as imagens do post pra uma pasta de trabalho (a capa primeiro).
2. Monte o `story.json` (formato completo no topo de `scripts/story_motion.py`): textos das 4 cenas, imagens, palavra, cores e fontes da configuração, `"sons": true` e o bloco `narracao` com o modo escolhido (`nenhuma`, `gratis`, `elevenlabs` ou `audio`) e as 4 falas.
3. Rode primeiro a prévia (`--previa`), olhe as 5 imagens e corrija texto saindo da tela ou sobrepondo. Depois gere o vídeo.
4. A última linha da ferramenta diz qual voz foi usada. Se a narração falhou, avise e ofereça as outras opções.

Sem navegador no ambiente: entregue o roteiro das 4 cenas pra pessoa montar no CapCut ou no Canva.

## Entrega

- Mande o vídeo e diga em uma linha o que acontece em cada cena.
- Diga como postar: subir o vídeo no Story. Se quiser, colocar por cima a figurinha de **Link** apontando pro post, ou a de **Menção** com o próprio @.
- Os sons e a trilha são sintetizados pela própria ferramenta, sem direitos autorais. Se a pessoa for usar uma música do Instagram por cima, sugira deixá-la em ~30% do volume.
- Ajustes rápidos que a pessoa costuma pedir: tirar um som específico, trocar uma frase, trocar a cor. Refaça só o que mudou.

Nada é postado pela skill. A pessoa sobe o Story.
