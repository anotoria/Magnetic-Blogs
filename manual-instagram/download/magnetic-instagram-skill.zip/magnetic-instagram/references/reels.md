# Opção 3: Roteiro de Reels

Transforma uma ideia em um Reels que a pessoa assiste até o fim. Reels é o formato que mais chega em quem ainda não segue a conta.

## Antes de escrever

1. Leia a voz da pessoa na configuração (exemplos, jeito de falar, palavras que usa e nunca usa, se aparece no vídeo). Roteiro na voz errada não serve: ela vai ter que falar em voz alta.
2. Leia `references/ganchos.md`.
3. Se a ideia estiver rasa, faça UMA pergunta com tudo junto: o que aconteceu, com quem, e quanto custou ou rendeu. Um Reels precisa de uma coisa específica e verdadeira.
4. Se veio do Radar, use a fórmula de gancho do Reels de referência como ponto de partida.

## O formato

```
0:00 - 0:02   GANCHO     a afirmação. Fala e texto na tela, escritos separados. Movimento no primeiro quadro.
0:02 - 0:07   O PORQUÊ   por que isso importa pra quem assiste. Uma frase.
0:07 - ...    O MEIO     uma ideia por trecho, e a imagem muda a cada trecho.
ÚLTIMOS 3s    A ENTREGA  cumpre o que o gancho prometeu e faz UM pedido (a chamada da configuração).
ÚLTIMA FRASE  O LOOP     repete uma palavra do gancho, pra o replay emendar.
```

Duração: de 15 a 45 segundos. Abaixo de 7 segundos só infla replay; acima de 60 quase ninguém deveria fazer.

## Passo a passo

1. **3 ganchos, não 1.** Escolha 3 fórmulas diferentes que combinam com a ideia e escreva, para cada uma, a fala e o texto da tela.
2. **Dê nota.** Salve as 3 falas num arquivo, uma por linha, e rode `python3 scripts/gancho.py ganchos.txt`. Mostre o ranking. Se o melhor ficou abaixo de 50, o gancho ainda não existe: reescreva.
3. **Escreva o roteiro** no gancho vencedor. Linguagem falada, do jeito que a pessoa fala. Frases curtas. Nenhuma frase que ela precisaria ensaiar.
4. **Cronometre.** Salve o roteiro (uma fala por linha) e rode `python3 scripts/roteiro.py roteiro.txt --alvo 30` (troque 30 pela duração desejada; se a pessoa souber a velocidade dela, `--ppm 170`). Corrija cada alerta: gancho passando de 3 segundos, trecho com mais de 4 segundos parado, sequência sem nada concreto, sem loop. Rode de novo até ficar limpo.
5. **Tire a cara de IA** (`references/escrita.md`).
6. **Entregue:**
   - O roteiro em tabela: tempo, o que falar, o que aparece na tela (cena), texto escrito na tela.
   - O texto da tela separado, com os tempos.
   - Texto da capa do Reels (até 6 palavras).
   - A legenda (opção 4, trabalho A: o vídeo já tem o gancho).
   - O resumo:
     ```
     REELS PRONTO
     gancho:   fórmula 5 (Tempo que encolheu), nota 86 FORTE
     duração:  28s em 9 trechos
     na tela:  6 cartões
     legenda:  pronta, checada
     ```
7. Pergunte se aprova. No "sim", anote no histórico (data, fórmula, primeira frase).

## Texto na tela é outro roteiro

- **Até 6 palavras por cartão.** É lido de longe por quem ainda não está ouvindo.
- **O cartão do gancho aparece no primeiro quadro**, não depois de um silêncio.
- **Área segura** (vídeo 1080×1920): nada acima de 230 px do topo, nada abaixo de 1440 px e deixe livres os 230 px da direita. Fora disso, a interface do Instagram cobre.
- **Nunca coloque o gancho embaixo**, onde fica a legenda.
- **Legenda queimada no vídeo no meio:** a maioria assiste sem som primeiro.

## Regras que fazem diferença

- **Uma ideia por Reels.** Se o roteiro tem duas, são dois Reels. Diga isso.
- **Número em vez de adjetivo.** Se não tiver o número, pergunte; não escreva em volta do buraco.
- **Corte a introdução.** Sem "oi, pessoal", sem nome, sem vinheta, sem pedir pra seguir no começo.
- **Mude a imagem a cada trecho.** 8 segundos parado é onde as pessoas saem.
- **Um pedido no final.** A chamada da configuração, falada e escrita na tela.
- **Nunca invente** números, clientes ou resultados, nem como exemplo no nome da pessoa.
- **Se a pessoa não aparece no vídeo** (configuração), faça a versão sem rosto: cenas com tela, mãos, imagens de apoio, texto na tela e narração ou trilha.
