# Opção 9: Analisar o que você já postou

A única fonte honesta do que funciona pra uma conta é a própria conta. Toda regra desta skill é um ponto de partida; os últimos 30 posts dela são a prova.

## Entrada

Peça o que ela tiver (prints servem):
- Insights por post: visualizações, alcance, interações, tempo de exibição, salvamentos, compartilhamentos, seguidores ganhos e a porcentagem de alcance de não seguidores.
- O gráfico de retenção do melhor e do pior Reels recente. Esse print vale mais que o resto junto.
- Ou só os posts e as visualizações, que já servem pra uma primeira leitura.

Se o Apify estiver conectado e o perfil for público, dá pra puxar curtidas, comentários e visualizações dos últimos 30 posts sozinho (mesma coleta do Radar, só com o @ dela) e rodar `scripts/ranking.py` com `--eu` pra achar os que passaram da média dela. Salvamentos, compartilhamentos e alcance só aparecem nos Insights: peça os prints pra completar.

Leia também o histórico, que diz qual fórmula de gancho cada post usou.

## O que medir

Visualização pura é o número menos útil, porque depende de quantos já seguem a conta. Calcule e mostre a conta:

| Métrica | Como | O que diz |
|---|---|---|
| **Vezes a média** | visualizações ÷ mediana de visualizações da conta | se foi um acerto de verdade ou um dia normal |
| **Alcance fora** | % do alcance de quem não segue | se viajou |
| **Retenção em 3s** | quem ficou aos 3s ÷ quem começou | se o gancho funcionou. É a nota do gancho. |
| **Tempo médio** | direto dos Insights | se o meio funcionou |
| **Envios por alcance** | compartilhamentos ÷ alcance | o sinal mais forte: alguém colocou o nome dele no seu post |
| **Seguidores por alcance** | seguidores ganhos ÷ alcance | se o perfil converteu a atenção |

Ordene por "vezes a média" e "envios por alcance", não por visualização. Um Reels com 4 mil views e 90 envios ganhou do de 60 mil com 11.

## Ache o padrão

Com os 5 melhores e os 5 piores lado a lado, veja o que separa, e esteja pronto pra concluir algo que ela não vai gostar:
- **Retenção em 3s.** Se melhores e piores diferem aqui, é o gancho e só o gancho.
- **Fórmula de gancho** (do histórico).
- **Formato:** Reels, carrossel, foto.
- **Duração:** até 15s, 15 a 30s, 30 a 60s, mais de 60s.
- **Tema.**
- **Se respondeu comentários na primeira hora.**
- **Dia e horário** — por último, e só se o resto não mostrar nada. Quase nunca é a causa.

Diga a conclusão como afirmação com a prova junto e com o grau de certeza. Com 30 posts dá pra ver padrão. Com 6 não dá, e dizer isso é melhor que inventar.

## A diferença que economiza meses

**Reels com visualização e sem seguidor não é Reels ruim: é problema de perfil** (opção 5). **Reels sem visualização é problema de gancho** (opção 3). Separe os dois antes de recomendar qualquer coisa.

## Entrega

```
ANÁLISE · 31 posts · 12/06 a 05/09 · mediana 4.100 views

TOP 5 (vezes a média)
  18,2x  fórmula 3  Ninguém te conta   74.600 views  62% fora  retenção 71%  128 envios
  ...
PIORES 5
   0,3x  fórmula 11 Lista             1.200 views   9% fora  retenção 31%    2 envios

O QUE OS DADOS DIZEM
1. Retenção em 3s explica tudo: top 5 com 66%, piores com 33%.
2. ...

PARE: ...
FAÇA MAIS: ...
```

Salve as conclusões no histórico: o plano da semana (opção 6) e o Radar (opção 1) passam a usar o que funciona pra esta conta.
