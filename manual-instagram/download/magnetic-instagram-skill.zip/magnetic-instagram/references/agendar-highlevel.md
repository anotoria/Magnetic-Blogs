# Opção 10: Agendar no HighLevel (Planejador Social)

Use quando a pessoa pedir pra agendar, programar ou postar carrosséis prontos (ex.: "agenda um a cada 2 dias às 18h"). Reels ela grava e posta sozinha; este passo é pra carrossel e foto.

## 1. O que precisa estar ligado (confira em silêncio, explique só o que faltar)

1. **HighLevel conectado no Claude** (área de conectores). Obrigatório. Sem ele, explique como conectar e pare.
2. **Instagram conectado no Planejador Social** da subconta. Liste as contas conectadas da subconta (operação de listar contas do Planejador Social); se o Instagram não aparecer ou estiver vencido, peça pra ela reconectar no HighLevel (Marketing > Planejador Social) e pare.
3. **Um lugar com link aberto pras imagens.** O HighLevel e o Instagram buscam a imagem por um link aberto. Nesta ordem:
   - **GitHub conectado no Claude, com um repositório público de imagens** (caminho automático). Se ela não tiver, explique que é opcional e grátis: criar conta em github.com, criar um repositório público (ex.: "midia-posts") e conectar o GitHub no Claude. Ela nunca passa senha pra ninguém: a conexão fica na conta dela. Antes de guardar imagens no repositório, peça autorização uma vez e anote na configuração. Avise que as imagens ficam públicas (o que não é problema, já que vão pro Instagram).
   - **Sem GitHub:** caminho com um passo manual (opção B abaixo).
   - Não use Google Drive nem Canva como ponte: pela conexão do Claude eles não geram link aberto que o HighLevel consiga ler.
4. **Chrome do Claude** (extensão Claude in Chrome) com ela logada no HighLevel. Opcional: serve pra colocar as imagens também no Armazenamento de mídia da subconta.

Na primeira vez, pergunte e salve na configuração (campo "Agendamento no HighLevel"): qual subconta, qual conta do Instagram, horário padrão, fuso e o nome da pasta no Armazenamento de mídia (sugira "Carrosseis Instagram").

## 2. Montar o calendário

Confirme numa tabela simples antes de agendar: data, horário (no fuso dela), título do carrossel e número de slides. Converta o horário pro horário universal ao agendar (Brasília = UTC-3, ex.: 18h = 21:00Z). Não agende em data que já passou.

## 3. Levar as imagens pro HighLevel

**Opção A, automática (com GitHub):**
1. Converta os slides pra JPG (qualidade 86 a 90, 1080×1350) e envie pro repositório público, numa pasta por post: `social/AAAA-MM-DD-tema/slide-N.jpg`. Use o link fixado no commit (`raw.githubusercontent.com/<dono>/<repo>/<commit>/social/...`) e confira que abre como imagem (tipo `image/jpeg`).
2. Se o Chrome do Claude estiver ligado e ela logada: crie a pasta no Armazenamento de mídia pela conexão do HighLevel, abra a página do Armazenamento de mídia no Chrome, carregue as imagens no botão "Carregar" com nomes `AAAA-MM-DD-tema-slide-NN.jpg`, liste os arquivos pela conexão, pegue os links e mova pra pasta. Feche a aba que abriu.
3. Sem o Chrome, use direto os links do GitHub no post.

**Opção B, com um passo manual (sem GitHub):**
1. Crie a pasta no Armazenamento de mídia pela conexão do HighLevel.
2. Entregue os slides (arquivo compactado ou direto numa pasta do computador dela, se estiver conectado) com os nomes `AAAA-MM-DD-tema-slide-NN.jpg`.
3. Peça, em 3 passos: abrir o Armazenamento de mídia, entrar na pasta, clicar em "Carregar", selecionar todos e avisar "subiu".
4. Quando ela avisar, liste os arquivos pela conexão do HighLevel e pegue os links.

## 4. Criar os posts agendados

Antes, rode a checagem da legenda (opção 4): **no máximo 5 hashtags**, um pedido, sem link.

O usuário que cria o post: busque na lista de usuários da subconta (a busca de usuários pede o id da empresa, que aparece nos detalhes da subconta) e use o usuário da própria pessoa; ou leia um post antigo da subconta, que mostra quem criou.

Pra cada post, pela conexão do HighLevel (criar post do Planejador Social):
- conta: a do Instagram dela; tipo `post`, com os detalhes do Instagram também como `post`
- status `scheduled` e a data e hora no horário universal
- mídia: as imagens NA ORDEM dos slides, tipo `image/jpeg`
- legenda completa, com até 5 hashtags (o Instagram aceita até 2.200 caracteres)
- o id do usuário em "usuário" e em "criado por"
- uma chave única por post (ex.: `post-ig-AAAA-MM-DD-tema`), pra nunca duplicar se precisar repetir

**Carrossel: no máximo 10 imagens** (limite da publicação automática do Instagram pelo HighLevel). Se tiver mais, não agende: junte slides (ex.: a virada com a chamada) e gere de novo, pra nunca cortar a chamada do final.

Pra corrigir um post já agendado (legenda, data, imagens), use a operação de editar post com o id dele, mandando o post completo de novo com a mudança.

## 5. Conferir e entregar

Leia de volta os posts criados e confira data, hora, número de imagens e legenda. Entregue uma tabela curta: data, hora, título, número de slides. Avise que as imagens precisam continuar no lugar até a data da publicação. Se achar outro post agendado com algo estranho (carrossel com 1 imagem, mais de 5 hashtags), avise e ofereça corrigir. Salve na configuração o que funcionou (onde ficam as imagens, conta, horário), pra da próxima vez fazer tudo sem perguntar.
