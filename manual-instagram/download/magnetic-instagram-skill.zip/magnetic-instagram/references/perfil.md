# Opção 5: Nota do perfil (0 a 100) e nova bio

O perfil não é vitrine. É uma **tela de decisão**: quem chega de um Reels tem uns 3 segundos pra responder "tem mais disso aqui, e é pra mim?".

## Entrada

Peça um print do topo do perfil com as duas primeiras linhas de posts (ou cole: nome, @, bio, link, nomes dos destaques, o que está fixado e as 9 primeiras capas). Não entre na conta da pessoa.

Se o perfil for público e o Apify estiver conectado, dá pra complementar com os últimos posts (data do último post, frequência). Não é obrigatório.

## A nota (12 itens, 100 pontos)

Dê a nota de cada item com honestidade. A maioria dos perfis tira entre 30 e 45 na primeira vez; nota generosa não ajuda ninguém.

| Item | Pontos | Nota cheia quando... | Erro comum |
|---|---|---|---|
| Campo de nome | 12 | O nome (30 caracteres, a linha em negrito, não o @) tem o nome + o que faz em palavras que as pessoas buscam: "Ana Souza \| Tráfego pra clínicas". O Instagram busca por esse campo. | Só o nome, ou nome com emoji. |
| Primeira linha da bio | 12 | Diz pra quem é e o que muda pra essa pessoa, nas palavras dela. | "Empreendedor \| Pai \| Café". |
| Resto da bio | 8 | Os 150 caracteres levam uma prova ou uma oferta clara, em frases. | Lista de palavras separada por barras. |
| 3 posts fixados | 10 | Três fixados com três funções: a melhor prova, a explicação mais clara da oferta e a melhor apresentação da pessoa. | Nada fixado, ou os mais vistos por acaso. |
| Link | 8 | Um destino que cumpre o que a bio prometeu. Até 5 são permitidos; mais de 2 vira cardápio, e cardápio converte menos que uma porta. | Árvore de links com 9 botões. |
| Destaques | 8 | De 4 a 6, com nomes das perguntas de quem compra: Preços, Resultados, Como funciona, Sobre. Capas iguais. | "Aleatório", "2023", "Viagem". |
| Leitura da grade | 8 | As 9 primeiras capas se entendem em miniatura e dizem do que é a conta sem clicar. Capa de Reels escolhida. | Rosto no meio da fala em 6 de 9 capas. |
| Foto | 6 | Rosto ocupa uns 60% do círculo, olhos visíveis, foto dos últimos 2 anos, fundo que não compete. | Logo pequeno ou foto de longe. |
| @ | 6 | Fácil de ler e falar, igual nas outras redes. | Underlines e números no lugar de letras. |
| Categoria e contato | 6 | Conta profissional, categoria certa, botões de contato funcionando. | E-mail que ninguém lê. |
| Atividade recente | 10 | Postou nos últimos 7 dias e respondeu os comentários do último post. | Último post há meses. |
| Stories | 6 | Tem Stories no ar agora, ou na maioria dos dias. | Nenhum Story. |

Mostre a tabela com a nota de cada item e o total.

## Depois, reescreva nesta ordem

Corrija do item que mais perdeu ponto para o que menos perdeu. Não reescreva tudo de uma vez: a pessoa precisa ir lá e mudar cada campo.

1. **Campo de nome (30 caracteres):** formato "{Nome} \| {o que faz, em palavras buscadas}". Dê 3 opções usando o nicho e os temas da configuração.
2. **Primeira linha da bio:** pra quem é e o que muda. Depois uma prova ou a oferta da configuração, e a chamada (ex.: "Comenta GUIA em qualquer post" ou "Link abaixo").
3. **Os 3 fixados:** diga quais posts atuais servem pra cada função ou quais precisam ser criados (e ofereça criar pela opção 2 ou 3).
4. **Destaques:** de 4 a 6 nomes para o negócio dela.
5. **Link:** um destino, o da oferta principal da configuração.
6. **Capas da grade:** até 4 palavras de texto em cada capa.

## Entrega

A tabela de nota, depois cada reescrita em bloco pronto pra copiar, na ordem de correção, sem cara de IA. No fim, dê a nota nova estimada, com honestidade: se a reescrita chega a 84 e não a 98, diga 84 e o que falta (normalmente grade, rotina de Stories e um fixado que ainda não existe).

Nada é alterado no Instagram por esta skill. A pessoa muda cada campo.
