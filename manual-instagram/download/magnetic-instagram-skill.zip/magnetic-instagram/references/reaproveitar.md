# Opção 8: Reaproveitar um vídeo, live ou texto

Um conteúdo longo bom tem de 4 a 6 posts dentro. A maioria das pessoas tira um e joga o resto fora.

## Entrada

Transcrição, artigo, newsletter, roteiro, resumo de reunião, live, aula, podcast. Se ela mandar um link de vídeo e houver ferramenta de transcrição na conversa (ex.: YouTube, Fathom, Apify), use; senão peça pra colar o texto ou mandar o arquivo. Leia tudo antes de tirar qualquer coisa.

Se o vídeo é dela, peça também o arquivo: um Reels com o trecho real (com a reação de verdade) vale mais que regravar.

## Extraia, não resuma

Resumo de vídeo não é post. Procure o que fica de pé sozinho:

| Tirar | O que é |
|---|---|
| **Afirmações** | toda frase que começaria uma discussão |
| **Números** | todo valor, custo, tempo, porcentagem |
| **Histórias** | todo momento com uma pessoa, uma cena e um custo |
| **Mecanismos** | todo "o jeito que isso funciona de verdade é..." |
| **Erros** | toda confissão de algo que deu errado |
| **Frases** | toda frase que já dá pra citar como está |

Liste o que achou, com a contagem, antes de escrever. Se deu menos de 4 itens, o material é fraco, e diga isso.

## Escolha o formato de cada item

- **Afirmação, erro, história** → Reels (precisam de voz e rosto).
- **Mecanismo, lista numerada** → carrossel (precisam ser relidos).
- **Frase de efeito** → uma tela de Stories, não um post.

## Monte a semana

Cada item vira um post que fica de pé sozinho. Quem vê o post nunca viu o original: nunca escreva "como falei no meu último vídeo".

Dê uma fórmula de gancho diferente pra cada post (`references/ganchos.md`). Cinco posts do mesmo material com o mesmo tipo de gancho parecem fábrica de conteúdo.

Se o material é vídeo da própria pessoa, indique o trecho exato (minuto e segundo) de cada Reels. Corte na frase, não na respiração.

Ordem: a afirmação mais forte primeiro, a história no meio da semana, o mecanismo por último.

## Entrega

```
MATERIAL: "Por que parei de fazer reunião de diagnóstico" (live de 42 min)

ACHEI  5 afirmações, 9 números, 3 histórias, 4 mecanismos, 2 erros, 7 frases

SEMANA
TER  REELS      fórmula 2  Pare e faça     — pare de fazer reunião de diagnóstico (trecho 14:20)
QUA  CARROSSEL  capa: "O FORMULÁRIO DE 4 PERGUNTAS"
SEX  REELS      fórmula 21 Meio da frase   — "...e ele pediu reembolso 9 dias depois"
DOM  REELS      fórmula 5  Tempo que encolheu — 6 horas por semana de volta

Diga "escreve a terça" que eu faço.
```

Depois faça um de cada vez, pela opção 2 ou 3. Não entregue 4 roteiros prontos de uma vez: vão sair parecidos e ela não vai gravar nenhum.
