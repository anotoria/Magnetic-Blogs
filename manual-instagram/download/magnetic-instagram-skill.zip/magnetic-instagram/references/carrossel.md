# Opção 2: Criar carrossel

Carrossel é o formato de maior tempo de tela no feed: cada arrastada conta como interação. E o Instagram pode mostrar o carrossel de novo, começando por um slide seguinte, pra quem não interagiu da primeira vez. Por isso o slide 2 também precisa funcionar sozinho.

## Carrossel ou Reels?

Use carrossel quando a ideia tem sequência e precisa ser relida: passos, método com partes, antes e depois, lista que vale salvar. Se a ideia é uma afirmação só, com emoção ou rosto, é Reels: diga isso e ofereça a opção 3.

## Entrada

Pode vir de:
- um post do Radar (opção 1): mesmo formato e tema, texto 100% novo;
- um tema que a pessoa trouxer;
- um link ou print de referência que ela mandar: moldar o formato, nunca copiar.

Se a ideia estiver rasa, faça UMA pergunta com tudo junto: o que aconteceu, com quem, e qual número ou resultado concreto existe. Um carrossel bom precisa de uma coisa específica e verdadeira.

## Estrutura (8 a 10 slides; nunca mais que 10)

Siga a **anatomia do carrossel viral** (`references/anatomia-viral.md`): capa que quebra o padrão com imagem chamativa, slides 2 e 3 que prendem com uma promessa, 4 a 6 com a entrega pesada, 7 e 8 pra salvar e a chamada no fim. Leia esse arquivo antes de escrever.

```
1          QUEBRA DE PADRÃO   imagem chamativa (não só o rosto) + manchete forte + linha do que ganha ao arrastar
2 e 3      RETENÇÃO           a situação que a pessoa reconhece + a promessa do que vem
4 a 6      ENTREGA            uma ideia por slide: conceito, passo, dado, exemplo, print
7 e 8      SALVAMENTO         checklist, prompt pronto, modelo, comparação ou resumo ("salva esse post")
ÚLTIMO     CHAMADA            uma ação só: a chamada da configuração, exatamente igual
```

Quando fizer sentido para a oferta dela, o penúltimo slide faz a ponte do conteúdo para a oferta da configuração (o problema que o conteúdo mostrou → o que ela vende resolve), sem parecer anúncio.

## Regras do texto

- **A capa é 80% do resultado.** Afirmativa, concreta, com número ou nome quando der. Comece pela solução ou pelo resultado, não pela introdução.
- **A imagem da capa vem antes do texto da capa.** Escolha a imagem pela regra da anatomia viral (metáfora visual, print surpreendente, cena do problema, imagem gerada ou foto da pessoa com expressão forte). Rosto sozinho não é o padrão. Se precisar de imagem que a pessoa tem (print, foto do produto), peça; se o Unsplash ou um gerador de imagem estiver disponível, busque você e mostre 2 ou 3 opções.
- **Nenhum slide é parágrafo.** Passou de 25 palavras, vira dois slides.
- **Numere os slides** (3/8): a pessoa arrasta mais quando vê o fim.
- **O @ em todos os slides.** Print viaja sem você.
- Palavras do cliente (da configuração) valem mais que termos técnicos.
- Siga `references/escrita.md`.

## Passo a passo

1. **Texto primeiro.** Mostre o carrossel slide a slide, numa lista que a pessoa lê em 10 segundos:
   ```
   CARROSSEL · 8 slides
   1  CAPA    O CONTRATO DE R$18 MIL
              A linha que eu coloco em todo contrato agora.
   2  PORQUÊ  Aprovaram o trabalho. Pediram o dinheiro de volta 9 dias depois.
   ...
   8  CHAMADA Comenta CONTRATO que eu te mando a cláusula.
   ```
   Pergunte se aprova ou quer mudar algo. Só gere as imagens depois do "ok" (se a pessoa pediu "já faz tudo", siga direto).
2. **Estilo.** Use o estilo da configuração:
   - **Um estilo fixo:** use sempre ele.
   - **Viral (recomendado pra crescer):** capa com a imagem em tela cheia e manchete embaixo (ou `"layout": "card"`: manchete em cima e a imagem num cartão), `"selo"` opcional, slides creme com cartões, fotos e prints, pontinhos de progresso e o @ com a numeração no topo.
   - **"alternar":** coloque `"estilo": "alternar"` e `"ultimo_estilo"` com o último usado (a ferramenta sorteia um diferente). Ou escolha você o que combina com o conteúdo: Tweet pra opinião e bastidor, Caderno pra passo a passo, Editorial pra análise e dados, Gradiente pra tecnologia e novidade, Minimal pra frase e reflexão, Impacto pra lista e chamada forte, Caneta pra tutorial em fases (cara de desenho à mão em caderno), Sistema pra método e "monte seu sistema" (papel bege, post-it e cartões), Jornal pra notícia, novidade e resumo do que saiu ontem (página de jornal impresso com o nome do jornal da pessoa no topo, manchete com serifa e carimbo). Drawing pra explicar um processo e contar história com cara de feito à mão (folha de caderno nas cores da marca, letra de mão, contorno de caneta, marca-texto e a foto da pessoa vira desenho a lápis). Depois anote o estilo usado em "Último estilo usado".
   - **"igual ao meu exemplo":** olhe o print que a pessoa mandou, escolha o estilo mais parecido e use `"css_extra"` pra aproximar detalhes (cantos, bordas, tamanho de título, fundo), sempre com as cores dela. Nunca copie logo, foto ou texto do exemplo.
   - A pessoa pode pedir um estilo só pra este carrossel ("faz esse no estilo caderno"). Pra ver todos de novo, gere a galeria (`--galeria`).
   - No estilo Tweet, preencha `"nome"` e `"avatar"` (foto de perfil da pessoa).
   - No estilo Jornal, preencha `"jornal_nome"` (o nome do jornal da pessoa, ex.: "O Diário Magnético"; se ela não tiver, sugira "O Diário de [nome]") e `"jornal_edicao"` (ex.: "Edição de ontem · Qui, 1º de outubro"). Em cada slide dá pra mudar a seção com `"pagina"` ("Pág. 2", "Caderno de Tecnologia", "Classificados") e pôr um carimbo com `"carimbo": "SAIU|ONTEM"` e `"carimbo_data": "01/10"`. Bom de combinar: capa = manchete, lista = "o que mudou em N notas", comparação = antes e depois, CTA = "Classificados" com a palavra-chave.
   - Qualquer estilo também gera telas de Stories (1080×1920): coloque `"formato": "story"` no JSON.
   - **Limite:** o Planejador Social do HighLevel e a publicação automática do Instagram aceitam no máximo **10 imagens por carrossel**. Planeje até 10 slides. Se passar, junte slides (ex.: o slide da virada com o da chamada) em vez de cortar a chamada.
3. **Imagens.** Monte o arquivo `slides.json` e rode `python3 scripts/carrossel.py slides.json pasta-do-carrossel/` (o formato do arquivo está no começo da ferramenta). Use as cores, fontes, fotos e o @ da configuração. Alterne fundo escuro e claro; o último slide sai na cor de destaque. Escolha o tipo de slide que combina com cada ideia: `capa`, `texto`, `lista`, `chat` (pedido e resposta de IA, conversa), `comparacao` (antes e depois, grátis e pago), `numero` (um dado grande), `imagem` (foto ou print grande com legenda), `print` (print de celular na moldura de um telefone), `salvar` (checklist com o ícone de salvar), `resumo` e `cta`. Varie os tipos: nunca três slides de texto puro seguidos.
   - Olhe as imagens geradas antes de entregar: texto cortado, slide vazio demais ou cheio demais se corrige ajustando o texto ou o tipo de slide.
   - Se não houver navegador para gerar as imagens: entregue o HTML (abre no navegador) e, se o Canva estiver conectado, ofereça montar lá. Em último caso, entregue o texto slide a slide com a indicação de cor e fonte.
4. **Prévia e arquivos.** Entregue uma prévia com todos os slides lado a lado e um arquivo compactado com os slides (PNG) e a legenda.
5. **Legenda.** Escreva seguindo a opção 4 (trabalho B: a legenda complementa a capa), rode a checagem e entregue junto.
6. **Texto alternativo** da capa, em uma frase (acessibilidade e busca do Instagram).
7. **Arquivo prometido = arquivo entregue (sempre).** Se a chamada promete mandar algo ("te mando o checklist", "o mapa", "o guia", "os prompts"), crie esse arquivo em PDF no mesmo visual do carrossel (mesmas cores, fontes, logo e @), com conteúdo de verdade (passo a passo, prompts, dicas) e os links da pessoa no fim. Entregue junto com o carrossel, com o link pronto pra colocar no botão da automação de direct e a mensagem que vai junto. Nunca agende um post que promete um arquivo que ainda não existe.
8. Antes de entregar, confira: palavra-chave idêntica à da automação, preço e dados citados, nenhuma promessa de ganho.
9. Ofereça: "Quer que eu já agende no seu HighLevel?" (opção 10). Anote no histórico.
