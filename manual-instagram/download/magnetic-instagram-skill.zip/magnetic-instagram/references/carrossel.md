# Opção 2: Criar carrossel

Carrossel é o formato de maior tempo de tela no feed: cada arrastada conta como interação. E o Instagram pode mostrar o carrossel de novo, começando por um slide seguinte, pra quem não interagiu da primeira vez. Por isso o slide 2 também precisa funcionar sozinho.

## Carrossel ou Reels?

Use carrossel quando a ideia tem sequência e precisa ser relida: passos, método com partes, antes e depois, lista que vale salvar. Se a ideia é uma afirmação só, com emoção ou rosto, é Reels: diga isso e ofereça a opção 3.

## Entrada

Pode vir de:
- um post do Radar (opção 1): mesmo formato e tema, texto 100% novo;
- um tema que a pessoa trouxer;
- um link ou print de referência que ela mandar: moldar o formato, nunca copiar.

Se a ideia estiver rasa, faça UMA pergunta com tudo junto: o que aconteceu, com quem, e qual número ou resultado concreto existe. Um carrossel bom precisa de uma coisa específica e verdadeira.

## Estrutura (6 a 10 slides; nunca mais que 10)

```
1          CAPA      o gancho. Até 6 palavras grandes + uma linha de promessa.
2          O PORQUÊ  por que isso importa, em uma frase. Funciona como segunda capa.
3 a N      UMA IDEIA POR SLIDE. Título de 3 a 7 palavras e no máximo 25 palavras embaixo.
N+1        RESUMO    tudo numa lista. É o slide que as pessoas printam e mandam.
ÚLTIMO     CHAMADA   uma ação só: a chamada da configuração, exatamente igual.
```

Quando fizer sentido para a oferta dela, o penúltimo slide faz a ponte do conteúdo para a oferta da configuração (o problema que o conteúdo mostrou → o que ela vende resolve), sem parecer anúncio.

## Regras do texto

- **A capa é 80% do resultado.** Afirmativa, concreta, com número ou nome quando der. Comece pela solução ou pelo resultado, não pela introdução.
- **Varie a capa:** alterne capa só com título grande e capa com foto da pessoa (título de 3 a 5 palavras), se ela tiver fotos na configuração.
- **Nenhum slide é parágrafo.** Passou de 25 palavras, vira dois slides.
- **Numere os slides** (3/8): a pessoa arrasta mais quando vê o fim.
- **O @ em todos os slides.** Print viaja sem você.
- Palavras do cliente (da configuração) valem mais que termos técnicos.
- Siga `references/escrita.md`.

## Passo a passo

1. **Texto primeiro.** Mostre o carrossel slide a slide, numa lista que a pessoa lê em 10 segundos:
   ```
   CARROSSEL · 8 slides
   1  CAPA    O CONTRATO DE R$18 MIL
              A linha que eu coloco em todo contrato agora.
   2  PORQUÊ  Aprovaram o trabalho. Pediram o dinheiro de volta 9 dias depois.
   ...
   8  CHAMADA Comenta CONTRATO que eu te mando a cláusula.
   ```
   Pergunte se aprova ou quer mudar algo. Só gere as imagens depois do "ok" (se a pessoa pediu "já faz tudo", siga direto).
2. **Estilo.** Use o estilo da configuração:
   - **Um estilo fixo:** use sempre ele.
   - **"alternar":** coloque `"estilo": "alternar"` e `"ultimo_estilo"` com o último usado (a ferramenta sorteia um diferente). Ou escolha você o que combina com o conteúdo: Tweet pra opinião e bastidor, Caderno pra passo a passo, Editorial pra análise e dados, Gradiente pra tecnologia e novidade, Minimal pra frase e reflexão, Impacto pra lista e chamada forte. Depois anote o estilo usado em "Último estilo usado".
   - **"igual ao meu exemplo":** olhe o print que a pessoa mandou, escolha o estilo mais parecido e use `"css_extra"` pra aproximar detalhes (cantos, bordas, tamanho de título, fundo), sempre com as cores dela. Nunca copie logo, foto ou texto do exemplo.
   - A pessoa pode pedir um estilo só pra este carrossel ("faz esse no estilo caderno"). Pra ver todos de novo, gere a galeria (`--galeria`).
   - No estilo Tweet, preencha `"nome"` e `"avatar"` (foto de perfil da pessoa).
   - **Limite:** o Planejador Social do HighLevel e a publicação automática do Instagram aceitam no máximo **10 imagens por carrossel**. Planeje até 10 slides. Se passar, junte slides (ex.: o slide da virada com o da chamada) em vez de cortar a chamada.
3. **Imagens.** Monte o arquivo `slides.json` e rode `python3 scripts/carrossel.py slides.json pasta-do-carrossel/` (o formato do arquivo está no começo da ferramenta). Use as cores, fontes, fotos e o @ da configuração. Alterne fundo escuro e claro; o último slide sai na cor de destaque. Escolha o tipo de slide que combina com cada ideia: `capa`, `texto`, `lista`, `chat` (pedido e resposta de IA, conversa), `comparacao` (antes e depois, grátis e pago), `numero` (um dado grande), `resumo` e `cta`.
   - Olhe as imagens geradas antes de entregar: texto cortado, slide vazio demais ou cheio demais se corrige ajustando o texto ou o tipo de slide.
   - Se não houver navegador para gerar as imagens: entregue o HTML (abre no navegador) e, se o Canva estiver conectado, ofereça montar lá. Em último caso, entregue o texto slide a slide com a indicação de cor e fonte.
4. **Prévia e arquivos.** Entregue uma prévia com todos os slides lado a lado e um arquivo compactado com os slides (PNG) e a legenda.
5. **Legenda.** Escreva seguindo a opção 4 (trabalho B: a legenda complementa a capa), rode a checagem e entregue junto.
6. **Texto alternativo** da capa, em uma frase (acessibilidade e busca do Instagram).
7. Antes de entregar, confira: palavra-chave idêntica à da automação, preço e dados citados, nenhuma promessa de ganho.
8. Ofereça: "Quer que eu já agende no seu HighLevel?" (opção 10). Anote no histórico.
