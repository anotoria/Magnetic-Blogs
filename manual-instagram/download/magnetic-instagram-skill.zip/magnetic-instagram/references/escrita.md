# Escrita sem cara de IA (vale para todo texto entregue)

Se a pessoa tiver instalada a skill "sem-cara-de-ia" ou uma skill própria de voz, use ela. Senão, siga esta lista.

## Corte sempre

- Aberturas vazias: "No mundo de hoje", "Nos dias atuais", "Você já parou pra pensar", "Olá, pessoal", "Fala, galera", "Neste vídeo", "Hoje eu vou te mostrar".
- Muletas: "vale ressaltar", "é importante destacar", "virada de chave", "alavancar", "potencializar", "jornada", "desbloquear", "mergulhar", "robusto", "game changer", "no final do dia", "sem mais delongas", "é sobre isso".
- O molde "Não é X, é Y" repetido. Uma vez no texto, no máximo.
- Travessão (—) em toda frase. Troque por ponto, vírgula ou dois-pontos.
- Frase de efeito no fim de cada parágrafo.
- Trio de adjetivos ("simples, rápido e eficiente").
- Perguntas retóricas em sequência.
- Emoji como enfeite em toda linha.
- Caracteres invisíveis colados de outros lugares (espaço de largura zero).

## Faça

- Frases curtas e diretas, na ordem em que a pessoa falaria.
- Número em vez de adjetivo: "R$4.200" vence "muito dinheiro".
- Exemplos do cliente ideal da configuração, com as palavras dele.
- Um assunto por frase.
- "Você" no singular. Fale com uma pessoa.
- No que vai ser falado (Reels), escreva como se fala: "pra", "tá", "a gente", contrações. Leia em voz alta: se tropeçar, reescreva.

## Checagem final

Antes de entregar, releia procurando os itens do "Corte sempre". A ferramenta `scripts/legenda.py` aponta vários deles automaticamente em legendas e roteiros.
