# Opção 1: Radar — o que está viralizando no nicho

O Radar olha os perfis de referência da configuração, acha os carrosséis e os Reels que mais passaram da média do PRÓPRIO perfil e entrega de 5 a 10 com link, dizendo por que cada um funcionou e como moldar para o público e a oferta da pessoa.

## Antes: conexão com o Apify

O Radar precisa do Apify para ler o Instagram. Confira se as ferramentas do Apify estão disponíveis na conversa. Se não estiverem, explique em passos simples:
1. Criar uma conta em apify.com (o plano gratuito dá alguns dólares de crédito por mês).
2. Conectar o Apify na área de conectores do Claude.

Diga o custo com clareza: cada rodada gasta perto de US$1 no Apify dela, com 15 perfis; os ganchos dos Reels custam uns centavos a mais (cerca de US$0,015 por Reels). Não siga sem a conexão. Se o Apify acabar os créditos no meio, diga em uma frase e pare.

## Qual formato hoje

Se o pedido não disser, pergunte uma vez: **"Hoje é Carrossel, Reels ou os dois?"** Na rodada agendada, use o formato preferido da configuração.

## Coletar

Rode o ator `apify/instagram-scraper` com:
- `directUrls`: `https://www.instagram.com/<perfil>/` para cada perfil da configuração, mais o @ da própria pessoa
- `resultsType`: `posts`, `resultsLimit`: `30`, `addParentData`: `true`
- limite de gasto `maxTotalChargeUsd`: `1.5`

Não use busca por hashtag: ela só traz os posts mais recentes, sem curtidas, e não acha viral.

Espere terminar e baixe os itens com os campos `ownerUsername,type,likesCount,commentsCount,videoPlayCount,videoViewCount,videoDuration,shortCode,timestamp,caption`. Salve como `posts.json`. Nunca invente dado.

## Ranquear

Rode a ferramenta desta skill:
`python3 scripts/ranking.py posts.json --formato ambos --dias 60 --top 10 --eu ARROBA > ranking.json`

Troque `ambos` por `carrossel` ou `reels` conforme o formato, e ARROBA pelo @ da configuração (sem o @). Para um tema: `--tema "palavra1,palavra2" --dias 120`; se vierem menos de 5, complete sem tema e avise.

Carrossel é medido por curtidas + comentários; Reels por reproduções. Cada post é comparado com a mediana do próprio perfil: um perfil pequeno que fez 10 vezes a média dele conta mais que um gigante que ficou na média. Salvamentos e compartilhamentos não são públicos e ficam de fora — diga isso se perguntarem.

Se vierem menos de 5 de um formato, avise que os perfis da lista postam pouco daquele formato e sugira de 3 a 5 perfis novos que postam mais, para ela aprovar e atualizar a configuração.

## Gancho dos Reels (só se o formato incluir Reels)

Para os 5 Reels mais fortes, rode `steadyfetch/instagram-reel-transcript-scraper` com `reelUrls` (os links) e `maxItems: 5`, limite de gasto `maxTotalChargeUsd: 0.15`. Use o campo `hook3s` (o que foi dito nos 3 primeiros segundos) e, da transcrição, só o começo e o fim. Não carregue a transcrição inteira. Reels sem fala voltam como "sem fala": nesse caso o que prende é a imagem, e diga isso. Classifique cada gancho numa fórmula de `references/ganchos.md`.

## Entregar

De 5 a 10 por formato pedido, do mais forte para o menos forte. Para cada um:
1. **Link do post** e **@perfil**
2. **Quanto passou da média** (ex.: "28 vezes a média do perfil") e a data
3. **Por que funcionou**, em uma frase: o formato (lista, novidade de ferramenta, antes e depois, erro comum...), a chamada usada e, no Reels, o gancho dos 3 primeiros segundos entre aspas com o número da fórmula
4. **Como moldar**: o mesmo formato adaptado aos temas, ao público e à oferta da configuração, com sugestão de título de capa (e número de slides, no carrossel)

Feche com os 2 melhores posts da própria pessoa no período (se algum passou da média dela) e a pergunta: **"Qual desses vira o seu próximo conteúdo?"** Quando ela escolher, siga para a opção 2 (carrossel) ou 3 (Reels).

Anote no histórico as fórmulas de gancho e os formatos que apareceram no topo: a opção 3 e a 6 usam isso como prova do que está funcionando no nicho dela agora.

## A página do Radar (sempre, inclusive na primeira rodada)

1. Escreva um arquivo `pagina.json` com:
   - `arroba`, `nicho`, `cor_destaque`, `cor_escura`, `cor_clara`, `fonte_titulo`, `fonte_texto` (da configuração; se faltar, use `#D15434`, `#0F0D0C`, `#F7F4F1`, Barlow Condensed e Plus Jakarta Sans)
   - `achados`: 3 pares [título curto, texto de 1 a 2 frases] com o que ESTA rodada mostrou (qual formato explodiu, quem posta mais carrossel, que tema está em alta). Só com base nos dados.
   - `moldar`: para cada link do ranking, "como moldar" em 1 a 2 frases para o público e a oferta da pessoa, com a chamada dela
   - `ganchos`: para cada Reels com transcrição, o gancho dos 3 primeiros segundos (ou "sem fala: só imagem e música")
   - `focos`: para cada perfil, o foco em poucas palavras
2. Rode `python3 scripts/pagina.py ranking.json pagina.json > radar.html`.
3. Publique:
   - Se a ferramenta de publicar páginas (Artifact) estiver disponível, publique o `radar.html` com o nome "Radar @arroba". Nas rodadas seguintes, atualize a MESMA página (guarde o link na configuração, campo "Página do Radar").
   - Se não estiver, entregue o `radar.html` como arquivo para ela abrir no navegador.
4. **PDF:** se o ambiente tiver navegador para gerar PDF, gere `Radar-@arroba-DD-MM-AAAA.pdf` em A4, com fundo e links. Se não tiver, diga que ela pode abrir o arquivo no navegador e salvar como PDF.

A página traz no fim a seção "Transforme isso em renda" com os links do criador e o crédito. Não remova nem altere.
