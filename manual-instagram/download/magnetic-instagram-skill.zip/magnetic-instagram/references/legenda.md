# Opção 4: Escrever ou revisar legenda

O feed mostra só uns 125 caracteres da legenda e esconde o resto atrás do "...mais". Quase toda legenda que falha, falha ali.

## Primeiro: qual é o trabalho desta legenda

- **Trabalho A — o vídeo já prendeu** (Reels com gancho forte). A legenda não é um segundo gancho. O trabalho dela é o pedido, o contexto que dá sentido ao pedido e as palavras que as pessoas buscam.
- **Trabalho B — a legenda é o conteúdo** (foto, carrossel). A primeira linha é o gancho, concreta, curta, e corta num suspense, não no meio de uma frase.

Diga qual dos dois está escrevendo e por quê.

## O formato

```
Linha 1    até 125 caracteres visíveis. A: o pedido, direto. B: o gancho.
           Nunca cumprimento, nunca hashtag, nunca emoji como primeiro caractere.
Corpo      parágrafos curtos, com uma linha em branco entre eles. De 2 a 6.
           É aqui que entram as palavras de busca. Listas com setas (→) funcionam bem.
O pedido   UM: a chamada da configuração (comenta a palavra, salva ou direct).
Hashtags   no máximo 5, específicas, sozinhas na última linha. Ou nenhuma.
```

Limite do Instagram: 2.200 caracteres. Quase nada precisa disso: 400 a 900 costuma bastar.

## Hashtags

Desde dezembro de 2025 o Instagram aceita no máximo **5 hashtags por post**. Hashtag hoje é etiqueta de assunto, não motor de alcance. Use até 5, específicas do nicho. Corte #viral, #fyp, #explore, #foryou.

## Palavras de busca valem mais que hashtag

A busca do Instagram lê o texto da legenda. Então a frase pela qual a pessoa quer ser achada entra na legenda como alguém digitaria, numa frase normal: "atendimento no WhatsApp" escrito na linha 3, e não "#atendimentonowhatsapp" no fim. Peça 2 ou 3 termos (ou tire dos temas da configuração).

## Regras

- **Sem link na legenda.** Não é clicável. Link vai na bio, no direct ou nos Stories.
- **Um pedido só.** Dois pedidos valem zero.
- **Palavra-chave digitável:** uma palavra, sem espaço, sem emoji, idêntica à da automação de direct, e falada também no vídeo.
- **Emoji como pontuação, não enfeite.**
- **Texto alternativo** para carrossel e foto: uma frase descrevendo a imagem.

## Passo a passo

1. Decida A ou B e diga.
2. Escreva na voz da configuração.
3. Tire a cara de IA (`references/escrita.md`).
4. Rode a checagem: salve em `legenda.txt` e rode `python3 scripts/legenda.py legenda.txt --busca "termo 1,termo 2" --palavra PALAVRA` (a palavra da chamada da configuração). Corrija todo REPROVADO. Em cada ATENÇÃO, decida em voz alta.
5. Entregue a legenda pronta pra copiar e o resumo:
   ```
   LEGENDA PRONTA
   trabalho:   B, a capa já usou as 6 palavras
   visível:    118 de 125 caracteres antes do corte
   pedido:     um, comenta GUIA
   hashtags:   4
   busca:      "atendimento no whatsapp" na linha 3
   checagem:   PRONTA
   ```

Para revisar uma legenda que a pessoa trouxer: rode a checagem primeiro, mostre o que o feed exibe e o que reprovou, depois entregue a versão corrigida.
